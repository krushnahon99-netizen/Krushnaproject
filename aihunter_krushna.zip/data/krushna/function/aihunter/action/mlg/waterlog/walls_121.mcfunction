execute if block ~ ~ ~ minecraft:tuff_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:tuff_wall[waterlogged=true] replace
execute if block ~ ~ ~ minecraft:polished_tuff_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:polished_tuff_wall[waterlogged=true] replace
execute if block ~ ~ ~ minecraft:tuff_brick_wall[waterlogged=false] run setblock ~ ~ ~ minecraft:tuff_brick_wall[waterlogged=true] replace
