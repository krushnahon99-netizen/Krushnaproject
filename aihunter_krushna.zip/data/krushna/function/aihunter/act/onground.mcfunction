##as at @e[type=minecraft:vindicator,tag=aihunter] (non-idle, target available, intent != 2, onground)
#(dy in engaged) aihunter_busy, cannot be grouped
#get over obstacles

execute unless score @s aihunter_busy matches 1.. if score @s aihunter_intent matches 0 if score @s aihunter_d matches ..25 if score @s aihunter_dy matches ..-1000 run function krushna:aihunter/action/break/down

# Show exact scores for debugging
execute if score debug aihunter_dummy matches 1 run tellraw @a ["dy=",{"score":{"name":"@s","objective":"aihunter_dy"}},", d=",{"score":{"name":"@s","objective":"aihunter_d"}},", intent=",{"score":{"name":"@s","objective":"aihunter_intent"}},", busy=",{"score":{"name":"@s","objective":"aihunter_busy"}}]

execute if score @s aihunter_intent matches 0 if score @s aihunter_d matches ..100 if score @s aihunter_dy matches 3000.. run function krushna:aihunter/action/build/tower


execute if predicate krushna:aihunter/dimension/overworld if score @s aihunter_y1 matches 61000.. run function krushna:aihunter/act/location/surface

execute if predicate krushna:aihunter/dimension/overworld if score @s aihunter_y1 matches ..60999 run function krushna:aihunter/act/location/underground


execute if predicate krushna:aihunter/dimension/nether run function krushna:aihunter/act/location/nether

execute if predicate krushna:aihunter/dimension/end run function krushna:aihunter/act/location/surface


#check if set spawnpoint (bed)

execute if score dimension aihunter_dummy matches 0 unless score bed aihunter_dummy matches 1 if score @s aihunter_d matches 160.. if predicate krushna:aihunter/chance/10 run function krushna:aihunter/check/bed


#check if create fire (disabled)

#execute unless score @s aihunter_busy matches 1.. if score difficulty aihunter_dummy matches 4.. if score @s aihunter_upgrade matches 2.. at @p[distance=..1.5,gamemode=!creative,gamemode=!spectator,team=!aihunter] if predicate krushna:aihunter/chance/10 run function krushna:aihunter/action/build/fire


#check if heal

execute if score difficulty aihunter_dummy matches 2..3 if score @s aihunter_upgrade matches 3.. unless score @s aihunter_potion matches ..-3 if score @s aihunter_hp matches ..90 unless entity @p[distance=..3,gamemode=!creative,gamemode=!spectator,team=!aihunter] if entity @p[distance=..8,gamemode=!creative,gamemode=!spectator,team=!aihunter] if predicate krushna:aihunter/chance/40 run function krushna:aihunter/action/potion/heal


#pick up (delete) items

execute as @e[distance=..1,type=minecraft:item,limit=6,sort=nearest] unless data entity @s Thrower run kill @s


#check if place water (brief)

execute if entity @s[predicate=krushna:aihunter/onfire,predicate=!krushna:aihunter/dimension/nether] run setblock ~ ~ ~ minecraft:water[level=15] keep
execute if score debug aihunter_dummy matches 1 run say ONGROUND RUNNING - dy={aihunter_dy} d={aihunter_d} busy={aihunter_busy}
