execute if block ~ ~ ~ minecraft:creaking_heart run setblock ~ ~ ~ minecraft:water replace
