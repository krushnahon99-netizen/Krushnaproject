'use client'

import { useSyncExternalStore } from 'react'
import { Star } from 'lucide-react'
import { hudStore } from '@/lib/game/state'
import { Minimap } from './minimap'
import { useIsTouchDevice } from './touch-controls'
import { cn } from '@/lib/utils'

const outline = { textShadow: '0 0 2px #000, 0 0 2px #000, 2px 2px 0 #000, -2px -2px 0 #000, 2px -2px 0 #000, -2px 2px 0 #000' }

export function Hud() {
  const hud = useSyncExternalStore(hudStore.subscribe, hudStore.getSnapshot, hudStore.getServerSnapshot)
  const touch = useIsTouchDevice()
  if (!hud.started) return null

  return (
    <div className="pointer-events-none fixed inset-0 z-10 select-none">
      <div className="absolute right-4 top-4 flex flex-col items-end gap-1 md:right-8 md:top-6">
        <div className="flex items-baseline gap-2" aria-label={`Time ${hud.clock}, ${hud.phase}`}>
          <span className="font-display text-xs uppercase tracking-[0.2em] text-white/85 md:text-sm" style={outline}>
            {hud.warping ? 'Time warp' : hud.phase}
          </span>
          <span
            className={cn('font-display text-2xl tracking-wide md:text-3xl', hud.warping ? 'text-[#ffcf4a]' : 'text-white')}
            style={outline}
          >
            {hud.clock}
          </span>
        </div>
        <p className="font-display text-3xl tracking-wide text-[#7ee08a] md:text-5xl" style={outline}>
          {'$'}
          {hud.money.toString().padStart(9, '0')}
        </p>
        <div className="flex gap-1" aria-label={`Wanted level ${hud.wanted} of 5`}>
          {Array.from({ length: 5 }, (_, i) => (
            <Star
              key={i}
              className={cn(
                'size-5 stroke-black stroke-2 md:size-7',
                i < hud.wanted ? 'fill-white text-white animate-pulse' : 'fill-black/40 text-black/40',
              )}
            />
          ))}
        </div>
      </div>

      {hud.prompt && (
        <div
          className={cn(
            'absolute max-w-56 rounded-md bg-black/75 px-4 py-3 text-sm text-white shadow-lg',
            touch ? 'bottom-[17rem] right-4' : 'left-4 top-4 md:left-8 md:top-6',
          )}
        >
          {touch ? hud.prompt.replace('Press F to', 'Tap Enter to').replace('Tap Enter to exit', 'Tap Exit to leave') : hud.prompt}
        </div>
      )}

      <div className="absolute inset-x-0 top-20 flex flex-col items-center gap-1 md:top-24" aria-live="polite">
        {hud.notices.map((notice) => (
          <p
            key={notice.id}
            className={cn(
              'font-display text-2xl tracking-wide animate-in fade-in slide-in-from-top-2 md:text-4xl',
              notice.tone === 'cash' ? 'text-[#7ee08a]' : 'text-[#ffcf4a]',
            )}
            style={outline}
          >
            {notice.text}
          </p>
        ))}
      </div>

      <div
        className={cn(
          'absolute',
          touch ? 'left-3 top-3 origin-top-left scale-[0.55]' : 'bottom-40 left-3 md:bottom-6 md:left-8',
        )}
      >
        <Minimap />
      </div>

      {hud.mode === 'car' && (
        <div className={cn('absolute text-right', touch ? 'bottom-44 right-5' : 'bottom-48 right-4 md:bottom-6 md:right-8')}>
          <p className={cn('font-display leading-none text-white', touch ? 'text-5xl' : 'text-5xl md:text-7xl')} style={outline}>
            {hud.speed}
          </p>
          <p className="font-display text-sm tracking-widest text-white/90 md:text-lg" style={outline}>
            KM/H
          </p>
        </div>
      )}

      <p
        className={cn(
          'absolute bottom-6 left-1/2 hidden -translate-x-1/2 rounded-md bg-black/50 px-3 py-1.5 text-xs text-white/85',
          !touch && 'md:block',
        )}
      >
        {hud.mode === 'car'
          ? 'W/S accelerate & brake  ·  A/D steer  ·  Space handbrake  ·  F exit  ·  Hold T time warp'
          : 'W/S walk  ·  A/D turn  ·  Shift sprint  ·  Space jump  ·  F enter car  ·  Hold T time warp'}
      </p>
    </div>
  )
}
