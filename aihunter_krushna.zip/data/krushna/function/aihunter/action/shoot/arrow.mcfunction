summon minecraft:arrow ~ ~1.6 ~ {Tags:["aihunter_arrow","aihunter_arrow_fresh"],pickup:1,ShotFromCrossbow:1}

data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] {HandItems:[{id:"minecraft:crossbow",count:1},{}]}

execute if score @s aihunter_upgrade matches 6.. run data merge entity @s {HandItems:[{id:"minecraft:crossbow",count:1},{}]}


scoreboard players set @s aihunter_weapon 0

scoreboard players remove @s aihunter_arrow 1

execute unless score @s aihunter_arrow matches ..-6 run scoreboard players add @s aihunter_busy 6

execute unless score @s aihunter_arrow matches ..-6 run effect give @s minecraft:saturation 2 31 true

execute unless score @s aihunter_arrow matches ..-6 run effect give @s minecraft:weakness 2 10 true


function krushna:aihunter/find/vector/3d

execute as @e[limit=1,sort=nearest,type=minecraft:arrow,tag=aihunter_arrow_fresh] run function krushna:aihunter/action/shoot/arrow1


playsound minecraft:item.crossbow.shoot master @a ~ ~ ~

execute unless score @s aihunter_arrow matches ..-6 run playsound minecraft:item.crossbow.loading_start master @a ~ ~ ~

execute unless score @s aihunter_arrow matches ..-6 run playsound minecraft:item.crossbow.loading_middle master @a ~ ~ ~