import bpy, sys

def report(path):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if path.endswith('.fbx'):
        bpy.ops.import_scene.fbx(filepath=path)
    else:
        bpy.ops.import_scene.gltf(filepath=path)
    print('=====', path)
    for o in bpy.data.objects:
        if o.type == 'MESH':
            me = o.data
            print('MESH', o.name, 'verts', len(me.vertices), 'mats', [m.name for m in me.materials],
                  'shapekeys', len(me.shape_keys.key_blocks) if me.shape_keys else 0,
                  'groups', len(o.vertex_groups), 'dims', tuple(round(d, 3) for d in o.dimensions))
        elif o.type == 'ARMATURE':
            bones = o.data.bones
            print('ARM', o.name, len(bones))
            for b in bones:
                h = o.matrix_world @ b.head_local
                t = o.matrix_world @ b.tail_local
                print('  ', b.name, '<', b.parent.name if b.parent else None,
                      'h', tuple(round(v, 3) for v in h), 't', tuple(round(v, 3) for v in t))
    for m in bpy.data.materials:
        imgs = []
        if m.use_nodes:
            for n in m.node_tree.nodes:
                if n.type == 'TEX_IMAGE' and n.image:
                    imgs.append(n.image.name)
        print('MAT', m.name, imgs)

for p in sys.argv[sys.argv.index('--') + 1:]:
    report(p)
