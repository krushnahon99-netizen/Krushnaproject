#1..
#__
#_h
#xh

execute unless score @s aihunter_busy matches 1.. unless block ^ ^0.5 ^0.5 #krushna:aihunter/passable_117 unless block ^ ^0.5 ^0.5 minecraft:snow[layers=1] run function krushna:aihunter/find/action/underground/situation/1


#2=break front
#__
#xh
#oh

execute unless score @s aihunter_busy matches 1.. if block ^ ^0.5 ^0.5 #krushna:aihunter/passable_117 unless block ^ ^1.5 ^0.5 #krushna:aihunter/passable_117 unless block ^ ^1.5 ^0.5 minecraft:snow[layers=1] run function krushna:aihunter/find/action/underground/situation/2