execute if score initialupgrade aihunter_dummy matches ..1 run data merge entity @s {ArmorItems:[{id:"minecraft:leather_boots"},{id:"minecraft:leather_leggings"},{id:"minecraft:leather_chestplate"},{id:"minecraft:skeleton_skull"}]}

execute if score initialupgrade aihunter_dummy matches 2 run data merge entity @s {ArmorItems:[{id:"minecraft:iron_boots"},{id:"minecraft:leather_leggings"},{id:"minecraft:iron_chestplate"},{id:"minecraft:skeleton_skull"}]}

execute if score initialupgrade aihunter_dummy matches 3 run data merge entity @s {ArmorItems:[{id:"minecraft:iron_boots"},{id:"minecraft:iron_leggings"},{id:"minecraft:iron_chestplate"},{id:"minecraft:skeleton_skull"}]}

execute if score initialupgrade aihunter_dummy matches 4 run data merge entity @s {ArmorItems:[{id:"minecraft:iron_boots"},{id:"minecraft:diamond_leggings"},{id:"minecraft:diamond_chestplate"},{id:"minecraft:skeleton_skull"}]}

execute if score initialupgrade aihunter_dummy matches 5 run data merge entity @s {ArmorItems:[{id:"minecraft:diamond_boots"},{id:"minecraft:diamond_leggings"},{id:"minecraft:diamond_chestplate"},{id:"minecraft:skeleton_skull"}]}

execute if score initialupgrade aihunter_dummy matches 6.. run data merge entity @s {ArmorItems:[{id:"minecraft:netherite_boots"},{id:"minecraft:netherite_leggings"},{id:"minecraft:netherite_chestplate"},{id:"minecraft:wither_skeleton_skull"}]}
