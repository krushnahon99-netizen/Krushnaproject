execute if block ~ ~ ~ minecraft:pale_oak_trapdoor[waterlogged=false] run setblock ~ ~ ~ minecraft:pale_oak_trapdoor[waterlogged=true] replace
