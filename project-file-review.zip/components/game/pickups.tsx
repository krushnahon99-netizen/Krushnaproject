'use client'

import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { game } from '@/lib/game/state'

function CashPickup({ index }: { index: number }) {
  const group = useRef<THREE.Group>(null)
  const spinner = useRef<THREE.Group>(null)

  useFrame((state) => {
    const pickup = game.pickups[index]
    if (!group.current || !spinner.current) return
    const t = state.clock.elapsedTime
    group.current.position.set(pickup.x, 0, pickup.z)
    spinner.current.rotation.y = t * 1.8 + index
    spinner.current.position.y = 1.2 + Math.sin(t * 2.4 + index) * 0.2
  })

  return (
    <group ref={group}>
      <group ref={spinner}>
        <mesh castShadow>
          <boxGeometry args={[0.9, 0.35, 0.5]} />
          <meshStandardMaterial color="#3f8a4a" emissive="#2fbf55" emissiveIntensity={0.6} roughness={0.5} />
        </mesh>
        <mesh position={[0, 0, 0]}>
          <boxGeometry args={[0.92, 0.12, 0.52]} />
          <meshStandardMaterial color="#e9e2c8" roughness={0.6} />
        </mesh>
      </group>
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.05, 0]}>
        <ringGeometry args={[1.1, 1.35, 40]} />
        <meshBasicMaterial color={[0.4, 3, 0.8]} toneMapped={false} transparent opacity={0.85} />
      </mesh>
      <mesh position={[0, 4, 0]}>
        <cylinderGeometry args={[0.6, 1.2, 8, 20, 1, true]} />
        <meshBasicMaterial color={[0.3, 2, 0.6]} toneMapped={false} transparent opacity={0.12} depthWrite={false} side={THREE.DoubleSide} />
      </mesh>
    </group>
  )
}

export function Pickups() {
  return (
    <group>
      {game.pickups.map((pickup, index) => (
        <CashPickup key={pickup.id} index={index} />
      ))}
    </group>
  )
}
