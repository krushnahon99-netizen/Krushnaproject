'use client'

import { Suspense, useLayoutEffect, useRef, useState } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Environment, Lightformer, PerformanceMonitor, Sky } from '@react-three/drei'
import * as THREE from 'three'
import {
  Bloom,
  BrightnessContrast,
  EffectComposer,
  HueSaturation,
  N8AO,
  SMAA,
  ToneMapping,
  Vignette,
} from '@react-three/postprocessing'
import { ToneMappingMode } from 'postprocessing'
import { City } from './city'
import { Palms } from './palms'
import { CarModel } from './car-model'
import { PlayerModel } from './player-model'
import { Pickups } from './pickups'
import { CameraRig, GameLoop, SUN_POSITION, SunLight } from './camera-rig'
import { game, input } from '@/lib/game/state'
import { QUALITY } from '@/lib/game/quality'
import { graphicsStatus } from '@/lib/game/diagnostics'

const SKY = { turbidity: 5, rayleigh: 1.4, mieCoefficient: 0.004, mieDirectionalG: 0.82 }

function FrameTracker() {
  useFrame(() => graphicsStatus.frame())
  return null
}

function MobileToneMapping() {
  const gl = useThree((state) => state.gl)
  useLayoutEffect(() => {
    gl.toneMapping = THREE.AgXToneMapping
    gl.toneMappingExposure = 1.05
    return () => {
      gl.toneMapping = THREE.NoToneMapping
    }
  }, [gl])
  return null
}

const initialDpr = () => Math.min(1.5, window.devicePixelRatio || 1)

function CityEnvironment() {
  return (
    <Environment frames={1} resolution={128}>
      <color attach="background" args={['#9fb9d1']} />
      <Lightformer form="rect" intensity={2.2} color="#dcebff" scale={[60, 60, 1]} position={[0, 30, 0]} rotation-x={Math.PI / 2} />
      <Lightformer form="rect" intensity={3} color="#fff1de" scale={[20, 12, 1]} position={[30, 20, -20]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={0.8} color="#c9d6e2" scale={[40, 10, 1]} position={[-30, 6, 10]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={0.5} color="#8a7c66" scale={[60, 60, 1]} position={[0, -10, 0]} rotation-x={-Math.PI / 2} />
    </Environment>
  )
}

export default function Scene() {
  const drag = useRef<{ id: number; x: number; y: number } | null>(null)
  const [dpr, setDpr] = useState(initialDpr)
  const [highQuality, setHighQuality] = useState(QUALITY.ambientOcclusion)
  const [postFx, setPostFx] = useState(true)
  const [shadows, setShadows] = useState(true)
  const [canvasKey, setCanvasKey] = useState(0)

  const endLook = (pointerId: number) => {
    if (drag.current?.id !== pointerId) return
    drag.current = null
    input.lookHeld = false
  }

  return (
    <div
      className="fixed inset-0 touch-none select-none"
      onPointerDown={(e) => {
        if (drag.current) return
        e.currentTarget.setPointerCapture(e.pointerId)
        drag.current = { id: e.pointerId, x: e.clientX, y: e.clientY }
        input.lookHeld = true
      }}
      onPointerMove={(e) => {
        if (drag.current?.id !== e.pointerId) return
        const sensitivity = e.pointerType === 'mouse' ? 0.006 : 0.009
        input.cameraDrag -= (e.clientX - drag.current.x) * sensitivity
        input.cameraPitch = Math.max(-0.25, Math.min(0.6, input.cameraPitch + (e.clientY - drag.current.y) * sensitivity * 0.7))
        drag.current.x = e.clientX
        drag.current.y = e.clientY
      }}
      onPointerUp={(e) => endLook(e.pointerId)}
      onPointerCancel={(e) => endLook(e.pointerId)}
      onLostPointerCapture={(e) => endLook(e.pointerId)}
    >
      <Canvas
        key={canvasKey}
        shadows={!shadows ? false : QUALITY.softShadows ? 'soft' : true}
        dpr={dpr}
        camera={{ fov: 55, near: 0.3, far: 1600, position: [0, 4, 0] }}
        gl={{
          antialias: QUALITY.mobile,
          powerPreference: 'high-performance',
          stencil: false,
          failIfMajorPerformanceCaveat: false,
        }}
        onCreated={({ gl }) => {
          const context = gl.getContext()
          const info = context.getExtension('WEBGL_debug_renderer_info')
          graphicsStatus.setRenderer(
            String(info ? context.getParameter(info.UNMASKED_RENDERER_WEBGL) : context.getParameter(context.RENDERER)),
          )
          gl.debug.onShaderError = (glContext, _program, vertexShader, fragmentShader) => {
            const log = glContext.getShaderInfoLog(vertexShader) || glContext.getShaderInfoLog(fragmentShader) || 'shader failed'
            graphicsStatus.error(`Shader: ${log.trim()}`)
          }
          gl.domElement.addEventListener('webglcontextlost', (event) => {
            event.preventDefault()
            graphicsStatus.contextLost()
            setHighQuality(false)
            setPostFx(!QUALITY.mobile)
            setDpr(1)
            if (graphicsStatus.get().contextLosses <= 2) setTimeout(() => setCanvasKey((k) => k + 1), 300)
          })
        }}
      >
        <PerformanceMonitor
          flipflops={2}
          onDecline={() => {
            if (dpr > 1.25) {
              setDpr(1.25)
              return
            }
            if (dpr > 1) {
              setDpr(1)
              return
            }
            if (QUALITY.mobile) setPostFx(false)
            else setHighQuality(false)
          }}
          onFallback={() => {
            setDpr(1)
            setHighQuality(false)
            if (QUALITY.mobile) {
              setPostFx(false)
              setShadows(false)
            }
          }}
        />
        <color attach="background" args={['#a9c4dc']} />
        <fogExp2 attach="fog" args={['#b8c9d8', 0.0014]} />
        <Sky sunPosition={SUN_POSITION} distance={4500} {...SKY} />
        <hemisphereLight args={['#cfe0f5', '#6e604c', shadows ? 0.45 : 1.1]} />
        <SunLight />
        <CityEnvironment />
        <FrameTracker />

        <GameLoop />
        <Suspense fallback={null}>
          <City />
          <Palms />
        </Suspense>
        <Pickups />
        <Suspense fallback={null}>
          {game.cars.map((car) => (
            <CarModel key={car.id} car={car} />
          ))}
        </Suspense>
        <Suspense fallback={null}>
          <PlayerModel />
        </Suspense>
        <CameraRig />

        {!postFx ? (
          <MobileToneMapping />
        ) : (
          <EffectComposer multisampling={QUALITY.mobile ? 4 : 0} enableNormalPass={false}>
            {highQuality ? (
              <N8AO aoRadius={2.2} distanceFalloff={1.2} intensity={2.4} quality="performance" halfRes />
            ) : (
              <></>
            )}
            <Bloom luminanceThreshold={1.05} luminanceSmoothing={0.25} intensity={0.45} mipmapBlur />
            <HueSaturation saturation={0.14} />
            <BrightnessContrast brightness={0.01} contrast={0.12} />
            <ToneMapping mode={ToneMappingMode.AGX} />
            <Vignette offset={0.3} darkness={0.42} />
            {QUALITY.antialiasPass ? <SMAA /> : <></>}
          </EffectComposer>
        )}
      </Canvas>
    </div>
  )
}
