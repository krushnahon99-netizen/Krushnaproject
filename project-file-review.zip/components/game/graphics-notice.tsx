'use client'

import { useEffect, useState, useSyncExternalStore } from 'react'
import { TriangleAlert } from 'lucide-react'
import { graphicsStatus } from '@/lib/game/diagnostics'

export function GraphicsNotice() {
  const status = useSyncExternalStore(graphicsStatus.subscribe, graphicsStatus.get, graphicsStatus.get)
  const [timedOut, setTimedOut] = useState(false)
  const [dismissed, setDismissed] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setTimedOut(true), 8000)
    return () => clearTimeout(timer)
  }, [])

  const noFrames = timedOut && status.framesDrawn === 0
  const failing = noFrames || status.contextLosses > 0 || status.errors.length > 0
  if (!failing || dismissed) return null

  return (
    <div
      role="status"
      className="pointer-events-auto fixed left-1/2 top-3 z-40 flex w-[min(92vw,520px)] -translate-x-1/2 items-start gap-3 rounded-lg bg-black/80 p-3 text-xs leading-relaxed text-white backdrop-blur"
    >
      <TriangleAlert aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-amber-400" />
      <div className="flex min-w-0 flex-col gap-1">
        <p className="font-semibold">Graphics problem on this device</p>
        <p className="text-white/75">
          {`GPU: ${status.renderer} · frames: ${status.framesDrawn} · context lost: ${status.contextLosses}`}
        </p>
        {status.errors.map((error) => (
          <p key={error} className="break-words font-mono text-[10px] text-white/60">
            {error}
          </p>
        ))}
        <p className="text-white/75">Screenshot this message and send it to the developer.</p>
      </div>
      <button
        type="button"
        onClick={() => setDismissed(true)}
        className="ml-auto shrink-0 rounded px-2 py-1 text-white/70 hover:bg-white/10"
      >
        Close
      </button>
    </div>
  )
}
