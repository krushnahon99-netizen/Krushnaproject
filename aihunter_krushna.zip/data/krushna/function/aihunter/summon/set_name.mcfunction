data merge entity @s {text:"Hunter"}

execute if score showhp aihunter_dummy matches 1 in minecraft:the_end run function krushna:aihunter/summon/set_hpbar
