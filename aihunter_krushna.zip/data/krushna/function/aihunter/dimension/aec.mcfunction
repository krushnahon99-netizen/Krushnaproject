execute if predicate krushna:aihunter/dimension/overworld run summon minecraft:area_effect_cloud ~ ~6 ~ {Radius:0f,Duration:9000000,Radius:0f,Tags:["aihunter_overworld_portal"]}

execute if predicate krushna:aihunter/dimension/nether run summon minecraft:area_effect_cloud ~ ~6 ~ {Radius:0f,Duration:9000000,Radius:0f,Tags:["aihunter_nether_spawn"]}

execute if predicate krushna:aihunter/dimension/end run summon minecraft:area_effect_cloud ~ ~ ~ {Radius:0f,Duration:9000000,Radius:0f,Tags:["aihunter_end_spawn"]}

forceload add ~ ~

execute if score debug aihunter_dummy matches 1 run say aec