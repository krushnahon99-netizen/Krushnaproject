
scoreboard players set @s aihunter_tower 0

execute positioned ~0.3 ~ ~0.3 unless block ~ ~-0.5 ~ #krushna:aihunter/passable unless block ~ ~-1.5 ~ #krushna:aihunter/passable unless block ~ ~-2.5 ~ #krushna:aihunter/passable positioned as @s run function krushna:aihunter/check/tower/corner/1

execute positioned ~-0.3 ~ ~0.3 unless block ~ ~-0.5 ~ #krushna:aihunter/passable unless block ~ ~-1.5 ~ #krushna:aihunter/passable unless block ~ ~-2.5 ~ #krushna:aihunter/passable positioned as @s run function krushna:aihunter/check/tower/corner/2

execute positioned ~-0.3 ~ ~-0.3 unless block ~ ~-0.5 ~ #krushna:aihunter/passable unless block ~ ~-1.5 ~ #krushna:aihunter/passable unless block ~ ~-2.5 ~ #krushna:aihunter/passable positioned as @s run function krushna:aihunter/check/tower/corner/3

execute positioned ~0.3 ~ ~-0.3 unless block ~ ~-0.5 ~ #krushna:aihunter/passable unless block ~ ~-1.5 ~ #krushna:aihunter/passable unless block ~ ~-2.5 ~ #krushna:aihunter/passable positioned as @s run function krushna:aihunter/check/tower/corner/4