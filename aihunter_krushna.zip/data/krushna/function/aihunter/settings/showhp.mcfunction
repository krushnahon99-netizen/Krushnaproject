scoreboard players add showhp aihunter_dummy 1

execute unless score showhp aihunter_dummy matches 0..1 run scoreboard players set showhp aihunter_dummy 0

function krushna:aihunter/settings/menu/1

execute if score started aihunter_dummy matches 1 if score showhp aihunter_dummy matches 0 as @e[type=minecraft:text_display,tag=aihunter_name] run data merge entity @s {text:"Hunter"}

execute if score started aihunter_dummy matches 1 if score showhp aihunter_dummy matches 0 as @e[type=minecraft:text_display,tag=aihunter_name] run data modify entity @s text set from storage minecraft:aihunter_custom name

execute if score started aihunter_dummy matches 1 if score showhp aihunter_dummy matches 1 as @e[type=minecraft:vindicator,tag=aihunter] at @s in minecraft:the_end run function krushna:aihunter/hp