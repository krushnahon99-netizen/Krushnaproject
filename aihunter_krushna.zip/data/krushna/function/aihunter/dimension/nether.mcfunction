##^aihunter/always
##as at server

#execute as @p[predicate=krushna:aihunter/dimension/nether] at @s unless entity @e[type=minecraft:area_effect_cloud,tag=aihunter_nether_spawn] run function krushna:aihunter/dimension/aec

execute at @e[type=minecraft:area_effect_cloud,tag=aihunter_nether_spawn,limit=1,sort=nearest] run function krushna:aihunter/check/respawn