'use client'

import { type ReactNode, useLayoutEffect, useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { useTexture } from '@react-three/drei'
import * as THREE from 'three'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'
import {
  BEACH_START,
  BLOCK,
  BLOCK_CENTERS,
  type BuildingStyle,
  CELL,
  HALF,
  ROAD,
  ROAD_LINES,
  SHORE_X,
  city,
} from '@/lib/game/world'
import {
  TEXTURE_URLS,
  createGlossMap,
  createNormalMap,
  createWaterNormalMap,
  createWindowLightMap,
  setupTiling,
} from '@/lib/game/textures'
import { createRandom } from '@/lib/game/random'
import { lighting } from '@/lib/game/time-of-day'

type Rect = { x: number; z: number; w: number; l: number; y?: number; h?: number }
type Tile = { w: number; h: number; snap: boolean }
type RGB = [number, number, number]

const TILES: Record<BuildingStyle | 'storefront' | 'roof', Tile> = {
  glass: { w: 15, h: 15, snap: true },
  stucco: { w: 13, h: 13, snap: true },
  concrete: { w: 14, h: 14, snap: true },
  storefront: { w: 12, h: 14.4, snap: true },
  roof: { w: 9, h: 9, snap: false },
}

function boxPiece(w: number, h: number, d: number, x: number, y: number, z: number, color: RGB, tile: Tile, offset: [number, number] = [0, 0]) {
  const geometry = new THREE.BoxGeometry(w, h, d)
  geometry.translate(x, y, z)
  const uv = geometry.attributes.uv as THREE.BufferAttribute
  for (let face = 0; face < 6; face++) {
    const isCap = face === 2 || face === 3
    const faceW = face < 2 ? d : w
    const faceH = isCap ? d : h
    let su = faceW / tile.w
    let sv = faceH / tile.h
    if (tile.snap && !isCap) {
      su = Math.max(1, Math.round(su * 4)) / 4
      sv = Math.max(1, Math.round(sv * 4)) / 4
    }
    for (let k = 0; k < 4; k++) {
      const index = face * 4 + k
      uv.setXY(index, uv.getX(index) * su + offset[0], uv.getY(index) * sv + offset[1])
    }
  }
  const colors = new Float32Array(24 * 3)
  for (let i = 0; i < 24; i++) colors.set(color, i * 3)
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3))
  return geometry
}

function merge(pieces: THREE.BufferGeometry[]) {
  if (!pieces.length) return null
  const merged = mergeGeometries(pieces)
  pieces.forEach((p) => p.dispose())
  return merged
}

function Buildings() {
  const [glassMap, stuccoMap, concreteMap, roofMap] = useTexture([
    TEXTURE_URLS.facadeGlass,
    TEXTURE_URLS.facadeStucco,
    TEXTURE_URLS.facadeConcrete,
    TEXTURE_URLS.roof,
  ])

  const { meshes, neon, windowMaterials } = useMemo(() => {
    const random = createRandom(99)
    const groups: Record<BuildingStyle | 'roof' | 'trim', THREE.BufferGeometry[]> = { glass: [], stucco: [], concrete: [], roof: [], trim: [] }
    const neonPieces: THREE.BufferGeometry[] = []
    const roofTint: RGB = [0.78, 0.78, 0.78]
    const trim: RGB = [0.95, 0.93, 0.89]
    const storefrontTint: RGB = [0.5, 0.55, 0.6]

    for (const b of city.buildings) {
      const base = 0.25
      const tile = TILES[b.style]
      const offset: [number, number] = b.style === 'glass' ? b.uvOffset : [0, 0]
      groups[b.style].push(boxPiece(b.w, b.h, b.d, b.x, base + b.h / 2, b.z, b.color, tile, offset))

      if (b.style !== 'glass') {
        groups.glass.push(boxPiece(b.w + 0.12, 3.6, b.d + 0.12, b.x, base + 1.8, b.z, storefrontTint, TILES.storefront))
        groups.trim.push(boxPiece(b.w + 0.6, 0.35, b.d + 0.6, b.x, base + 3.78, b.z, trim, TILES.roof))
      }

      groups.trim.push(boxPiece(b.w + 0.3, 0.8, b.d + 0.3, b.x, base + b.h + 0.4, b.z, b.style === 'glass' ? [0.7, 0.72, 0.75] : trim, TILES.roof))
      groups.roof.push(boxPiece(b.w - 0.1, 0.1, b.d - 0.1, b.x, base + b.h + 0.84, b.z, roofTint, TILES.roof))
      let top = base + b.h + 0.8
      if (b.tier) {
        groups[b.style].push(boxPiece(b.tier.w, b.tier.h, b.tier.d, b.x, top + b.tier.h / 2, b.z, b.color, tile, offset))
        top += b.tier.h
        groups.trim.push(boxPiece(b.tier.w + 0.3, 0.6, b.tier.d + 0.3, b.x, top + 0.3, b.z, [0.7, 0.72, 0.75], TILES.roof))
        top += 0.6
        if (b.h > 70) {
          groups.trim.push(boxPiece(0.3, 14, 0.3, b.x, top + 7, b.z, [0.85, 0.85, 0.88], TILES.roof))
          groups.trim.push(boxPiece(1.6, 1.2, 1.6, b.x, top + 0.6, b.z, [0.6, 0.6, 0.62], TILES.roof))
        }
      } else {
        const units = 1 + Math.floor(random() * 3)
        for (let u = 0; u < units; u++) {
          const s = 1.5 + random() * 2.5
          groups.trim.push(
            boxPiece(s, 1.2 + random(), s * (0.6 + random() * 0.6), b.x + (random() - 0.5) * (b.w - 5), top + 0.6, b.z + (random() - 0.5) * (b.d - 5), [0.88, 0.88, 0.9], TILES.roof),
          )
        }
        if (random() < 0.35) {
          groups.trim.push(boxPiece(2.2, 3.2, 2.2, b.x + (random() - 0.5) * (b.w - 6), top + 1.6, b.z + (random() - 0.5) * (b.d - 6), [0.62, 0.6, 0.58], TILES.roof))
        }
      }

      if (b.neon) {
        const y = base + b.h - 0.9
        const t = 0.18
        const flat = TILES.roof
        neonPieces.push(boxPiece(b.w + 0.2, t, t, b.x, y, b.z + b.d / 2 + 0.1, b.neon, flat))
        neonPieces.push(boxPiece(b.w + 0.2, t, t, b.x, y, b.z - b.d / 2 - 0.1, b.neon, flat))
        neonPieces.push(boxPiece(t, t, b.d + 0.2, b.x + b.w / 2 + 0.1, y, b.z, b.neon, flat))
        neonPieces.push(boxPiece(t, t, b.d + 0.2, b.x - b.w / 2 - 0.1, y, b.z, b.neon, flat))
      }
    }

    setupTiling(glassMap)
    setupTiling(stuccoMap)
    setupTiling(concreteMap)
    setupTiling(roofMap)

    const glassMaterial = new THREE.MeshStandardMaterial({
      map: glassMap,
      emissiveMap: createWindowLightMap(glassMap, 'glass', 7),
      emissive: '#ffffff',
      emissiveIntensity: 0,
      vertexColors: true,
      roughness: 0.08,
      metalness: 0.85,
      envMapIntensity: 1.5,
    })
    const stuccoMaterial = new THREE.MeshStandardMaterial({
      map: stuccoMap,
      roughnessMap: createGlossMap(stuccoMap, 0.45, 0.12, 0.92),
      normalMap: createNormalMap(stuccoMap, 2.5),
      normalScale: new THREE.Vector2(0.6, 0.6),
      emissiveMap: createWindowLightMap(stuccoMap, 'punched', 13),
      emissive: '#ffffff',
      emissiveIntensity: 0,
      vertexColors: true,
      metalness: 0,
      envMapIntensity: 1.1,
    })
    const concreteMaterial = new THREE.MeshStandardMaterial({
      map: concreteMap,
      roughnessMap: createGlossMap(concreteMap, 0.3, 0.15, 0.95),
      normalMap: createNormalMap(concreteMap, 3),
      normalScale: new THREE.Vector2(0.9, 0.9),
      emissiveMap: createWindowLightMap(concreteMap, 'punched', 21),
      emissive: '#ffffff',
      emissiveIntensity: 0,
      vertexColors: true,
      metalness: 0,
      envMapIntensity: 1,
    })
    const roofMaterial = new THREE.MeshStandardMaterial({
      map: roofMap,
      normalMap: createNormalMap(roofMap, 3),
      vertexColors: true,
      roughness: 0.95,
      metalness: 0,
    })

    const trimMaterial = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.8, metalness: 0.05 })

    return {
      windowMaterials: [glassMaterial, stuccoMaterial, concreteMaterial],
      meshes: [
        { geometry: merge(groups.glass), material: glassMaterial },
        { geometry: merge(groups.stucco), material: stuccoMaterial },
        { geometry: merge(groups.concrete), material: concreteMaterial },
        { geometry: merge(groups.roof), material: roofMaterial },
        { geometry: merge(groups.trim), material: trimMaterial },
      ],
      neon: merge(neonPieces),
    }
  }, [glassMap, stuccoMap, concreteMap, roofMap])

  const neonMaterial = useRef<THREE.MeshBasicMaterial>(null)
  useFrame(() => {
    const night = lighting.night
    windowMaterials[0].emissiveIntensity = night * 0.65
    windowMaterials[1].emissiveIntensity = night * 1.4
    windowMaterials[2].emissiveIntensity = night * 1.5
    neonMaterial.current?.color.setScalar(1 + night * 2.2)
  })

  return (
    <group>
      {meshes.map(
        (m, i) => m.geometry && <mesh key={i} geometry={m.geometry} material={m.material} castShadow receiveShadow />,
      )}
      {neon && (
        <mesh geometry={neon}>
          <meshBasicMaterial ref={neonMaterial} vertexColors toneMapped={false} />
        </mesh>
      )}
    </group>
  )
}

function InstancedBoxes({
  rects,
  y,
  receiveShadow = true,
  children,
}: {
  rects: Rect[]
  y: number
  receiveShadow?: boolean
  children: ReactNode
}) {
  const ref = useRef<THREE.InstancedMesh>(null)
  useLayoutEffect(() => {
    const mesh = ref.current
    if (!mesh) return
    const dummy = new THREE.Object3D()
    rects.forEach((rect, i) => {
      dummy.position.set(rect.x, rect.y ?? y, rect.z)
      dummy.rotation.set(0, 0, 0)
      dummy.scale.set(rect.w, rect.h ?? 0.02, rect.l)
      dummy.updateMatrix()
      mesh.setMatrixAt(i, dummy.matrix)
    })
    mesh.instanceMatrix.needsUpdate = true
    mesh.computeBoundingSphere()
  }, [rects, y])

  return (
    <instancedMesh ref={ref} args={[undefined, undefined, rects.length]} receiveShadow={receiveShadow}>
      <boxGeometry />
      {children}
    </instancedMesh>
  )
}

function useRoadMarkings() {
  return useMemo(() => {
    const yellow: Rect[] = []
    const white: Rect[] = []
    const crosswalks: Rect[] = []
    const segment = CELL - ROAD

    ROAD_LINES.forEach((line) => {
      BLOCK_CENTERS.forEach((center) => {
        yellow.push({ x: line - 0.2, z: center, w: 0.14, l: segment - 6 })
        yellow.push({ x: line + 0.2, z: center, w: 0.14, l: segment - 6 })
        yellow.push({ x: center, z: line - 0.2, w: segment - 6, l: 0.14 })
        yellow.push({ x: center, z: line + 0.2, w: segment - 6, l: 0.14 })
        for (const side of [-1, 1]) {
          white.push({ x: line + side * (ROAD / 2 - 0.6), z: center, w: 0.16, l: segment })
          white.push({ x: center, z: line + side * (ROAD / 2 - 0.6), w: segment, l: 0.16 })
        }
      })
    })

    ROAD_LINES.forEach((lx) => {
      ROAD_LINES.forEach((lz) => {
        for (const side of [-1, 1]) {
          for (let s = -ROAD / 2 + 1.4; s <= ROAD / 2 - 1.4; s += 1.4) {
            crosswalks.push({ x: lx + side * (ROAD / 2 + 2), z: lz + s, w: 3, l: 0.6 })
            crosswalks.push({ x: lx + s, z: lz + side * (ROAD / 2 + 2), w: 0.6, l: 3 })
          }
        }
      })
    })
    return { yellow, white, crosswalks }
  }, [])
}

function Lamps() {
  const poleRef = useRef<THREE.InstancedMesh>(null)
  const armRef = useRef<THREE.InstancedMesh>(null)
  const headRef = useRef<THREE.InstancedMesh>(null)
  const bulbRef = useRef<THREE.InstancedMesh>(null)
  const bulbMaterial = useRef<THREE.MeshStandardMaterial>(null)

  useFrame(() => {
    if (bulbMaterial.current) bulbMaterial.current.emissiveIntensity = 0.4 + lighting.night * 9
  })

  useLayoutEffect(() => {
    const dummy = new THREE.Object3D()
    city.lamps.forEach((lamp, i) => {
      dummy.rotation.set(0, lamp.rotation, 0)
      dummy.position.set(lamp.x, 3.75, lamp.z)
      dummy.scale.set(1, 1, 1)
      dummy.updateMatrix()
      poleRef.current?.setMatrixAt(i, dummy.matrix)

      const dirX = Math.sin(lamp.rotation)
      const dirZ = Math.cos(lamp.rotation)
      dummy.position.set(lamp.x + dirX * 1.2, 7.4, lamp.z + dirZ * 1.2)
      dummy.updateMatrix()
      armRef.current?.setMatrixAt(i, dummy.matrix)

      dummy.position.set(lamp.x + dirX * 2.3, 7.32, lamp.z + dirZ * 2.3)
      dummy.updateMatrix()
      headRef.current?.setMatrixAt(i, dummy.matrix)

      dummy.position.set(lamp.x + dirX * 2.3, 7.2, lamp.z + dirZ * 2.3)
      dummy.updateMatrix()
      bulbRef.current?.setMatrixAt(i, dummy.matrix)
    })
    for (const ref of [poleRef, armRef, headRef, bulbRef]) {
      if (!ref.current) continue
      ref.current.instanceMatrix.needsUpdate = true
      ref.current.computeBoundingSphere()
    }
  }, [])

  const count = city.lamps.length
  return (
    <group>
      <instancedMesh ref={poleRef} args={[undefined, undefined, count]} castShadow>
        <cylinderGeometry args={[0.08, 0.13, 7.5, 12]} />
        <meshStandardMaterial color="#4a4d52" metalness={0.8} roughness={0.45} />
      </instancedMesh>
      <instancedMesh ref={armRef} args={[undefined, undefined, count]} castShadow>
        <boxGeometry args={[0.08, 0.08, 2.6]} />
        <meshStandardMaterial color="#4a4d52" metalness={0.8} roughness={0.45} />
      </instancedMesh>
      <instancedMesh ref={headRef} args={[undefined, undefined, count]} castShadow>
        <boxGeometry args={[0.42, 0.16, 0.8]} />
        <meshStandardMaterial color="#3a3c40" metalness={0.7} roughness={0.4} />
      </instancedMesh>
      <instancedMesh ref={bulbRef} args={[undefined, undefined, count]}>
        <boxGeometry args={[0.3, 0.04, 0.62]} />
        <meshStandardMaterial
          ref={bulbMaterial}
          color="#f2efe6"
          emissive="#ffd9a0"
          emissiveIntensity={0.4}
          roughness={0.2}
          toneMapped={false}
        />
      </instancedMesh>
    </group>
  )
}

function Water() {
  const { normal, detail } = useMemo(() => {
    const normal = createWaterNormalMap()
    normal.repeat.set(140, 210)
    const detail = normal.clone()
    detail.repeat.set(380, 560)
    detail.needsUpdate = true
    return { normal, detail }
  }, [])

  const foam = useRef<THREE.MeshBasicMaterial>(null)

  useFrame((state, dt) => {
    normal.offset.x += dt * 0.004
    normal.offset.y += dt * 0.0025
    detail.offset.x -= dt * 0.006
    detail.offset.y += dt * 0.004
    if (foam.current) foam.current.opacity = 0.35 + Math.sin(state.clock.elapsedTime * 0.9) * 0.15
  })

  return (
    <group>
      <mesh rotation-x={-Math.PI / 2} position={[SHORE_X + 1000, 0.06, 0]} receiveShadow>
        <planeGeometry args={[2000, 3000]} />
        <meshPhysicalMaterial
          color="#0d4b5e"
          roughness={0.1}
          metalness={0}
          normalMap={normal}
          normalScale={new THREE.Vector2(0.45, 0.45)}
          clearcoat={1}
          clearcoatRoughness={0.03}
          clearcoatNormalMap={detail}
          clearcoatNormalScale={new THREE.Vector2(0.3, 0.3)}
          envMapIntensity={1.3}
        />
      </mesh>
      <mesh rotation-x={-Math.PI / 2} position={[SHORE_X - 3, 0.035, 0]}>
        <planeGeometry args={[7, 2000]} />
        <meshStandardMaterial color="#6e5a3c" transparent opacity={0.35} roughness={0.35} depthWrite={false} />
      </mesh>
      <mesh rotation-x={-Math.PI / 2} position={[SHORE_X + 1.2, 0.075, 0]}>
        <planeGeometry args={[2.4, 2000]} />
        <meshBasicMaterial ref={foam} color="#f4f7f6" transparent opacity={0.4} depthWrite={false} />
      </mesh>
    </group>
  )
}

function Ground() {
  const [asphalt, sidewalk, sand, grass] = useTexture([
    TEXTURE_URLS.asphalt,
    TEXTURE_URLS.sidewalk,
    TEXTURE_URLS.sand,
    TEXTURE_URLS.grass,
  ])
  const roadWidth = BEACH_START + HALF + 20
  const roadDepth = HALF * 2 + 40
  const sandWidth = SHORE_X + 8 - BEACH_START

  const maps = useMemo(() => {
    setupTiling(asphalt, roadWidth / 9, roadDepth / 9)
    setupTiling(sidewalk, BLOCK / 3.5)
    setupTiling(sand, sandWidth / 7, 2000 / 7)
    setupTiling(grass, (BLOCK - 5) / 5)
    return {
      asphaltNormal: createNormalMap(asphalt, 4),
      sidewalkNormal: createNormalMap(sidewalk, 4),
      sandNormal: createNormalMap(sand, 3),
      grassNormal: createNormalMap(grass, 3),
    }
  }, [asphalt, sidewalk, sand, grass, roadWidth, roadDepth, sandWidth])

  const sidewalks = useMemo<Rect[]>(
    () => BLOCK_CENTERS.flatMap((x) => BLOCK_CENTERS.map((z) => ({ x, z, w: BLOCK, l: BLOCK, y: 0.125, h: 0.25 }))),
    [],
  )
  const parks = useMemo<Rect[]>(
    () => city.parks.map((p) => ({ x: p.x, z: p.z, w: BLOCK - 5, l: BLOCK - 5, y: 0.26, h: 0.04 })),
    [],
  )

  return (
    <group>
      <mesh rotation-x={-Math.PI / 2} position={[(BEACH_START - HALF - 20) / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[roadWidth, roadDepth]} />
        <meshStandardMaterial map={asphalt} normalMap={maps.asphaltNormal} roughness={0.88} metalness={0} color="#9a9a9a" />
      </mesh>
      <InstancedBoxes rects={sidewalks} y={0.125}>
        <meshStandardMaterial map={sidewalk} normalMap={maps.sidewalkNormal} roughness={0.9} />
      </InstancedBoxes>
      <InstancedBoxes rects={parks} y={0.26}>
        <meshStandardMaterial map={grass} normalMap={maps.grassNormal} roughness={0.95} />
      </InstancedBoxes>
      <mesh rotation-x={-Math.PI / 2} position={[(BEACH_START + SHORE_X + 8) / 2, 0.02, 0]} receiveShadow>
        <planeGeometry args={[sandWidth, 2000]} />
        <meshStandardMaterial map={sand} normalMap={maps.sandNormal} normalScale={new THREE.Vector2(0.6, 0.6)} roughness={1} />
      </mesh>
      <mesh rotation-x={-Math.PI / 2} position={[0, -0.05, 0]}>
        <planeGeometry args={[3000, 3000]} />
        <meshStandardMaterial color="#7d776b" roughness={1} />
      </mesh>
      <Water />
    </group>
  )
}

export function City() {
  const markings = useRoadMarkings()
  return (
    <group>
      <Ground />
      <InstancedBoxes rects={markings.yellow} y={0.015}>
        <meshStandardMaterial color="#d9a92e" roughness={0.7} />
      </InstancedBoxes>
      <InstancedBoxes rects={markings.white} y={0.015}>
        <meshStandardMaterial color="#cfcfcb" roughness={0.7} />
      </InstancedBoxes>
      <InstancedBoxes rects={markings.crosswalks} y={0.016}>
        <meshStandardMaterial color="#d6d6d2" roughness={0.75} />
      </InstancedBoxes>
      <Buildings />
      <Lamps />
    </group>
  )
}
