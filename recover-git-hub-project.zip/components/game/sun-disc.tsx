'use client'

import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { SUN_DIRECTION } from './camera-rig'

// Kept well inside the camera far plane (1600) so the sprites are never clipped.
const SUN_RANGE = 700
const forward = new THREE.Vector3()

function radialTexture(stops: [number, string][]) {
  const size = 256
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = size
  const ctx = canvas.getContext('2d')!
  const gradient = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2)
  for (const [offset, color] of stops) gradient.addColorStop(offset, color)
  ctx.fillStyle = gradient
  ctx.fillRect(0, 0, size, size)
  const texture = new THREE.CanvasTexture(canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  return texture
}

export function SunDisc() {
  const group = useRef<THREE.Group>(null)
  const glare = useRef<THREE.SpriteMaterial>(null)

  const [coreMap, haloMap, glareMap] = useMemo(
    () => [
      radialTexture([
        [0, 'rgba(255,255,255,1)'],
        [0.5, 'rgba(255,252,235,1)'],
        [0.62, 'rgba(255,238,190,0.85)'],
        [0.75, 'rgba(255,220,150,0.25)'],
        [1, 'rgba(255,205,130,0)'],
      ]),
      radialTexture([
        [0, 'rgba(255,236,190,1)'],
        [0.12, 'rgba(255,215,150,0.65)'],
        [0.4, 'rgba(255,190,115,0.2)'],
        [1, 'rgba(255,175,100,0)'],
      ]),
      radialTexture([
        [0, 'rgba(255,235,200,0.75)'],
        [0.35, 'rgba(255,215,165,0.22)'],
        [1, 'rgba(255,205,150,0)'],
      ]),
    ],
    [],
  )

  useFrame(({ camera }) => {
    if (!group.current) return
    group.current.position.copy(camera.position).addScaledVector(SUN_DIRECTION, SUN_RANGE)
    if (glare.current) {
      camera.getWorldDirection(forward)
      const facing = Math.max(0, forward.dot(SUN_DIRECTION))
      glare.current.opacity = Math.pow(facing, 4)
    }
  })

  const shared = { depthWrite: false, fog: false, toneMapped: false, transparent: true } as const

  return (
    <group ref={group}>
      <sprite scale={[720, 720, 1]} renderOrder={10}>
        <spriteMaterial ref={glare} map={glareMap} blending={THREE.AdditiveBlending} {...shared} />
      </sprite>
      <sprite scale={[380, 380, 1]} renderOrder={11}>
        <spriteMaterial map={haloMap} blending={THREE.AdditiveBlending} {...shared} />
      </sprite>
      <sprite scale={[95, 95, 1]} renderOrder={12}>
        <spriteMaterial map={coreMap} color="#fffaf0" {...shared} />
      </sprite>
    </group>
  )
}
