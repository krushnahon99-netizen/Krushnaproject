setblock 100 1 0 minecraft:oak_sign{Text1:'{"text":"Kyleong was here"}',Text3:'{"text":"and so does"}',Text4:'{"text":"AI Hunter"}'} replace

execute if data storage minecraft:aihunter_custom name run data modify block 100 1 0 Text4 set value '[{"text":"["},{"text":"200","color":"red"},{"text":"/200] "},{"nbt":"name","storage":"aihunter_custom","interpret":true}]'

execute unless data storage minecraft:aihunter_custom name run data modify block 100 1 0 Text4 set value '[{"text":"["},{"text":"200","color":"red"},{"text":"/200] "},{"text":"Hunter"}]'

data modify entity @s CustomName set from block 100 1 0 Text4