execute if score started aihunter_dummy matches 1 run tellraw @s {"text":"[AI Hunter] A Challenge Is On Going Right Now!","color":"dark_red","Bold":"true"}

execute unless score started aihunter_dummy matches 1 run function krushna:aihunter/start

