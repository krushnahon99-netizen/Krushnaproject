
execute positioned ^ ^2.5 ^0.5 run function krushna:aihunter/action/break/block

execute if score debug aihunter_dummy matches 2 run say l4