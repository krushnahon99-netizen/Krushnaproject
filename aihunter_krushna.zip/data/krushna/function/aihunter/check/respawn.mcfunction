execute store result score existing aihunter_dummy if entity @e[type=minecraft:vindicator,tag=aihunter]

execute store result score #armor aihunter_dummy if entity @e[type=minecraft:armor_stand,tag=aihunter]

execute if score existing aihunter_dummy < #armor aihunter_dummy run kill @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter]

execute if score existing aihunter_dummy > #armor aihunter_dummy run function krushna:aihunter/summon/stand

execute if score existing aihunter_dummy > #armor aihunter_dummy as @e[type=minecraft:armor_stand,tag=aihunter,limit=1,sort=nearest] run function krushna:aihunter/summon/set_buff

scoreboard players operation existing aihunter_dummy += simulation aihunter_dummy

execute if score hunters aihunter_dummy < existing aihunter_dummy run kill @e[limit=1,sort=nearest,type=minecraft:vindicator,tag=aihunter]

execute as @e[type=minecraft:text_display,tag=aihunter_name] at @s unless entity @e[type=minecraft:vindicator,tag=aihunter,distance=..6] run kill @s

execute unless score #checkcd aihunter_dummy matches 1.. if score hunters aihunter_dummy > existing aihunter_dummy run function krushna:aihunter/respawn

execute if score #checkcd aihunter_dummy matches 1.. run scoreboard players remove #checkcd aihunter_dummy 1

