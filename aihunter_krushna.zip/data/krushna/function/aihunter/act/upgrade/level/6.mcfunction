##as at @e[type=minecraft:vindicator,tag=aihunter]
#set

scoreboard players set @s aihunter_upgrade 6

attribute @s minecraft:armor base set 20

attribute @s minecraft:armor_toughness base set 12

data merge entity @s {HandItems:[{},{}]}

execute unless data storage minecraft:aihunter_custom armor run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] {equipment:{feet:{id:"minecraft:netherite_boots"},legs:{id:"minecraft:netherite_leggings"},chest:{id:"minecraft:netherite_chestplate"},head:{id:"minecraft:wither_skeleton_skull"}}}


#message

execute if score notifyupgrade aihunter_dummy matches 1.. run function krushna:aihunter/message/upgrade