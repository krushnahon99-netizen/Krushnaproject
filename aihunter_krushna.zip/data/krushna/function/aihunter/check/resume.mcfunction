execute unless score pause aihunter_dummy matches 1 run tellraw @s {"text":"[AI Hunter] No Paused Challenge","color":"red","Bold":"true"}

execute if score pause aihunter_dummy matches 1 run function krushna:aihunter/resume

