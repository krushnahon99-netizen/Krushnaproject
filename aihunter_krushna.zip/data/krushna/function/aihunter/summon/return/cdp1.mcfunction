execute if score debug aihunter_dummy matches 1 run say cdp applied

scoreboard players set @s[type=minecraft:vindicator] aihunter_hp 200

data modify entity @s[type=minecraft:armor_stand] ArmorItems set from storage minecraft:aihunter_custom armor

data modify entity @s[type=minecraft:vindicator] CustomName set from storage minecraft:aihunter_custom name

execute as @e[type=minecraft:text_display,tag=aihunter_name] run data modify entity @s text set from storage minecraft:aihunter_custom name

execute if entity @s[type=minecraft:armor_stand] unless data storage minecraft:aihunter_custom armor run function krushna:aihunter/summon/return/set_buff


#effects

execute if entity @s[type=minecraft:vindicator,tag=aihunter] run effect give @s minecraft:blindness 999999 99 true

execute if entity @s[type=minecraft:vindicator,tag=aihunter] run effect give @s minecraft:weakness 999999 20 true

execute if entity @s[type=minecraft:vindicator,tag=aihunter] run effect give @s minecraft:resistance 999999 4 true


function krushna:aihunter/adjust/damage