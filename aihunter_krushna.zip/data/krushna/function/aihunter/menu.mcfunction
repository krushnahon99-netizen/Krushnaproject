playsound minecraft:ui.button.click master @s ~ ~ ~ .1
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""

tellraw @s {"text":"----------------------------------------","color":"aqua","bold":true}
tellraw @s [{"text":"AI","color":"aqua","clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/debug"}},{"text":" Hunter","color":"aqua","clickEvent":{"action":"run_command","value":"/function krushna:aihunter/check/status"}},{"text":" Datapack for Minecraft 1.16 to 1.20","color":"aqua","clickEvent":{"action":"run_command","value":""}}]

tellraw @s ""
tellraw @s {"text":"[v1.8.0] Datapack made by Kyleong","color":"aqua","hoverEvent":{"action":"show_text","contents":[{"text":"Subscribe to my Youtube channel if you like it! (URL To: youtube.com)","color":"gold"}]},"clickEvent":{"action":"open_url","value":"https://www.youtube.com/channel/UCGclCRGdWUjJdVcHLZfdaOg"}}

tellraw @s ""

execute if score pause aihunter_dummy matches 1 run tellraw @s {"text":"<[Resume]>","color":"green","bold":true,"hoverEvent":{"action":"show_text","contents":[{"text":"Current (paused) challenge will be resumed.","color":"green"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/check/resume"}}

execute unless score started aihunter_dummy matches 1 run tellraw @s {"text":"<[START]>","color":"green","bold":true,"underlined":false,"hoverEvent":{"action":"show_text","contents":[{"text":"Challenge will start immediately after clicking.","color":"green"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/check/start"}}

execute if score started aihunter_dummy matches 1 run tellraw @s {"text":"<[Cancel Current Challage]>","color":"dark_red","bold":true,"hoverEvent":{"action":"show_text","contents":[{"text":"Current challenge will be cancelled.","color":"dark_red"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/cancel"}}

tellraw @s ""
tellraw @s {"text":"<Settings Menu>","color":"white","underlined":true,"hoverEvent":{"action":"show_text","contents":[{"text":"Go to settings menu, where you can customise your challenge.","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/menu/1"}}


tellraw @s ""
execute if score potato aihunter_dummy matches 0 run tellraw @s [{"text":"<Potato Device Mode: OFF>","color":"red","hoverEvent":{"action":"show_text","contents":[{"text":"If 'ON', you can play with render & simulation distance < 8, although few features may be disabled.","color":"red"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/potato"}}]

execute if score potato aihunter_dummy matches 1 run tellraw @s [{"text":"<Potato Device Mode: ON>","color":"yellow","hoverEvent":{"action":"show_text","contents":[{"text":"If 'ON', you can play with render & simulation distance < 8, although few features may be disabled.","color":"yellow"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/potato"}}]


tellraw @s ""
tellraw @s {"text":"[URL] The pack was inspired by Dream's manhunt videos!","color":"gold","underlined":true,"hoverEvent":{"action":"show_text","contents":[{"text":"Please go see'2 Minecraft Speedrunners VS Terminator' by Dream. (URL To: Youtube.com)","color":"gold"}]},"clickEvent":{"action":"open_url","value":"https://www.youtube.com/watch?v=O60zJzhYGEA&t=1s"}}


tellraw @s ""
tellraw @s {"text":"<Other Credits>","color":"gold","underlined":true,"hoverEvent":{"action":"show_text","contents":[{"text":"Please go see other credits!","color":"gold"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/credits"}}

tellraw @s {"text":"----------------------------------------","color":"aqua","bold":true}
