'use client'

import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { QUALITY } from '@/lib/game/quality'
import { SUN_DIRECTION } from './camera-rig'

// Inside the camera far plane (1600) so the dome is never clipped.
const DOME_RADIUS = 1400

const vertexShader = /* glsl */ `
  varying vec3 vDirection;
  void main() {
    vDirection = normalize(position);
    vec4 world = modelMatrix * vec4(position, 1.0);
    gl_Position = projectionMatrix * viewMatrix * world;
    gl_Position.z = gl_Position.w * 0.99999;
  }
`

const fragmentShader = /* glsl */ `
  precision highp float;

  uniform float uTime;
  uniform vec2 uWind;
  uniform vec3 uSunDir;
  uniform vec3 uCameraPos;
  uniform float uCoverage;
  uniform int uOctaves;

  varying vec3 vDirection;

  const float CLOUD_BASE = 900.0;
  const float CLOUD_THICKNESS = 420.0;

  float hash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
  }

  float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
  }

  float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    mat2 rot = mat2(0.8, -0.6, 0.6, 0.8);
    for (int i = 0; i < 7; i++) {
      if (i >= uOctaves) break;
      value += amplitude * noise(p);
      p = rot * p * 2.03 + 17.1;
      amplitude *= 0.5;
    }
    return value;
  }

  // Domain-warped density gives billowy cumulus edges instead of smooth blobs.
  float density(vec2 world, float evolve) {
    vec2 p = world * 0.0016;
    vec2 warp = vec2(fbm(p * 0.6 + evolve * 0.02), fbm(p * 0.6 + 9.2 - evolve * 0.017));
    float shape = fbm(p + warp * 1.1 + evolve * 0.006);
    float detail = (noise(world * 0.012 + evolve * 0.08) * 0.6 + noise(world * 0.034 - evolve * 0.12) * 0.4) * 0.11;
    float d = shape - detail;
    float low = 0.62 - uCoverage * 0.3;
    return smoothstep(low, low + 0.16, d);
  }

  void main() {
    vec3 dir = normalize(vDirection);
    if (dir.y <= 0.01) discard;

    float t = (CLOUD_BASE - uCameraPos.y) / dir.y;
    vec2 hit = uCameraPos.xz + dir.xz * t;
    vec2 world = hit + uWind * uTime;
    float evolve = uTime;

    float d = density(world, evolve);
    if (d < 0.003) discard;

    // March a few samples toward the sun to estimate self-shadowing through the cloud.
    vec2 sunStep = normalize(uSunDir.xz + 1e-4) * (CLOUD_THICKNESS / max(uSunDir.y, 0.25)) * 0.22;
    float occlusion = 0.0;
    for (int i = 1; i <= 4; i++) {
      occlusion += density(world + sunStep * float(i), evolve);
    }
    float transmittance = exp(-occlusion * 0.9);

    float cosTheta = dot(dir, uSunDir);
    float forward = pow(max(cosTheta, 0.0), 8.0) * 0.9;
    float silver = pow(max(cosTheta, 0.0), 32.0) * (1.0 - d) * 1.6;

    vec3 shadowColor = vec3(0.5, 0.56, 0.67);
    vec3 litColor = vec3(1.0, 0.98, 0.94);
    vec3 sunTint = vec3(1.0, 0.9, 0.72);
    float powder = 1.0 - exp(-d * 4.0);
    vec3 color = mix(shadowColor, litColor, transmittance * mix(0.55, 1.0, powder));
    color += sunTint * (forward + silver) * transmittance;
    // Thicker cores darken underneath like real cumulus bases.
    color *= mix(1.0, 0.82, smoothstep(0.55, 1.0, d) * (1.0 - transmittance));

    float horizonFade = smoothstep(0.02, 0.22, dir.y);
    float alpha = clamp(pow(d, 0.6) * 1.15, 0.0, 0.98) * horizonFade;
    vec3 haze = vec3(0.80, 0.85, 0.90);
    color = mix(haze, color, horizonFade);

    gl_FragColor = vec4(color, alpha);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`

export function Clouds() {
  const mesh = useRef<THREE.Mesh>(null)

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uWind: { value: new THREE.Vector2(9, 3.5) },
      uSunDir: { value: SUN_DIRECTION.clone().normalize() },
      uCameraPos: { value: new THREE.Vector3() },
      uCoverage: { value: 0.72 },
      uOctaves: { value: QUALITY.mobile ? 5 : 7 },
    }),
    [],
  )

  useFrame(({ camera }, delta) => {
    uniforms.uTime.value += Math.min(delta, 0.1)
    uniforms.uCameraPos.value.copy(camera.position)
    mesh.current?.position.copy(camera.position)
  })

  return (
    <mesh ref={mesh} renderOrder={13} frustumCulled={false}>
      <sphereGeometry args={[DOME_RADIUS, 48, 24, 0, Math.PI * 2, 0, Math.PI / 2]} />
      <shaderMaterial
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={uniforms}
        side={THREE.BackSide}
        transparent
        depthWrite={false}
        fog={false}
      />
    </mesh>
  )
}
