##119 block tags
##at the nearest, vertically non-passable block
##all blocks between hunter and this block is passable

#break instant mine-able blocks(only upper 2 blocks)

execute if block ~ ~1 ~ #krushna:aihunter/instant_break_119 run setblock ~ ~1 ~ air destroy

execute if block ~ ~2 ~ #krushna:aihunter/instant_break_119 run setblock ~ ~2 ~ air destroy


#break instant mine-able blocks(only upper 2 blocks)

execute if block ~ ~1 ~ #krushna:aihunter/instant_break run setblock ~ ~1 ~ air destroy

execute if block ~ ~2 ~ #krushna:aihunter/instant_break run setblock ~ ~2 ~ air destroy


#block above (passable) is water waterlogable

execute if block ~ ~1 ~ #krushna:aihunter/waterlogable_119 positioned ~ ~1 ~ run function krushna:aihunter/action/mlg/waterlog


#located block is waterlogable & block above (passable) is not water waterlogable

execute unless block ~ ~1 ~ #krushna:aihunter/waterlogable_119 if block ~ ~ ~ #krushna:aihunter/waterlogable_119 run function krushna:aihunter/action/mlg/waterlog


#located block is not waterlogable & block above (passable) is not water waterlogable

execute unless block ~ ~1 ~ #krushna:aihunter/waterlogable_119 unless block ~ ~ ~ #krushna:aihunter/waterlogable_119 positioned ~ ~1 ~ run function krushna:aihunter/action/mlg/water1