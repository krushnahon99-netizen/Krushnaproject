#krushna:aihunter/win must be executed first

execute if score started aihunter_dummy matches 1 if score wincondition aihunter_dummy matches 4 run function krushna:aihunter/win

advancement revoke @s only krushna:aihunter/win/warden


tellraw @s {"text":"Legendary Cookie.","bold":true,"italic":false,"color":"aqua"}

give @s cookie[minecraft:custom_name='{"text":"Legendary Cookie","bold":true,"italic":false}',minecraft:lore=['{"text":"In commemoration of one of the best AI Manhunter,","color":"dark_gray","italic":false}','[{"text":"ItsOreo","color":"white","italic":false},{"text":" and his Maihunt journey (he is still alive)","color":"dark_gray"}]'],minecraft:enchantments={}] 400