##as at @e[type=minecraft:vindicator,tag=aihunter]
#cannot be grouped

execute unless score @s aihunter_fall matches ..-1 store result score @s aihunter_fall run data get entity @s fall_distance 10

execute if score @s aihunter_fall matches 25.. positioned ~ ~-0.5 ~ unless block ~ ~ ~ #krushna:aihunter/passable_117 run function krushna:aihunter/action/mlg/check

execute if score @s aihunter_fall matches 25.. positioned ~ ~-1 ~ unless block ~ ~ ~ #krushna:aihunter/passable_117 run function krushna:aihunter/action/mlg/check

execute if score @s aihunter_fall matches 25.. positioned ~ ~-1.5 ~ unless block ~ ~ ~ #krushna:aihunter/passable_117 run function krushna:aihunter/action/mlg/check

execute if score @s aihunter_fall matches 25.. positioned ~ ~-2 ~ unless block ~ ~ ~ #krushna:aihunter/passable_117 run function krushna:aihunter/action/mlg/check

execute if score @s aihunter_fall matches 25.. positioned ~ ~-2.5 ~ unless block ~ ~ ~ #krushna:aihunter/passable_117 run function krushna:aihunter/action/mlg/check

execute if score @s aihunter_fall matches ..-1 run scoreboard players add @s aihunter_fall 1