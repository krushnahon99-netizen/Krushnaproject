schedule clear krushna:aihunter/message/10s

schedule clear krushna:aihunter/message/30s

schedule clear krushna:aihunter/message/cross