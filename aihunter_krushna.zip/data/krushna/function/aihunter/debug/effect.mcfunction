effect give krushna minecraft:night_vision 1000000 0 true

effect give krushna minecraft:resistance 1000000 4 true

effect give krushna minecraft:saturation 1000000 0 true