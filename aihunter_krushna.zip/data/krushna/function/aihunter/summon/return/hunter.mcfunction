#attacker

execute store result score wdiff aihunter_dummy run difficulty
execute if score wdiff aihunter_dummy matches 0 run difficulty easy


execute unless score @s aihunter_upgrade matches 1.. run summon minecraft:vindicator ~ ~ ~ {Health:20f,Silent:1b,Invisible:1b,PortalCooldown:9000000,DeathLootTable:"/",PersistenceRequired:1b,CanPickUpLoot:0b,Tags:["aihunter"],CustomNameVisible:0b,Team:"aihunter",HandItems:[{},{}],HandDropChances:[-327.670F,0.085F],active_effects:[{id:"minecraft:blindness",amplifier:99,duration:2,show_particles:false}],attributes:[{id:"minecraft:max_health",base:20},{id:"minecraft:knockback_resistance",base:0.15},{id:"minecraft:movement_speed",base:0},{id:"minecraft:attack_damage",base:1},{id:"minecraft:armor",base:0},{id:"minecraft:follow_range",base:6}] }


execute if score @s aihunter_upgrade matches 1 run summon minecraft:vindicator ~ ~ ~ {Health:20f,Silent:1b,Invisible:1b,PortalCooldown:9000000,DeathLootTable:"/",PersistenceRequired:1b,CanPickUpLoot:0b,Tags:["aihunter"],CustomNameVisible:0b,Team:"aihunter",HandItems:[{},{}],HandDropChances:[-327.670F,0.085F],active_effects:[{id:"minecraft:blindness",amplifier:99,duration:2,show_particles:false}],attributes:[{id:"minecraft:max_health",base:20},{id:"minecraft:knockback_resistance",base:0.15},{id:"minecraft:movement_speed",base:0},{id:"minecraft:attack_damage",base:1},{id:"minecraft:armor",base:0},{id:"minecraft:follow_range",base:6}] }


execute if score @s aihunter_upgrade matches 2 run summon minecraft:vindicator ~ ~ ~ {Health:20f,Silent:1b,Invisible:1b,PortalCooldown:9000000,DeathLootTable:"/",PersistenceRequired:1b,CanPickUpLoot:0b,Tags:["aihunter"],CustomNameVisible:0b,Team:"aihunter",HandItems:[{},{}],HandDropChances:[-327.670F,0.085F],active_effects:[{id:"minecraft:blindness",amplifier:99,duration:2,show_particles:false}],attributes:[{id:"minecraft:max_health",base:20},{id:"minecraft:knockback_resistance",base:0.15},{id:"minecraft:movement_speed",base:0},{id:"minecraft:attack_damage",base:1},{id:"minecraft:armor",base:8},{id:"minecraft:follow_range",base:6}] }


execute if score @s aihunter_upgrade matches 3 run summon minecraft:vindicator ~ ~ ~ {Health:20f,Silent:1b,Invisible:1b,PortalCooldown:9000000,DeathLootTable:"/",PersistenceRequired:1b,CanPickUpLoot:0b,Tags:["aihunter"],CustomNameVisible:0b,Team:"aihunter",HandItems:[{},{}],HandDropChances:[-327.670F,0.085F],active_effects:[{id:"minecraft:blindness",amplifier:99,duration:2,show_particles:false}],attributes:[{id:"minecraft:max_health",base:20},{id:"minecraft:knockback_resistance",base:0.15},{id:"minecraft:movement_speed",base:0},{id:"minecraft:attack_damage",base:1},{id:"minecraft:armor",base:15},{id:"minecraft:follow_range",base:6}] }


execute if score @s aihunter_upgrade matches 4 run summon minecraft:vindicator ~ ~ ~ {Health:20f,Silent:1b,Invisible:1b,PortalCooldown:9000000,DeathLootTable:"/",PersistenceRequired:1b,CanPickUpLoot:0b,Tags:["aihunter"],CustomNameVisible:0b,Team:"aihunter",HandItems:[{},{}],HandDropChances:[-327.670F,0.085F],active_effects:[{id:"minecraft:blindness",amplifier:99,duration:2,show_particles:false}],attributes:[{id:"minecraft:max_health",base:20},{id:"minecraft:knockback_resistance",base:0.15},{id:"minecraft:movement_speed",base:0},{id:"minecraft:attack_damage",base:1},{id:"minecraft:armor",base:18},{id:"minecraft:follow_range",base:6},{id:"minecraft:armor_toughness",base:4}] }

execute if score @s aihunter_upgrade matches 5 run summon minecraft:vindicator ~ ~ ~ {Health:20f,Silent:1b,Invisible:1b,PortalCooldown:9000000,DeathLootTable:"/",PersistenceRequired:1b,CanPickUpLoot:0b,Tags:["aihunter"],CustomNameVisible:0b,Team:"aihunter",HandItems:[{},{}],HandDropChances:[-327.670F,0.085F],active_effects:[{id:"minecraft:blindness",amplifier:99,duration:2,show_particles:false}],attributes:[{id:"minecraft:max_health",base:20},{id:"minecraft:knockback_resistance",base:0.15},{id:"minecraft:movement_speed",base:0},{id:"minecraft:attack_damage",base:1},{id:"minecraft:armor",base:20},{id:"minecraft:follow_range",base:6},{id:"minecraft:armor_toughness",base:8}] }

execute if score @s aihunter_upgrade matches 6.. run summon minecraft:vindicator ~ ~ ~ {Health:20f,Silent:1b,Invisible:1b,PortalCooldown:9000000,DeathLootTable:"/",PersistenceRequired:1b,CanPickUpLoot:0b,Tags:["aihunter"],CustomNameVisible:0b,Team:"aihunter",HandItems:[{},{}],HandDropChances:[-327.670F,0.085F],active_effects:[{id:"minecraft:blindness",amplifier:99,duration:2,show_particles:false}],attributes:[{id:"minecraft:max_health",base:20},{id:"minecraft:knockback_resistance",base:0.15},{id:"minecraft:movement_speed",base:0},{id:"minecraft:attack_damage",base:1},{id:"minecraft:armor",base:20},{id:"minecraft:follow_range",base:6},{id:"minecraft:armor_toughness",base:12}] }


#stand

function krushna:aihunter/summon/stand
# Spawn floating name tag
