'use client'

import { useEffect, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { useAnimations, useGLTF } from '@react-three/drei'
import * as THREE from 'three'
import { game } from '@/lib/game/state'

const MODEL_URL = '/models/character.glb'

// Native ground speed (m/s) each clip was authored at, so playback rate matches movement and feet don't slide.
const WALK_CLIP_SPEED = 2.1
const RUN_CLIP_SPEED = 6.2

const clamp01 = (v: number) => Math.min(1, Math.max(0, v))
const smooth = (v: number) => v * v * (3 - 2 * v)

export function PlayerModel() {
  const root = useRef<THREE.Group>(null)
  const body = useRef<THREE.Group>(null)
  const { scene, animations } = useGLTF(MODEL_URL)
  const { actions } = useAnimations(animations, body)
  const lastHeading = useRef(0)
  const lean = useRef(0)

  useEffect(() => {
    scene.traverse((obj) => {
      const mesh = obj as THREE.SkinnedMesh
      if (!mesh.isMesh) return
      mesh.castShadow = true
      mesh.receiveShadow = true
      mesh.frustumCulled = false
      const material = mesh.material as THREE.MeshStandardMaterial
      if (material.isMeshStandardMaterial) {
        material.envMapIntensity = 0.9
        material.needsUpdate = true
      }
    })
  }, [scene])

  useEffect(() => {
    const clips = ['Idle', 'Walk', 'Run', 'Sit', 'Reach'] as const
    for (const name of clips) {
      const action = actions[name]
      if (!action) continue
      action.reset().setLoop(THREE.LoopRepeat, Infinity).play()
      action.setEffectiveWeight(name === 'Idle' ? 1 : 0)
    }
    return () => {
      for (const name of clips) actions[name]?.stop()
    }
  }, [actions])

  useFrame((_, delta) => {
    const group = root.current
    if (!group) return
    const p = game.player
    group.position.set(p.x, p.y, p.z)
    group.rotation.y = p.heading

    const idle = actions.Idle
    const walk = actions.Walk
    const run = actions.Run
    const sit = actions.Sit
    const reach = actions.Reach
    if (!idle || !walk || !run) return

    const posed = clamp01(p.sit + p.reach)
    const free = 1 - posed
    const speed = Math.abs(p.speed)
    const backwards = p.speed < -0.1
    const airborne = posed === 0 && p.vy !== 0 && p.y > 0.05

    const moveW = smooth(clamp01(speed / 1.6))
    const runW = smooth(clamp01((speed - 4.8) / 2.6))
    idle.setEffectiveWeight((1 - moveW) * free)
    walk.setEffectiveWeight(moveW * (1 - runW) * free)
    run.setEffectiveWeight(moveW * runW * free)
    sit?.setEffectiveWeight(p.sit)
    reach?.setEffectiveWeight(p.reach)

    const direction = backwards ? -1 : 1
    walk.setEffectiveTimeScale(direction * Math.max(0.6, speed / WALK_CLIP_SPEED))
    run.setEffectiveTimeScale(direction * Math.max(0.7, speed / RUN_CLIP_SPEED))

    // Keep walk and run cycles phase-locked so the blend never crosses its feet.
    if (runW > 0 && runW < 1) {
      const leader = runW > 0.5 ? run : walk
      const follower = runW > 0.5 ? walk : run
      const phase = leader.time / leader.getClip().duration
      follower.time = phase * follower.getClip().duration
    }

    // Freeze mid-stride while in the air for a natural jump pose.
    const airScale = airborne ? 0.15 : 1
    walk.timeScale *= airScale
    run.timeScale *= airScale

    let turnRate = (p.heading - lastHeading.current) / Math.max(delta, 1e-4)
    turnRate = Math.atan2(Math.sin(turnRate), Math.cos(turnRate))
    lastHeading.current = p.heading
    const targetLean = THREE.MathUtils.clamp(-turnRate * 0.04 * (speed / 6), -0.22, 0.22) * free
    lean.current += (targetLean - lean.current) * Math.min(1, delta * 8)
    if (body.current) {
      body.current.rotation.z = lean.current
      body.current.rotation.x = (airborne ? -0.08 : runW * 0.06) * free
    }
  })

  return (
    <group ref={root}>
      <group ref={body}>
        <primitive object={scene} />
      </group>
    </group>
  )
}

useGLTF.preload(MODEL_URL)
