import { Smartphone } from 'lucide-react'

export function RotateOverlay() {
  return (
    <div
      role="alert"
      className="fixed inset-0 z-50 hidden flex-col items-center justify-center gap-5 bg-black px-8 text-center text-white [@media(orientation:portrait)_and_(pointer:coarse)]:flex"
    >
      <Smartphone aria-hidden="true" className="size-14 animate-[spin_2.4s_ease-in-out_infinite] text-[#ff4f87]" />
      <h2 className="font-display text-4xl tracking-wide">ROTATE YOUR DEVICE</h2>
      <p className="max-w-xs text-sm leading-relaxed text-white/70">
        Vice Shores plays in landscape. Turn your phone sideways to keep playing.
      </p>
    </div>
  )
}
