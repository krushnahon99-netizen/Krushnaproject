import * as THREE from 'three'

/**
 * Shared, tuned materials for the baked car models. The bake writes canonical material names;
 * every car swaps them for these instances so draw state is shared across the whole city.
 */
const physical = (params: THREE.MeshPhysicalMaterialParameters) => new THREE.MeshPhysicalMaterial(params)
const standard = (params: THREE.MeshStandardMaterialParameters) => new THREE.MeshStandardMaterial(params)

export const SHARED_CAR_MATERIALS: Record<string, THREE.Material> = {
  glass: physical({
    color: '#0c1116',
    roughness: 0.02,
    metalness: 0,
    envMapIntensity: 2.2,
    transparent: true,
    opacity: 0.58,
    depthWrite: false,
    clearcoat: 1,
    clearcoatRoughness: 0,
  }),
  darkGlass: physical({ color: '#06080a', roughness: 0.04, metalness: 0.35, clearcoat: 1, clearcoatRoughness: 0, envMapIntensity: 2 }),
  lens: physical({
    color: '#e8edf2',
    roughness: 0,
    metalness: 0,
    transparent: true,
    opacity: 0.18,
    depthWrite: false,
    clearcoat: 1,
    envMapIntensity: 2.5,
  }),
  chrome: standard({ color: '#eceef1', roughness: 0.06, metalness: 1, envMapIntensity: 2 }),
  metal: standard({ color: '#8d9095', roughness: 0.32, metalness: 1, envMapIntensity: 1.4 }),
  black: physical({ color: '#060607', roughness: 0.2, metalness: 0.2, clearcoat: 0.8, clearcoatRoughness: 0.08, envMapIntensity: 1.2 }),
  plastic: standard({ color: '#0c0c0d', roughness: 0.72, metalness: 0, envMapIntensity: 0.6 }),
  rubber: standard({ color: '#121213', roughness: 0.94, metalness: 0, envMapIntensity: 0.35 }),
  rim: standard({ color: '#c9ccd1', roughness: 0.2, metalness: 1, envMapIntensity: 1.7 }),
  brake: standard({ color: '#55575b', roughness: 0.45, metalness: 1, envMapIntensity: 1 }),
  caliper: standard({ color: '#b5141a', roughness: 0.32, metalness: 0.15, envMapIntensity: 1 }),
  interior: standard({ color: '#151516', roughness: 0.78, metalness: 0, envMapIntensity: 0.5 }),
  accent: standard({ color: '#5a1214', roughness: 0.6, metalness: 0, envMapIntensity: 0.5 }),
  headlight: standard({
    color: '#ffffff',
    emissive: new THREE.Color('#fff4e2'),
    emissiveIntensity: 2.2,
    roughness: 0.1,
    toneMapped: false,
  }),
  indicator: standard({ color: '#ff8a1a', emissive: new THREE.Color('#ff7a10'), emissiveIntensity: 0.6, roughness: 0.2 }),
}

/** Additive light throw on the road ahead of every car; its opacity follows the time of day. */
export const HEADLIGHT_BEAM_MATERIAL = new THREE.MeshBasicMaterial({
  color: '#fff1d6',
  transparent: true,
  opacity: 0,
  blending: THREE.AdditiveBlending,
  depthWrite: false,
  toneMapped: false,
  polygonOffset: true,
  polygonOffsetFactor: -2,
})

const paints = new Map<string, THREE.MeshPhysicalMaterial>()

/** Automotive paint: metallic base under a mirror clearcoat. Cached per colour. */
export function paintMaterial(color: string, metallic: boolean) {
  const key = `${color}|${metallic}`
  let mat = paints.get(key)
  if (!mat) {
    mat = physical({
      color,
      metalness: metallic ? 0.62 : 0.08,
      roughness: metallic ? 0.34 : 0.42,
      clearcoat: 1,
      clearcoatRoughness: 0.025,
      envMapIntensity: 1.35,
    })
    paints.set(key, mat)
  }
  return mat
}

/** Taillights are per car so each one can light up its own brake lamps. */
export function createTaillightMaterial() {
  return standard({
    color: '#4a0606',
    emissive: new THREE.Color('#ff1a0e'),
    emissiveIntensity: 0.7,
    roughness: 0.12,
    toneMapped: false,
  })
}
