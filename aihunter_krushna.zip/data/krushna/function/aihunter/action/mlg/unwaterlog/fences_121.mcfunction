execute if block ~ ~ ~ minecraft:pale_oak_fence[waterlogged=true] run setblock ~ ~ ~ minecraft:pale_oak_fence[waterlogged=false] replace
