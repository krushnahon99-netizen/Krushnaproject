scoreboard players add @s aihunter_busy 5

data merge entity @s {HandItems:[{id:"minecraft:potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:long_fire_resistance"}}},{}]}

data merge entity @e[type=minecraft:armor_stand,tag=aihunter,limit=1,sort=nearest] {HandItems:[{id:"minecraft:potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:long_fire_resistance"}}},{}]}

execute if score debug aihunter_dummy matches 1 run say potion: fire resistance
