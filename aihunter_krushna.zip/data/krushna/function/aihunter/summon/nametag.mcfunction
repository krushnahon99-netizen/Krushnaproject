# Runs as armor_stand at armor_stand position
# Summon text_display with unique temp tag
summon minecraft:text_display ~ ~ ~ {Tags:["aihunter_name","aihunter_name_new"],text:"Hunter",billboard:"center",view_range:128.0f,transformation:{translation:[0f,0.3f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f]}}

# Mount onto the nearest vindicator (no distance limit - works after spreadplayers too)
ride @e[type=minecraft:text_display,tag=aihunter_name_new,limit=1,sort=nearest] mount @e[type=minecraft:vindicator,tag=aihunter,limit=1,sort=nearest]

# Clean up temp tag
tag @e[type=minecraft:text_display,tag=aihunter_name_new] remove aihunter_name_new
