
execute unless score @s aihunter_busy matches 1.. if score @s aihunter_y2 matches ..56999 unless predicate krushna:aihunter/dimension/end run function krushna:aihunter/action/break/down


execute if score @s aihunter_d matches ..110 if score @s aihunter_dy matches 3000.. if score @s aihunter_intent matches 0 run function krushna:aihunter/action/build/tower


execute unless score @s aihunter_busy matches 1.. run function krushna:aihunter/find/action/surface/facing