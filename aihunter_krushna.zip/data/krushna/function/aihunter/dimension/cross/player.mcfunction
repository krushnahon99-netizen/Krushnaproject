advancement revoke @s only krushna:aihunter/dimension

execute if score started aihunter_dummy matches 1 if entity @s[gamemode=!creative,gamemode=!spectator,team=!aihunter] run function krushna:aihunter/dimension/cross/identify