execute if score @s aihunter_upgrade matches 1 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] {HandItems:[{id:"minecraft:wooden_axe",count:1},{}]}

execute if score @s aihunter_upgrade matches 2 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] {HandItems:[{id:"minecraft:stone_axe",count:1},{}]}

execute if score @s aihunter_upgrade matches 3 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] {HandItems:[{id:"minecraft:iron_axe",count:1},{}]}

execute if score @s aihunter_upgrade matches 4 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] {HandItems:[{id:"minecraft:diamond_axe",count:1},{}]}

execute if score @s aihunter_upgrade matches 5 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] {HandItems:[{id:"minecraft:diamond_axe",count:1},{}]}

execute if score @s aihunter_upgrade matches 6.. run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] {HandItems:[{id:"minecraft:netherite_axe",count:1},{}]}


execute if score @s aihunter_upgrade matches 1 run data merge entity @s {HandItems:[{id:"minecraft:wooden_axe",count:1},{}]}

execute if score @s aihunter_upgrade matches 2 run data merge entity @s {HandItems:[{id:"minecraft:stone_axe",count:1},{}]}

execute if score @s aihunter_upgrade matches 3 run data merge entity @s {HandItems:[{id:"minecraft:iron_axe",count:1},{}]}

execute if score @s aihunter_upgrade matches 4 run data merge entity @s {HandItems:[{id:"minecraft:diamond_axe",count:1},{}]}

execute if score @s aihunter_upgrade matches 5 run data merge entity @s {HandItems:[{id:"minecraft:diamond_axe",count:1},{}]}

execute if score @s aihunter_upgrade matches 6.. run data merge entity @s {HandItems:[{id:"minecraft:netherite_axe",count:1},{}]}


effect give @s minecraft:weakness 1 0 true

scoreboard players add @s aihunter_busy 4

scoreboard players set @s aihunter_weapon 0

execute if score debug aihunter_dummy matches 1 run say axe