let ready = false
const listeners = new Set<() => void>()

/** Flips once every model, texture and shader has been uploaded and compiled on the GPU. */
export const sceneReadyStore = {
  subscribe(listener: () => void) {
    listeners.add(listener)
    return () => listeners.delete(listener)
  },
  getSnapshot: () => ready,
  getServerSnapshot: () => false,
}

export function markSceneReady() {
  if (ready) return
  ready = true
  listeners.forEach((listener) => listener())
}
