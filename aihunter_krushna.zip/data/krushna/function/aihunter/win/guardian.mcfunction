#krushna:aihunter/win must be executed first

execute if score started aihunter_dummy matches 1 if score wincondition aihunter_dummy matches 3 run function krushna:aihunter/win

advancement revoke @s only krushna:aihunter/win/guardian