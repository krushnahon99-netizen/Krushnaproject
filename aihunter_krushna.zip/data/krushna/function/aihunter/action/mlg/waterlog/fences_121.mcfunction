execute if block ~ ~ ~ minecraft:pale_oak_fence[waterlogged=false] run setblock ~ ~ ~ minecraft:pale_oak_fence[waterlogged=true] replace
