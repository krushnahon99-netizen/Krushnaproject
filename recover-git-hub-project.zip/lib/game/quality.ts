export type QualityTier = {
  mobile: boolean
  maxDpr: number
  minDpr: number
  shadowMapSize: number
  shadowExtent: number
  softShadows: boolean
  postFx: boolean
  bounceLight: boolean
  ambientOcclusion: boolean
  antialiasPass: boolean
  anisotropy: number
}

function detectMobile() {
  if (typeof window === 'undefined') return false
  const forced = new URLSearchParams(window.location.search).get('mobile')
  if (forced === '1') return true
  if (forced === '0') return false
  const coarse = window.matchMedia?.('(pointer: coarse)').matches ?? false
  const ua = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)
  return coarse || ua
}

const mobile = detectMobile()

export const QUALITY: QualityTier = mobile
  ? {
      mobile,
      maxDpr: 4,
      minDpr: 2,
      shadowMapSize: 2048,
      shadowExtent: 50,
      softShadows: false,
      postFx: false,
      bounceLight: false,
      ambientOcclusion: false,
      antialiasPass: false,
      anisotropy: 4,
    }
  : {
      mobile,
      maxDpr: 3,
      minDpr: 1,
      shadowMapSize: 4096,
      shadowExtent: 85,
      softShadows: true,
      postFx: true,
      bounceLight: true,
      ambientOcclusion: true,
      antialiasPass: true,
      anisotropy: 16,
    }
