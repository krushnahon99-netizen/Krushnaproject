'use client'

import { useEffect, useRef, useSyncExternalStore, type ReactNode } from 'react'
import { ArrowBigUp, ChevronDown, ChevronUp, DoorOpen, Footprints, Hand, Zap } from 'lucide-react'
import { hudStore, input } from '@/lib/game/state'
import { cn } from '@/lib/utils'

type HoldKey = 'forward' | 'back' | 'left' | 'right' | 'handbrake' | 'sprint'

const STICK_RADIUS = 56
const DEAD_ZONE = 0.12

let touchSeen = false

function subscribeTouch(onChange: () => void) {
  const query = window.matchMedia('(any-pointer: coarse)')
  const onTouch = () => {
    touchSeen = true
    onChange()
  }
  query.addEventListener('change', onChange)
  window.addEventListener('touchstart', onTouch, { passive: true })
  return () => {
    query.removeEventListener('change', onChange)
    window.removeEventListener('touchstart', onTouch)
  }
}

function isTouchDevice() {
  return touchSeen || navigator.maxTouchPoints > 0 || window.matchMedia('(any-pointer: coarse)').matches
}

export function useIsTouchDevice() {
  return useSyncExternalStore(subscribeTouch, isTouchDevice, () => false)
}

function resetStick() {
  input.stickActive = false
  input.stickX = 0
  input.stickY = 0
}

function Joystick() {
  const zone = useRef<HTMLDivElement>(null)
  const base = useRef<HTMLDivElement>(null)
  const knob = useRef<HTMLDivElement>(null)
  const active = useRef<{ id: number; x: number; y: number } | null>(null)

  useEffect(() => resetStick, [])

  const placeBase = (x: number, y: number) => {
    const rect = zone.current?.getBoundingClientRect()
    if (!rect || !base.current) return
    base.current.style.left = `${x - rect.left}px`
    base.current.style.top = `${y - rect.top}px`
  }

  const moveKnob = (dx: number, dy: number) => {
    if (knob.current) knob.current.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`
  }

  const release = (pointerId: number) => {
    if (active.current?.id !== pointerId) return
    active.current = null
    resetStick()
    moveKnob(0, 0)
    base.current?.removeAttribute('data-active')
    if (base.current) {
      base.current.style.left = ''
      base.current.style.top = ''
    }
  }

  return (
    <div
      ref={zone}
      role="application"
      aria-label="Movement joystick. Drag to move."
      className="pointer-events-auto absolute bottom-0 left-0 h-[60%] w-[48%] touch-none select-none"
      onPointerDown={(e) => {
        if (active.current) return
        e.currentTarget.setPointerCapture(e.pointerId)
        active.current = { id: e.pointerId, x: e.clientX, y: e.clientY }
        placeBase(e.clientX, e.clientY)
        base.current?.setAttribute('data-active', '')
        input.stickActive = true
      }}
      onPointerMove={(e) => {
        const start = active.current
        if (start?.id !== e.pointerId) return
        let dx = e.clientX - start.x
        let dy = e.clientY - start.y
        const distance = Math.hypot(dx, dy)
        if (distance > STICK_RADIUS) {
          dx = (dx / distance) * STICK_RADIUS
          dy = (dy / distance) * STICK_RADIUS
        }
        moveKnob(dx, dy)
        const nx = dx / STICK_RADIUS
        const ny = -dy / STICK_RADIUS
        const amount = Math.hypot(nx, ny)
        if (amount < DEAD_ZONE) {
          input.stickX = 0
          input.stickY = 0
          return
        }
        const scaled = (amount - DEAD_ZONE) / (1 - DEAD_ZONE) / amount
        input.stickX = nx * scaled
        input.stickY = ny * scaled
      }}
      onPointerUp={(e) => release(e.pointerId)}
      onPointerCancel={(e) => release(e.pointerId)}
      onLostPointerCapture={(e) => release(e.pointerId)}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div
        ref={base}
        className="absolute left-[100px] top-[calc(100%-100px)] -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white/30 bg-black/35 opacity-70 backdrop-blur-sm transition-opacity data-[active]:opacity-100"
        style={{ width: STICK_RADIUS * 2 + 16, height: STICK_RADIUS * 2 + 16 }}
      >
        <div className="absolute inset-3 rounded-full border border-white/10" />
        <div
          ref={knob}
          className="absolute left-1/2 top-1/2 size-14 rounded-full border border-white/50 bg-white/85 shadow-lg shadow-black/40"
          style={{ transform: 'translate(-50%, -50%)' }}
        />
      </div>
    </div>
  )
}

function HoldButton({ keys, label, children, className }: { keys: HoldKey[]; label: string; children: ReactNode; className?: string }) {
  const set = (value: boolean) => keys.forEach((key) => (input[key] = value))
  return (
    <button
      type="button"
      aria-label={label}
      className={cn(
        'pointer-events-auto flex size-16 touch-none select-none flex-col items-center justify-center gap-0.5 rounded-full border border-white/25 bg-black/45 text-white backdrop-blur-sm active:scale-95 active:bg-white/30',
        className,
      )}
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId)
        set(true)
      }}
      onPointerUp={() => set(false)}
      onPointerCancel={() => set(false)}
      onLostPointerCapture={() => set(false)}
      onContextMenu={(e) => e.preventDefault()}
    >
      {children}
    </button>
  )
}

function ButtonLabel({ children }: { children: ReactNode }) {
  return <span className="text-[9px] font-semibold uppercase leading-none tracking-wide text-white/80">{children}</span>
}

export function TouchControls() {
  const hud = useSyncExternalStore(hudStore.subscribe, hudStore.getSnapshot, hudStore.getServerSnapshot)
  const touch = useIsTouchDevice()
  if (!hud.started || !touch) return null
  const inCar = hud.mode === 'car'

  return (
    <div className="pointer-events-none fixed inset-0 z-20 [padding-left:env(safe-area-inset-left)] [padding-right:env(safe-area-inset-right)]">
      <p className="absolute left-1/2 top-14 flex -translate-x-1/2 items-center gap-1.5 whitespace-nowrap rounded-full bg-black/40 px-3 py-1 text-[11px] font-medium text-white/75 backdrop-blur-sm">
        <Hand className="size-3.5" aria-hidden="true" />
        {inCar ? 'Stick: steer + gas · Drag right side to look' : 'Stick: move · Drag right side to look'}
      </p>

      <Joystick key={hud.mode} />

      <div className="absolute bottom-5 right-4 flex items-end gap-3 [margin-right:env(safe-area-inset-right)]">
        <div className="flex flex-col items-center gap-3">
          <button
            type="button"
            aria-label={inCar ? 'Exit vehicle' : 'Enter vehicle'}
            className="pointer-events-auto flex size-14 touch-none select-none flex-col items-center justify-center gap-0.5 rounded-full border border-white/25 bg-[#e0457b]/85 text-white active:scale-95"
            onPointerDown={() => (input.interactQueued = true)}
          >
            <DoorOpen className="size-5" aria-hidden="true" />
            <ButtonLabel>{inCar ? 'Exit' : 'Enter'}</ButtonLabel>
          </button>
          <HoldButton keys={['handbrake']} label={inCar ? 'Handbrake' : 'Jump'} className="size-14">
            {inCar ? <Zap className="size-5" aria-hidden="true" /> : <ArrowBigUp className="size-5" aria-hidden="true" />}
            <ButtonLabel>{inCar ? 'Drift' : 'Jump'}</ButtonLabel>
          </HoldButton>
        </div>
        {inCar ? (
          <div className="flex flex-col gap-3">
            <HoldButton keys={['forward']} label="Accelerate">
              <ChevronUp className="size-7" aria-hidden="true" />
              <ButtonLabel>Gas</ButtonLabel>
            </HoldButton>
            <HoldButton keys={['back']} label="Brake or reverse">
              <ChevronDown className="size-7" aria-hidden="true" />
              <ButtonLabel>Brake</ButtonLabel>
            </HoldButton>
          </div>
        ) : (
          <HoldButton keys={['sprint']} label="Sprint" className="size-20">
            <Footprints className="size-7" aria-hidden="true" />
            <ButtonLabel>Sprint</ButtonLabel>
          </HoldButton>
        )}
      </div>
    </div>
  )
}
