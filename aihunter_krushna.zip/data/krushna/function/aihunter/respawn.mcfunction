scoreboard players set #checkcd aihunter_dummy 40

execute if score dimension aihunter_dummy matches 2 run function krushna:aihunter/summon/clear

function krushna:aihunter/summon/attacker

effect give @e[type=minecraft:vindicator,tag=aihunter] minecraft:invisibility 999999 0 true

execute as @e[type=minecraft:vindicator,tag=aihunter,predicate=krushna:aihunter/fresh] run function krushna:aihunter/summon/set

# Equip armor on fresh armor stands
execute as @e[type=minecraft:armor_stand,tag=aihunter,limit=1,sort=nearest] run function krushna:aihunter/summon/set_buff

# Spawn nametag if missing
execute as @e[type=minecraft:armor_stand,tag=aihunter] at @s unless entity @e[type=minecraft:text_display,tag=aihunter_name,distance=..4] run function krushna:aihunter/summon/nametag

title @a actionbar {"text":" A Hunter has fallen","color":"yellow"}

execute if score debug aihunter_dummy matches 1 run say respawn