advancement revoke @s only krushna:aihunter/kill

execute unless score store aihunter_dummy matches 0.. at @a run playsound minecraft:entity.player.levelup master @a ~ ~ ~ 1 2

schedule function krushna:aihunter/xp 1t