scoreboard players set version aihunter_dummy 116

function krushna:aihunter/check/version/117

function krushna:aihunter/check/version/118

function krushna:aihunter/check/version/119

function krushna:aihunter/check/version/120

tellraw @s [{"text":"MC Version:"},{"score":{"name":"version","objective":"aihunter_dummy"},"color":"white"},{"text":"X"}]
function krushna:aihunter/check/version/121
