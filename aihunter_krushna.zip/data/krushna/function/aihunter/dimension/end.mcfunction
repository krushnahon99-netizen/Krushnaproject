##^aihunter/always
##as at server

#execute as @p[predicate=krushna:aihunter/dimension/end] at @s unless entity @e[type=minecraft:area_effect_cloud,tag=aihunter_end_spawn] run function krushna:aihunter/dimension/aec

execute at @e[type=minecraft:area_effect_cloud,tag=aihunter_end_spawn,limit=1] run function krushna:aihunter/check/respawn