export type QualityTier = {
  mobile: boolean
  maxDpr: number
  shadowMapSize: number
  softShadows: boolean
  ambientOcclusion: boolean
  antialiasPass: boolean
  anisotropy: number
}

function detectMobile() {
  if (typeof window === 'undefined') return false
  const forced = new URLSearchParams(window.location.search).get('mobile')
  if (forced === '1') return true
  if (forced === '0') return false
  const coarse = window.matchMedia?.('(pointer: coarse)').matches ?? false
  const ua = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)
  return coarse || ua
}

const mobile = detectMobile()

export const QUALITY: QualityTier = mobile
  ? { mobile, maxDpr: 2, shadowMapSize: 2048, softShadows: false, ambientOcclusion: false, antialiasPass: false, anisotropy: 8 }
  : { mobile, maxDpr: 2, shadowMapSize: 4096, softShadows: true, ambientOcclusion: true, antialiasPass: true, anisotropy: 16 }
