/**
 * Bakes the source car models into game-ready GLBs.
 *
 * Sources (all CC-BY 4.0, see CAR_CREDITS in lib/game/cars.ts):
 *   ferrari.glb  three.js examples, "Ferrari 458 Italia" by vicent091036
 *   lambo.glb    pmndrs/examples, "Lamborghini Urus" by Steven Grey
 *   porsche.glb  pmndrs/examples, "Porsche 911 930 Turbo" by Lionsharp Studios
 *
 * For every car this normalises orientation (+z forward, +x driver side), scale and ground height,
 * maps every source material onto a shared set of canonical materials, merges geometry per material,
 * splits the four wheels around their real hub pivots, and writes three levels of detail:
 *   <name>-lod0.glb  full detail (near)
 *   <name>-lod1.glb  "lod1" (mid distance, no interior) and "lod2" (far, static wheels) groups
 *
 * Usage: node tools/bake-cars.mjs <source-dir>
 * Then run `node tools/rebuild-car-lods.mjs` to regenerate the lod1 file with clean normals.
 */
import { Document } from '@gltf-transform/core'
import { KHRMaterialsClearcoat } from '@gltf-transform/extensions'
import { meshopt, prune, dedup } from '@gltf-transform/functions'
import { MeshoptEncoder, MeshoptSimplifier } from 'meshoptimizer'
import * as THREE from 'three'
import path from 'node:path'
import fs from 'node:fs'
import { getIO, loadParts } from './car-source.mjs'

const SOURCE_DIR = process.argv[2] ?? '/tmp/cars'
const OUT_DIR = path.resolve('public/models/cars')

/** Canonical materials. Runtime swaps these by name for shared, tuned instances. */
const MATERIALS = {
  paint: { color: [0.6, 0.02, 0.03], metal: 0.6, rough: 0.3 },
  glass: { color: [0.02, 0.03, 0.04], metal: 0, rough: 0.05, alpha: 0.55 },
  darkGlass: { color: [0.01, 0.01, 0.012], metal: 0.2, rough: 0.05 },
  lens: { color: [0.9, 0.92, 0.95], metal: 0, rough: 0.02, alpha: 0.25 },
  chrome: { color: [0.92, 0.92, 0.93], metal: 1, rough: 0.08 },
  metal: { color: [0.55, 0.56, 0.58], metal: 1, rough: 0.35 },
  black: { color: [0.015, 0.015, 0.017], metal: 0.3, rough: 0.25 },
  plastic: { color: [0.03, 0.03, 0.032], metal: 0, rough: 0.7 },
  rubber: { color: [0.025, 0.025, 0.027], metal: 0, rough: 0.92 },
  rim: { color: [0.75, 0.76, 0.78], metal: 1, rough: 0.22 },
  brake: { color: [0.32, 0.32, 0.33], metal: 1, rough: 0.45 },
  caliper: { color: [0.75, 0.05, 0.04], metal: 0.2, rough: 0.35 },
  interior: { color: [0.05, 0.05, 0.052], metal: 0, rough: 0.75 },
  accent: { color: [0.3, 0.05, 0.05], metal: 0, rough: 0.6 },
  headlight: { color: [1, 1, 1], metal: 0, rough: 0.1, emissive: [1, 0.96, 0.9] },
  taillight: { color: [0.45, 0.01, 0.01], metal: 0, rough: 0.15, emissive: [1, 0.05, 0.02] },
  indicator: { color: [1, 0.45, 0.05], metal: 0, rough: 0.2, emissive: [1, 0.45, 0.05] },
}

/** Buckets that only matter up close. */
const INTERIOR = new Set(['interior', 'accent'])

/**
 * Per-car configuration. `rules` are tested against "<node path>|<material>" in order;
 * the first match wins. `wheel` decides which triangles belong to the spinning wheels.
 */
const CARS = [
  {
    name: 'sports',
    file: 'ferrari.glb',
    flip: true,
    length: 4.53,
    lod1Ratio: 0.08,
    lod2Ratio: 0.015,
    wheel: (key) => /wheel_(fl|fr|rl|rr)\//.test(key),
    rules: [
      [/\|Body_Color/, 'paint'],
      [/wheel_..\/tire/, 'rubber'],
      [/wheel_..\/rim/, 'rim'],
      [/wheel_..\/brake/, 'brake'],
      [/wheel_..\/centre/, 'caliper'],
      [/wheel_..\/nuts/, 'chrome'],
      [/wheel_..\//, 'rim'],
      [/main\/brakes/, 'caliper'],
      [/steering_red_lights/, 'taillight'],
      [/\|Taillight_Glass/, 'taillight'],
      [/\|Turn_Signal_LED/, 'headlight'],
      [/\|Projector_Glass/, 'headlight'],
      [/\|Glass_Gray/, 'glass'],
      [/\|metal_chrome/, 'chrome'],
      [/main\/metal\|/, 'metal'],
      [/\|metal_gray/, 'metal'],
      [/\|Tires/, 'plastic'],
      [/\|plastic_gray/, 'plastic'],
      [/\|Carbon_Fiber/, 'black'],
      [/\|Leather_red/, 'accent'],
      [/\|Ferrari_Yellow/, 'caliper'],
      [/\|(Leather|Carpet|Interior_dark|Interior_light|_0098_DodgerBlue)/, 'interior'],
    ],
  },
  {
    name: 'suv',
    file: 'lambo.glb',
    flip: false,
    length: 5.11,
    wheel: (key) => /wheel003|Whl_HD|Universal_Caliper|\/(FL|FR|RL|RR)\//.test(key),
    rules: [
      [/\|WhiteCar/, 'paint'],
      [/\|TiresGum/, 'rubber'],
      [/\|RimsChrome/, 'rim'],
      [/wheel003_019.*\|Chrome/, 'rim'],
      [/wheel003_020.*\|Chrome/, 'chrome'],
      [/\|BreakDiscs$/, 'brake'],
      [/Universal_Caliper/, 'caliper'],
      [/Whl_HD/, 'brake'],
      [/\|emitbrake/, 'taillight'],
      [/\|LightsGlassBack/, 'taillight'],
      [/\|BreaksRedPaint/, 'taillight'],
      [/\|LightsFrontLed/, 'headlight'],
      [/\|Default_Material/, 'headlight'],
      [/\|material/, 'indicator'],
      [/\|LightsGlassFront/, 'lens'],
      [/\|Glass$/, 'darkGlass'],
      [/\|Mirror/, 'chrome'],
      [/\|(Chrome|ChromeBLurred)/, 'chrome'],
      [/\|BreakDiscs_1/, 'black'],
      [/\|(GreyElements|BlackPaint)/, 'black'],
      [/\|(FrameBlack|Logo)/, 'plastic'],
    ],
  },
  {
    name: 'sedan',
    file: 'porsche.glb',
    flip: false,
    length: 4.29,
    wheel: (key) => /\|930_(rim|tire)$/.test(key),
    rules: [
      [/\|Material\.001/, null],
      [/\|DefaultMaterial/, null],
      [/\|paint/, 'paint'],
      [/\|930_tire/, 'rubber'],
      [/\|930_rim/, 'rim'],
      [/\|930_lights_refraction/, 'lens'],
      [/\|930_lights/, 'headlight'],
      [/\|glass/, 'glass'],
      [/\|930_chromes/, 'chrome'],
      [/\|black/, 'black'],
      [/\|plate/, 'plastic'],
      [/\|930_stickers/, null],
      [/\|930_plastics/, 'plastic'],
    ],
  },
]

const WHEELS = ['fl', 'fr', 'rl', 'rr']

/** A growable indexed geometry bucket. */
class Bucket {
  constructor() {
    this.pos = []
    this.nrm = []
    this.idx = []
  }
  get tris() {
    return this.idx.length / 3
  }
}

function classify(car, part) {
  const key = `${part.node}|${part.material}`
  for (const [re, mat] of car.rules) if (re.test(key)) return { key, mat }
  console.warn(`  unmapped ${key} -> plastic`)
  return { key, mat: 'plastic' }
}

function computeNormals(part) {
  const g = new THREE.BufferGeometry()
  g.setAttribute('position', new THREE.BufferAttribute(part.pos, 3))
  g.setIndex(new THREE.BufferAttribute(part.idx, 1))
  g.computeVertexNormals()
  part.nrm = g.getAttribute('normal').array
}

/** Transform matrix from source space into normalised car space. */
function normaliser(car, parts) {
  const rot = new THREE.Matrix4().makeRotationY(car.flip ? Math.PI : 0)
  const box = new THREE.Box3()
  const v = new THREE.Vector3()
  for (const p of parts) for (let i = 0; i < p.pos.length; i += 3) box.expandByPoint(v.fromArray(p.pos, i).applyMatrix4(rot))
  const size = box.getSize(new THREE.Vector3())
  const scale = car.length / size.z
  const center = box.getCenter(new THREE.Vector3())
  const m = new THREE.Matrix4()
    .makeScale(scale, scale, scale)
    .multiply(new THREE.Matrix4().makeTranslation(-center.x, -box.min.y, -center.z))
    .multiply(rot)
  return { m, rot, scale }
}

function wheelOf(x, z) {
  return (z > 0 ? 'f' : 'r') + (x > 0 ? 'l' : 'r')
}

async function bakeCar(car) {
  console.log(`\n== ${car.name} (${car.file})`)
  const raw = await loadParts(path.join(SOURCE_DIR, car.file))
  const parts = []
  for (const part of raw) {
    const { key, mat } = classify(car, part)
    if (!mat) continue
    if (!part.hasNormals) computeNormals(part)
    parts.push({ ...part, key, mat, isWheel: car.wheel(key) })
  }
  const { m, rot } = normaliser(car, parts)
  const normalM = new THREE.Matrix3().getNormalMatrix(m)

  const body = new Map()
  const wheels = Object.fromEntries(WHEELS.map((w) => [w, new Map()]))
  const wheelBoxes = Object.fromEntries(WHEELS.map((w) => [w, new THREE.Box3()]))
  const flipWinding = m.determinant() < 0
  const v = new THREE.Vector3()
  const n = new THREE.Vector3()

  for (const part of parts) {
    const count = part.pos.length / 3
    const P = new Float32Array(part.pos.length)
    const N = new Float32Array(part.pos.length)
    for (let i = 0; i < count; i++) {
      v.fromArray(part.pos, i * 3).applyMatrix4(m).toArray(P, i * 3)
      n.fromArray(part.nrm, i * 3).applyMatrix3(normalM).normalize().toArray(N, i * 3)
    }
    // Triangles are routed one by one so merged sources (like the Porsche) still split per wheel.
    const remaps = new Map()
    for (let t = 0; t < part.idx.length; t += 3) {
      const a = part.idx[t]
      const b = part.idx[t + (flipWinding ? 2 : 1)]
      const c = part.idx[t + (flipWinding ? 1 : 2)]
      let target = body
      let wheelKey = null
      if (part.isWheel) {
        const cx = (P[a * 3] + P[b * 3] + P[c * 3]) / 3
        const cz = (P[a * 3 + 2] + P[b * 3 + 2] + P[c * 3 + 2]) / 3
        wheelKey = wheelOf(cx, cz)
        target = wheels[wheelKey]
      }
      let bucket = target.get(part.mat)
      if (!bucket) target.set(part.mat, (bucket = new Bucket()))
      const mapKey = `${wheelKey}|${part.mat}`
      let remap = remaps.get(mapKey)
      if (!remap) remaps.set(mapKey, (remap = new Map()))
      for (const vi of [a, b, c]) {
        let out = remap.get(vi)
        if (out === undefined) {
          out = bucket.pos.length / 3
          bucket.pos.push(P[vi * 3], P[vi * 3 + 1], P[vi * 3 + 2])
          bucket.nrm.push(N[vi * 3], N[vi * 3 + 1], N[vi * 3 + 2])
          remap.set(vi, out)
          if (wheelKey && part.mat === 'rubber') wheelBoxes[wheelKey].expandByPoint(v.set(P[vi * 3], P[vi * 3 + 1], P[vi * 3 + 2]))
        }
        bucket.idx.push(out)
      }
    }
  }

  const pivots = {}
  for (const w of WHEELS) {
    const box = wheelBoxes[w]
    if (box.isEmpty()) throw new Error(`${car.name}: wheel ${w} has no tyre geometry`)
    const c = box.getCenter(new THREE.Vector3())
    const s = box.getSize(new THREE.Vector3())
    pivots[w] = { x: c.x, y: c.y, z: c.z, radius: s.y / 2, width: s.x }
  }
  // Wheel geometry lives relative to its hub so the runtime can spin and steer it.
  for (const w of WHEELS) {
    for (const bucket of wheels[w].values()) {
      for (let i = 0; i < bucket.pos.length; i += 3) {
        bucket.pos[i] -= pivots[w].x
        bucket.pos[i + 1] -= pivots[w].y
        bucket.pos[i + 2] -= pivots[w].z
      }
    }
  }

  const bodyBox = new THREE.Box3()
  for (const b of body.values()) for (let i = 0; i < b.pos.length; i += 3) bodyBox.expandByPoint(v.fromArray(b.pos, i))
  const dims = bodyBox.getSize(new THREE.Vector3())

  const steering = steeringCenter(raw, m)
  const meta = {
    name: car.name,
    length: +dims.z.toFixed(3),
    width: +dims.x.toFixed(3),
    height: +dims.y.toFixed(3),
    roof: +bodyBox.max.y.toFixed(3),
    floor: +bodyBox.min.y.toFixed(3),
    wheels: Object.fromEntries(WHEELS.map((w) => [w, Object.fromEntries(Object.entries(pivots[w]).map(([k, val]) => [k, +val.toFixed(4)]))])),
    steering,
  }
  console.log('  dims', meta.length, meta.width, meta.height, 'wheel r', pivots.fl.radius.toFixed(3), 'base', (pivots.fl.z - pivots.rl.z).toFixed(3), 'track', (pivots.fl.x - pivots.fr.x).toFixed(3))
  console.log('  steering', steering ? `${steering.x.toFixed(2)},${steering.y.toFixed(2)},${steering.z.toFixed(2)}` : 'n/a')

  const lod0 = buildLod({ body, wheels, pivots }, { ratio: 1, error: 0, interior: true })
  const lod1 = buildLod({ body, wheels, pivots }, { ratio: car.lod1Ratio ?? 0.15, error: 0.008, interior: false, mergeWheel: true })
  const lod2 = buildLod({ body, wheels, pivots }, { ratio: car.lod2Ratio ?? 0.03, error: 0.04, interior: false, mergeWheel: true, staticWheels: true, collapse: true })
  report('lod0', lod0)
  report('lod1', lod1)
  report('lod2', lod2)

  await writeGlb(`${car.name}-lod0.glb`, { lod0 }, meta)
  await writeGlb(`${car.name}-lod1.glb`, { lod1, lod2 }, meta)
  return meta
}

function steeringCenter(raw, m) {
  const parts = raw.filter((p) => /steering_(wheel|leather|carbon)/.test(p.node))
  if (!parts.length) return null
  const box = new THREE.Box3()
  const v = new THREE.Vector3()
  for (const p of parts) for (let i = 0; i < p.pos.length; i += 3) box.expandByPoint(v.fromArray(p.pos, i).applyMatrix4(m))
  const c = box.getCenter(new THREE.Vector3())
  return { x: +c.x.toFixed(3), y: +c.y.toFixed(3), z: +c.z.toFixed(3) }
}

const COLLAPSE = { rim: 'rim', brake: 'rim', caliper: 'rim', chrome: 'chrome', metal: 'chrome', lens: 'glass', glass: 'glass', darkGlass: 'darkGlass', indicator: 'headlight', accent: 'black', plastic: 'black' }

/** Simplifies a welded bucket; returns typed arrays. */
function simplifyBucket(bucket, ratio, error, loose) {
  const pos = new Float32Array(bucket.pos)
  let nrm = new Float32Array(bucket.nrm)
  let idx = new Uint32Array(bucket.idx)
  if (ratio >= 1) return compact(pos, nrm, idx)
  if (loose) nrm = smoothNormals(pos, idx)
  const target = Math.max(12, Math.floor((idx.length * ratio) / 3) * 3)
  let [out] = MeshoptSimplifier.simplify(idx, pos, 3, target, error, ['ErrorAbsolute'])
  // Flat-shaded or fragmented sources barely collapse; fall back to sloppy clustering.
  if (out.length > target * 1.6) [out] = MeshoptSimplifier.simplifySloppy(idx, pos, 3, null, target, error)
  // Very small fragments can simplify to nothing; keep the original then.
  if (out.length >= 3) idx = out
  return compact(pos, nrm, idx)
}

function smoothNormals(pos, idx) {
  const g = new THREE.BufferGeometry()
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3))
  g.setIndex(new THREE.BufferAttribute(idx, 1))
  g.computeVertexNormals()
  return g.getAttribute('normal').array
}

function compact(pos, nrm, idx) {
  const map = new Int32Array(pos.length / 3).fill(-1)
  let count = 0
  for (const i of idx) if (map[i] === -1) map[i] = count++
  const P = new Float32Array(count * 3)
  const N = new Float32Array(count * 3)
  for (let i = 0; i < map.length; i++) {
    const o = map[i]
    if (o === -1) continue
    P.set(pos.subarray(i * 3, i * 3 + 3), o * 3)
    N.set(nrm.subarray(i * 3, i * 3 + 3), o * 3)
  }
  const I = new Uint32Array(idx.length)
  for (let i = 0; i < idx.length; i++) I[i] = map[idx[i]]
  return { pos: P, nrm: N, idx: I }
}

/**
 * Welds vertices so the simplifier sees connected surfaces. Strict welding keeps hard normals;
 * loose welding merges by position only (normals are rebuilt smooth afterwards).
 */
function weld(bucket, loose) {
  const keyOf = (i) => {
    const p = bucket.pos
    const n = bucket.nrm
    const k = `${Math.round(p[i * 3] * 1e3)},${Math.round(p[i * 3 + 1] * 1e3)},${Math.round(p[i * 3 + 2] * 1e3)}`
    if (loose) return k
    return `${Math.round(p[i * 3] * 1e4)},${Math.round(p[i * 3 + 1] * 1e4)},${Math.round(p[i * 3 + 2] * 1e4)},${Math.round(n[i * 3] * 20)},${Math.round(n[i * 3 + 1] * 20)},${Math.round(n[i * 3 + 2] * 20)}`
  }
  const seen = new Map()
  const out = new Bucket()
  const remap = new Uint32Array(bucket.pos.length / 3)
  for (let i = 0; i < remap.length; i++) {
    const k = keyOf(i)
    let o = seen.get(k)
    if (o === undefined) {
      o = out.pos.length / 3
      seen.set(k, o)
      out.pos.push(bucket.pos[i * 3], bucket.pos[i * 3 + 1], bucket.pos[i * 3 + 2])
      out.nrm.push(bucket.nrm[i * 3], bucket.nrm[i * 3 + 1], bucket.nrm[i * 3 + 2])
    }
    remap[i] = o
  }
  for (let t = 0; t < bucket.idx.length; t += 3) {
    const a = remap[bucket.idx[t]]
    const b = remap[bucket.idx[t + 1]]
    const c = remap[bucket.idx[t + 2]]
    if (a !== b && b !== c && a !== c) out.idx.push(a, b, c)
  }
  return out
}

function mergeInto(target, mat, bucket, offset = null) {
  let dst = target.get(mat)
  if (!dst) target.set(mat, (dst = new Bucket()))
  const base = dst.pos.length / 3
  for (let i = 0; i < bucket.pos.length; i += 3) {
    dst.pos.push(bucket.pos[i] + (offset?.x ?? 0), bucket.pos[i + 1] + (offset?.y ?? 0), bucket.pos[i + 2] + (offset?.z ?? 0))
    dst.nrm.push(bucket.nrm[i], bucket.nrm[i + 1], bucket.nrm[i + 2])
  }
  for (const i of bucket.idx) dst.idx.push(i + base)
}

function buildLod(src, opts) {
  const remapMat = (mat) => (opts.collapse ? (COLLAPSE[mat] ?? mat) : opts.mergeWheel && (mat === 'brake' || mat === 'caliper') ? 'rim' : mat)
  const body = new Map()
  for (const [mat, bucket] of src.body) {
    if (!opts.interior && INTERIOR.has(mat)) continue
    mergeInto(body, remapMat(mat), bucket)
  }
  const wheels = {}
  for (const w of WHEELS) {
    const merged = new Map()
    for (const [mat, bucket] of src.wheels[w]) mergeInto(merged, remapMat(mat), bucket)
    if (opts.staticWheels) for (const [mat, bucket] of merged) mergeInto(body, mat, bucket, src.pivots[w])
    else wheels[w] = merged
  }
  const finish = (map) => {
    const out = {}
    for (const [mat, bucket] of map) {
      const loose = opts.ratio < 1
      const welded = weld(bucket, loose)
      if (!welded.idx.length) continue
      out[mat] = simplifyBucket(welded, opts.ratio, opts.error, loose)
    }
    return out
  }
  return {
    body: finish(body),
    wheels: opts.staticWheels ? null : Object.fromEntries(WHEELS.map((w) => [w, finish(wheels[w])])),
    pivots: src.pivots,
  }
}

function report(label, lod) {
  const count = (g) => Object.values(g).reduce((s, b) => s + b.idx.length / 3, 0)
  let tris = count(lod.body)
  let calls = Object.keys(lod.body).length
  if (lod.wheels)
    for (const w of WHEELS) {
      tris += count(lod.wheels[w])
      calls += Object.keys(lod.wheels[w]).length
    }
  console.log(`  ${label}: ${Math.round(tris)} tris, ${calls} draw calls`)
}

async function writeGlb(file, lods, meta) {
  const doc = new Document()
  const buffer = doc.createBuffer()
  const clearcoat = doc.createExtension(KHRMaterialsClearcoat)
  const materials = {}
  const material = (name) => {
    if (materials[name]) return materials[name]
    const def = MATERIALS[name]
    const mat = doc
      .createMaterial(name)
      .setBaseColorFactor([...def.color, def.alpha ?? 1])
      .setMetallicFactor(def.metal)
      .setRoughnessFactor(def.rough)
    if (def.alpha !== undefined) mat.setAlphaMode('BLEND')
    if (def.emissive) mat.setEmissiveFactor(def.emissive)
    if (name === 'paint') mat.setExtension('KHR_materials_clearcoat', clearcoat.createClearcoat().setClearcoatFactor(1).setClearcoatRoughnessFactor(0.03))
    materials[name] = mat
    return mat
  }
  const meshOf = (name, groups) => {
    const mesh = doc.createMesh(name)
    for (const [mat, g] of Object.entries(groups)) {
      const prim = doc
        .createPrimitive()
        .setAttribute('POSITION', doc.createAccessor().setType('VEC3').setArray(g.pos).setBuffer(buffer))
        .setAttribute('NORMAL', doc.createAccessor().setType('VEC3').setArray(g.nrm).setBuffer(buffer))
        .setIndices(doc.createAccessor().setType('SCALAR').setArray(g.idx).setBuffer(buffer))
        .setMaterial(material(mat))
      mesh.addPrimitive(prim)
    }
    return mesh
  }
  const scene = doc.createScene(meta.name)
  for (const [lodName, lod] of Object.entries(lods)) {
    const root = doc.createNode(lodName)
    scene.addChild(root)
    root.addChild(doc.createNode(`${lodName}_body`).setMesh(meshOf(`${lodName}_body`, lod.body)))
    if (lod.wheels) {
      for (const w of WHEELS) {
        const p = lod.pivots[w]
        // Pivot node carries the hub position; the child holds the mesh so quantisation can't move the pivot.
        const pivot = doc.createNode(`${lodName}_wheel_${w}`).setTranslation([p.x, p.y, p.z])
        pivot.addChild(doc.createNode(`${lodName}_wheel_${w}_mesh`).setMesh(meshOf(`${lodName}_wheel_${w}`, lod.wheels[w])))
        root.addChild(pivot)
      }
    }
  }
  scene.setExtras({ car: meta })
  doc.getRoot().setDefaultScene(scene)
  await doc.transform(dedup(), prune(), meshopt({ encoder: MeshoptEncoder, level: 'medium' }))
  const io = await getIO()
  const out = path.join(OUT_DIR, file)
  await io.write(out, doc)
  console.log(`  wrote ${file} ${(fs.statSync(out).size / 1024 / 1024).toFixed(2)} MB`)
}

await MeshoptSimplifier.ready
fs.mkdirSync(OUT_DIR, { recursive: true })
const metas = []
for (const car of CARS) metas.push(await bakeCar(car))
fs.writeFileSync(path.join(OUT_DIR, 'cars.json'), JSON.stringify(Object.fromEntries(metas.map((m) => [m.name, m])), null, 2))
console.log('\nwrote cars.json')
