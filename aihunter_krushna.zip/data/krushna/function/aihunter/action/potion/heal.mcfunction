scoreboard players add @s aihunter_busy 25
scoreboard players set @s aihunter_weapon 0

data merge entity @s {HandItems:[{id:"minecraft:splash_potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:strong_healing"}}},{}]}

data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] {HandItems:[{id:"minecraft:splash_potion",count:1,components:{"minecraft:potion_contents":{potion:"minecraft:strong_healing"}}},{}]}

execute if score quality aihunter_dummy matches 2 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] {Pose:{Head:[300f,0f,0f]}}

scoreboard players set @s aihunter_potion -1

execute if score debug aihunter_dummy matches 1 run say potion: heal
