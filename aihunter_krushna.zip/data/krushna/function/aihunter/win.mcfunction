schedule function krushna:aihunter/stop 1t

execute as @e[type=minecraft:armor_stand,tag=aihunter] run data merge entity @s {HandItems:[{id:"minecraft:diamond",count:1},{}],Pose:{LeftArm:[-50f,-30f,0f],RightArm:[-50f,30f,0f]},Glowing:0b,CustomName:'{"text":"Congrats!"}',Tags:[""],Invulnerable:0b,DisabledSlots:0}

scoreboard players set #valve3 aihunter_dummy 1


#

function krushna:aihunter/message/victory

execute at @a run playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ .8 1.6

execute at @a run summon minecraft:firework_rocket ~ ~ ~ {Tags:["aihunter_congrats"],LifeTime:30,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{Explosions:[{Type:1,Flicker:1b,Trail:1b,Colors:[I;12063487],FadeColors:[I;2303]}]}}}}

execute if score difficulty aihunter_dummy matches 2.. at @a run summon minecraft:firework_rocket ~ ~ ~ {Tags:["aihunter_congrats"],LifeTime:40,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{Explosions:[{Type:3,Flicker:1b,Trail:1b,Colors:[I;63487],FadeColors:[I;2303]}]}}}}

execute if score difficulty aihunter_dummy matches 3.. at @a run summon minecraft:firework_rocket ~ ~ ~ {Tags:["aihunter_congrats"],LifeTime:50,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{Explosions:[{Type:2,Flicker:1b,Trail:1b,Colors:[I;2063487],FadeColors:[I;2303]}]}}}}

#

advancement revoke @s only krushna:aihunter/win