execute if entity @s[nbt={Type:oak}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:oak_boat",count:1}}

execute if entity @s[nbt={Type:spruce}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:spruce_boat",count:1}}

execute if entity @s[nbt={Type:birch}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:birch_boat",count:1}}

execute if entity @s[nbt={Type:jungle}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:jungle_boat",count:1}}

execute if entity @s[nbt={Type:acacia}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:acacia_boat",count:1}}

execute if entity @s[nbt={Type:dark_oak}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:dark_oak_boat",count:1}}

execute if entity @s[type=minecraft:minecart] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:minecart",count:1}}

kill @s
