"""
Renders front / side / back / face turnaround shots of a .blend or .glb with Cycles (CPU).

    blender -b -P scripts/character/render_preview.py -- <input> <out_prefix> [views]
"""

import bpy
import math
import sys
from mathutils import Vector

args = sys.argv[sys.argv.index("--") + 1 :]
src, prefix = args[0], args[1]
views = args[2].split(",") if len(args) > 2 else ["front", "side", "back", "face"]

if src.endswith(".blend"):
    bpy.ops.wm.open_mainfile(filepath=src)
else:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=src)

scene = bpy.context.scene
scene.render.engine = "CYCLES"
scene.cycles.device = "CPU"
scene.cycles.samples = 24
scene.cycles.use_denoising = True
scene.render.resolution_x = 640
scene.render.resolution_y = 900
scene.render.film_transparent = False
scene.view_settings.view_transform = "AgX"

world = bpy.data.worlds.new("PreviewWorld")
world.use_nodes = True
world.node_tree.nodes["Background"].inputs[0].default_value = (0.42, 0.47, 0.55, 1)
world.node_tree.nodes["Background"].inputs[1].default_value = 0.6
scene.world = world

def add_light(name, loc, energy, size):
    data = bpy.data.lights.new(name, "AREA")
    data.energy = energy
    data.size = size
    obj = bpy.data.objects.new(name, data)
    obj.location = loc
    direction = Vector((0, 0, 1.0)) - Vector(loc)
    obj.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()
    scene.collection.objects.link(obj)

add_light("Key", (2.2, -2.6, 2.6), 650, 2.0)
add_light("Fill", (-2.6, -1.6, 1.6), 220, 3.0)
add_light("Rim", (0.0, 2.8, 2.4), 380, 2.0)

meshes = [o for o in scene.objects if o.type == "MESH" and o.visible_get()]
lo = Vector((1e9, 1e9, 1e9))
hi = Vector((-1e9, -1e9, -1e9))
depsgraph = bpy.context.evaluated_depsgraph_get()
for o in meshes:
    ev = o.evaluated_get(depsgraph)
    for v in ev.to_mesh().vertices:
        w = o.matrix_world @ v.co
        lo = Vector(map(min, lo, w))
        hi = Vector(map(max, hi, w))
    ev.to_mesh_clear()
height = hi.z - lo.z
print("BOUNDS", tuple(round(c, 3) for c in lo), tuple(round(c, 3) for c in hi), "height", round(height, 3))

cam_data = bpy.data.cameras.new("Cam")
cam = bpy.data.objects.new("Cam", cam_data)
scene.collection.objects.link(cam)
scene.camera = cam

SHOTS = {
    "front": (0, height * 0.5, 4.6, 35),
    "side": (90, height * 0.5, 4.6, 35),
    "back": (180, height * 0.5, 4.6, 35),
    "three": (35, height * 0.5, 4.6, 35),
    "face": (20, height * 0.93, 0.95, 40),
    "hands": (0, height * 0.5, 1.5, 40),
}

for view in views:
    yaw, target_z, dist, lens = SHOTS[view]
    a = math.radians(yaw)
    target = Vector((0, 0, lo.z + target_z if view != "face" else lo.z + target_z))
    cam.location = target + Vector((math.sin(a) * dist, -math.cos(a) * dist, 0.0))
    cam.rotation_euler = (target - cam.location).to_track_quat("-Z", "Y").to_euler()
    cam_data.lens = lens
    scene.render.filepath = f"{prefix}-{view}.png"
    bpy.ops.render.render(write_still=True)
    print("RENDERED", scene.render.filepath)
