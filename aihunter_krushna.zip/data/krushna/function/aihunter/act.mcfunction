##as at @e[type=minecraft:vindicator,tag=aihunter]
#always

execute store result score @s aihunter_hp run data get entity @s Health 10

execute if score falldamage aihunter_dummy matches 1 if predicate krushna:aihunter/falling run data modify entity @s fall_distance set value -999

execute if score difficulty aihunter_dummy matches ..3 if predicate krushna:aihunter/onfire if predicate krushna:aihunter/dimension/nether unless predicate krushna:aihunter/fire_resistance if predicate krushna:aihunter/chance/30 run function krushna:aihunter/action/potion/fire


#engaged: target available

execute unless predicate krushna:aihunter/idle if entity @p[gamemode=!creative,gamemode=!spectator,team=!aihunter] run function krushna:aihunter/act/engaged


#suppose in act/onground but moved here for head animation.

execute unless score @s aihunter_busy matches ..0 run scoreboard players remove @s aihunter_busy 1