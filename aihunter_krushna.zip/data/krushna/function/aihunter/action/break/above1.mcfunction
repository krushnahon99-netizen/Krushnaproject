execute if score @s aihunter_upgrade matches ..1 run scoreboard players add @s aihunter_busy 3
execute if score @s aihunter_upgrade matches 2.. run scoreboard players add @s aihunter_busy 2
scoreboard players set @s aihunter_weapon 0

#data merge entity @s {HandItems:[{id:"minecraft:iron_pickaxe",count:1},{}]}

data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] {HandItems:[{id:"minecraft:iron_pickaxe",count:1},{}]}

execute if score quality aihunter_dummy matches 2 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] {Pose:{Head:[300f,0f,0f]}}

setblock ~ ~2.5 ~ minecraft:air destroy