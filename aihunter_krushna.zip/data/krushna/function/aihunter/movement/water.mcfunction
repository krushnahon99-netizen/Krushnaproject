function krushna:aihunter/find/vector/2d

scoreboard players set #valve2 aihunter_dummy 0

execute positioned ~ ~-1 ~ if predicate krushna:aihunter/water positioned ~ ~-1 ~ if predicate krushna:aihunter/water positioned ~ ~2 ~ run function krushna:aihunter/movement/water/deep

execute unless score #valve2 aihunter_dummy matches 1 run function krushna:aihunter/movement/water/shallow