execute if block ~ ~ ~ minecraft:pale_oak_sign[waterlogged=false] run setblock ~ ~ ~ minecraft:pale_oak_sign[waterlogged=true] replace
execute if block ~ ~ ~ minecraft:pale_oak_wall_sign[waterlogged=false] run setblock ~ ~ ~ minecraft:pale_oak_wall_sign[waterlogged=true] replace
