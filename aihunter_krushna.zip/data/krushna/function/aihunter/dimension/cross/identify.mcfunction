#identify going to which dimension

advancement revoke @s only krushna:aihunter/dimension

execute if predicate krushna:aihunter/dimension/overworld run function krushna:aihunter/dimension/cross/0

execute unless score wincondition aihunter_dummy matches 2 if predicate krushna:aihunter/dimension/nether run function krushna:aihunter/dimension/cross/1

execute unless score dimension aihunter_dummy matches 2 if predicate krushna:aihunter/dimension/end run function krushna:aihunter/dimension/cross/2