import { createRandom } from './random'
import { GRID, ROAD, buildTrafficLoop, randomRoadPoint } from './world'

export type CarVariant = 'sports' | 'sedan' | 'taxi' | 'suv'

export type Car = {
  id: number
  kind: 'drivable' | 'traffic'
  variant: CarVariant
  color: string
  x: number
  z: number
  heading: number
  vx: number
  vz: number
  steer: number
  wheelSpin: number
  roll: number
  pitch: number
  braking: boolean
  slip: number
  loop: { x: number; z: number }[]
  segment: number
  speed: number
  cruiseSpeed: number
  stun: number
  blocked: number
  bypass: number
  door: number
}

export type CarTransition = {
  kind: 'enter' | 'exit'
  carId: number
  t: number
  fromX: number
  fromZ: number
  fromY: number
  fromHeading: number
}

export type Pickup = { id: number; x: number; z: number; value: number }

export type Notice = { id: number; text: string; tone: 'cash' | 'alert' }

export const input = {
  forward: false,
  back: false,
  left: false,
  right: false,
  handbrake: false,
  sprint: false,
  interactQueued: false,
  cameraDrag: 0,
  /** Negative looks up toward the sky, positive orbits overhead to look down. */
  cameraPitch: 0,
  lookHeld: false,
  lookIdle: 0,
  stickActive: false,
  stickX: 0,
  stickY: 0,
}

const random = createRandom(42)

function makeCar(partial: Partial<Car> & Pick<Car, 'id' | 'kind' | 'variant' | 'color' | 'x' | 'z' | 'heading'>): Car {
  return {
    vx: 0,
    vz: 0,
    steer: 0,
    wheelSpin: 0,
    roll: 0,
    pitch: 0,
    braking: false,
    slip: 0,
    loop: [],
    segment: 0,
    speed: 0,
    cruiseSpeed: 0,
    stun: 0,
    blocked: 0,
    bypass: 0,
    door: 0,
    ...partial,
  }
}

const PARKING_X = ROAD / 2 - 1.1

const TRAFFIC_COLORS = ['#e8e4dc', '#1c1f26', '#7a8794', '#2a4d8f', '#8f1d24', '#c9b28a', '#3c6e57', '#f2f2f2']

function createCars(): Car[] {
  const cars: Car[] = [
    makeCar({ id: 0, kind: 'drivable', variant: 'sports', color: '#d4141c', x: PARKING_X, z: 24, heading: 0 }),
    makeCar({ id: 1, kind: 'drivable', variant: 'sports', color: '#f2f2f2', x: -PARKING_X, z: 30, heading: Math.PI }),
    makeCar({ id: 2, kind: 'drivable', variant: 'suv', color: '#111317', x: -PARKING_X, z: 16, heading: Math.PI }),
  ]

  const loops: [number, number, number, number][] = [
    [0, GRID, 0, GRID],
    [1, 5, 1, 5],
    [2, 4, 2, 4],
    [0, 3, 0, 3],
    [3, 6, 3, 6],
    [0, 3, 3, 6],
    [3, 6, 0, 3],
    [1, 4, 2, 6],
    [2, 6, 1, 4],
  ]

  let id = cars.length
  loops.forEach((bounds, loopIndex) => {
    ;[true, false].forEach((clockwise) => {
      const loop = buildTrafficLoop(...bounds, clockwise)
      const carsOnLoop = loopIndex === 0 ? 3 : 1
      for (let n = 0; n < carsOnLoop; n++) {
        const segment = Math.floor(random() * 4)
        const a = loop[segment]
        const b = loop[(segment + 1) % 4]
        const t = 0.2 + random() * 0.5
        const roll = random()
        const variant: CarVariant = roll < 0.25 ? 'taxi' : roll < 0.45 ? 'suv' : roll < 0.6 ? 'sports' : 'sedan'
        cars.push(
          makeCar({
            id: id++,
            kind: 'traffic',
            variant,
            color: variant === 'taxi' ? '#f5b90f' : TRAFFIC_COLORS[Math.floor(random() * TRAFFIC_COLORS.length)],
            x: a.x + (b.x - a.x) * t,
            z: a.z + (b.z - a.z) * t,
            heading: Math.atan2(b.x - a.x, b.z - a.z),
            loop,
            segment: (segment + 1) % 4,
            cruiseSpeed: 11 + random() * 6,
            speed: 10,
          }),
        )
      }
    })
  })

  return cars
}

function createPickups(): Pickup[] {
  return Array.from({ length: 12 }, (_, id) => ({ id, ...randomRoadPoint(random), value: randomCashValue() }))
}

export function randomCashValue() {
  return Math.round((100 + Math.random() * 900) / 50) * 50
}

export const game = {
  started: false,
  mode: 'foot' as 'foot' | 'car',
  carId: null as number | null,
  player: { x: ROAD / 2 + 1.5, z: 17, y: 0, vy: 0, heading: 0, speed: 0, phase: 0, sit: 0, reach: 0 },
  transition: null as CarTransition | null,
  cars: createCars(),
  pickups: createPickups(),
  money: 0,
  wanted: 0,
  lastCrime: 0,
  time: 0,
  shake: 0,
  prompt: null as string | null,
  notices: [] as Notice[],
}

export function getPlayerCar() {
  return game.carId === null ? null : game.cars[game.carId]
}

export function getFocus() {
  const car = getPlayerCar()
  return car ? { x: car.x, z: car.z, heading: car.heading } : { x: game.player.x, z: game.player.z, heading: game.player.heading }
}

export type HudSnapshot = {
  started: boolean
  mode: 'foot' | 'car'
  speed: number
  money: number
  wanted: number
  prompt: string | null
  notices: Notice[]
}

let snapshot: HudSnapshot = {
  started: false,
  mode: 'foot',
  speed: 0,
  money: 0,
  wanted: 0,
  prompt: null,
  notices: [],
}

const listeners = new Set<() => void>()

export const hudStore = {
  subscribe(listener: () => void) {
    listeners.add(listener)
    return () => listeners.delete(listener)
  },
  getSnapshot() {
    return snapshot
  },
  getServerSnapshot() {
    return snapshot
  },
}

export function publishHud() {
  const car = getPlayerCar()
  const speed = car ? Math.round(Math.hypot(car.vx, car.vz) * 3.6) : 0
  const next: HudSnapshot = {
    started: game.started,
    mode: game.mode,
    speed,
    money: game.money,
    wanted: game.wanted,
    prompt: game.prompt,
    notices: game.notices,
  }
  const changed = (Object.keys(next) as (keyof HudSnapshot)[]).some((key) => next[key] !== snapshot[key])
  if (!changed) return
  snapshot = next
  listeners.forEach((listener) => listener())
}

let noticeId = 0
export function pushNotice(text: string, tone: Notice['tone']) {
  const notice = { id: noticeId++, text, tone }
  game.notices = [...game.notices.slice(-2), notice]
  setTimeout(() => {
    game.notices = game.notices.filter((n) => n.id !== notice.id)
    publishHud()
  }, 2200)
  publishHud()
}

export function startGame() {
  game.started = true
  publishHud()
}
