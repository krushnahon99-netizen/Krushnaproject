execute as @a[gamemode=!creative,gamemode=!spectator,team=!aihunter] run function krushna:aihunter/check/movestart/check

execute as @a[gamemode=!survival,gamemode=!adventure] run function krushna:aihunter/check/movestart/clear

execute unless score #movestart aihunter_dummy matches 1 run schedule function krushna:aihunter/check/movestart/loop 2t

execute if score #movestart aihunter_dummy matches 1 run schedule function krushna:aihunter/active 1t