scoreboard players remove initialupgrade aihunter_dummy 1

execute unless score initialupgrade aihunter_dummy matches 0..6 run scoreboard players set initialupgrade aihunter_dummy 6

function krushna:aihunter/settings/menu/2