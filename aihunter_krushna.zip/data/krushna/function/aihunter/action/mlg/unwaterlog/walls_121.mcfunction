execute if block ~ ~ ~ minecraft:tuff_wall[waterlogged=true] run setblock ~ ~ ~ minecraft:tuff_wall[waterlogged=false] replace
execute if block ~ ~ ~ minecraft:polished_tuff_wall[waterlogged=true] run setblock ~ ~ ~ minecraft:polished_tuff_wall[waterlogged=false] replace
execute if block ~ ~ ~ minecraft:tuff_brick_wall[waterlogged=true] run setblock ~ ~ ~ minecraft:tuff_brick_wall[waterlogged=false] replace
