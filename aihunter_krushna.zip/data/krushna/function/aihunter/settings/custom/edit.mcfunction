summon minecraft:armor_stand ~ ~ ~ {CustomName:'{"text":"Hunter"}',CustomNameVisible:1b,NoGravity:1b,Invulnerable:1b,ShowArms:1b,DisabledSlots:1,Tags:["aihunter_custom"]}

tellraw @s {"text":"<Click Here To Save The Customization>","color":"light_purple","clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/custom/save"}}

gamemode creative @s

give @s minecraft:anvil

give @s minecraft:name_tag