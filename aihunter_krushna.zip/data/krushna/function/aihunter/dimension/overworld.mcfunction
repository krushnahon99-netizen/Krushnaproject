##^aihunter/always
##as at server

execute as @p[predicate=krushna:aihunter/dimension/overworld] at @s if block ~ ~ ~ minecraft:nether_portal unless entity @e[type=minecraft:area_effect_cloud,tag=aihunter_overworld_portal] run function krushna:aihunter/dimension/aec

execute unless score bed aihunter_dummy matches 1 run function krushna:aihunter/check/respawn

execute if score bed aihunter_dummy matches 1 at @e[type=minecraft:area_effect_cloud,tag=aihunter_bed,limit=1,sort=nearest] run function krushna:aihunter/check/respawn

execute if score bed aihunter_dummy matches 1 at @e[type=minecraft:area_effect_cloud,tag=aihunter_bed] unless block ~ ~ ~ minecraft:brown_bed[part=foot] run scoreboard players set bed aihunter_dummy 0