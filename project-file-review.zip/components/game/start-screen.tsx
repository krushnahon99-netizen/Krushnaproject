'use client'

import Image from 'next/image'

const CONTROLS = [
  ['W / S', 'Drive & brake / walk'],
  ['A / D', 'Steer / turn'],
  ['Space', 'Handbrake / jump'],
  ['F', 'Enter, exit or steal cars'],
  ['Shift', 'Sprint'],
  ['Drag', 'Look around'],
  ['Hold T', 'Fast-forward time'],
]

export function StartScreen({ ready, onStart }: { ready: boolean; onStart: () => void }) {
  return (
    <div className="fixed inset-0 z-30 flex flex-col justify-end overflow-hidden bg-black text-white">
      <Image src="/images/key-art.png" alt="" fill priority className="object-cover opacity-80" sizes="100vw" />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/55 to-transparent" />

      <div className="relative flex flex-col gap-6 p-6 pb-10 md:max-w-3xl md:p-14 [@media(max-height:500px)]:gap-3 [@media(max-height:500px)]:p-5">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.35em] text-[#ff9db8]">Open world · 24-hour cycle</p>
          <h1 className="font-display text-7xl leading-[0.85] tracking-tight md:text-9xl [@media(max-height:500px)]:text-6xl">
            <span className="bg-gradient-to-b from-[#ffd38a] via-[#ff7aa2] to-[#c04bd6] bg-clip-text text-transparent">VICE</span>
            <br />
            SHORES
          </h1>
          <p className="mt-4 max-w-md text-pretty text-sm leading-relaxed text-white/80 md:text-base [@media(max-height:500px)]:mt-2 [@media(max-height:500px)]:text-xs">
            Walk the boulevard, steal any car you like, and grab the cash scattered across town. Crashing into traffic
            raises your wanted level, so drive carefully if you want to stay clean.
          </p>
        </div>

        <ul className="hidden grid-cols-3 gap-x-6 gap-y-2 text-sm md:grid [@media(pointer:coarse)]:hidden">
          {CONTROLS.map(([key, action]) => (
            <li key={key} className="flex items-center gap-2 text-white/75">
              <kbd className="rounded border border-white/25 bg-white/10 px-1.5 py-0.5 font-mono text-xs text-white">{key}</kbd>
              {action}
            </li>
          ))}
        </ul>

        <button
          type="button"
          onClick={onStart}
          disabled={!ready}
          className="w-full rounded-md bg-[#ff4f87] px-10 py-4 font-display text-2xl tracking-wider text-white shadow-[0_0_40px_rgba(255,79,135,0.45)] transition hover:bg-[#ff6b9a] disabled:cursor-wait disabled:opacity-60 md:w-fit [@media(max-height:500px)]:w-fit [@media(max-height:500px)]:py-2.5"
        >
          {ready ? 'PLAY' : 'LOADING CITY...'}
        </button>
      </div>
    </div>
  )
}
