import { NodeIO } from '@gltf-transform/core'
import { ALL_EXTENSIONS } from '@gltf-transform/extensions'
import { dequantize } from '@gltf-transform/functions'
import draco3d from 'draco3dgltf'
import { MeshoptEncoder } from 'meshoptimizer'
import * as THREE from 'three'

let ioPromise
export function getIO() {
  ioPromise ??= (async () => {
    await MeshoptEncoder.ready
    return new NodeIO().registerExtensions(ALL_EXTENSIONS).registerDependencies({
      'draco3d.decoder': await draco3d.createDecoderModule(),
      'draco3d.encoder': await draco3d.createEncoderModule(),
      'meshopt.encoder': MeshoptEncoder,
    })
  })()
  return ioPromise
}

/**
 * Flattens every triangle primitive of a glTF into world-space parts.
 * Each part keeps its source material name, node path and indexed geometry.
 */
export async function loadParts(file) {
  const io = await getIO()
  const doc = await io.read(file)
  await doc.transform(dequantize())
  const parts = []
  const scene = doc.getRoot().getDefaultScene() ?? doc.getRoot().listScenes()[0]

  const visit = (node, path) => {
    const name = `${path}/${node.getName()}`
    const mesh = node.getMesh()
    if (mesh) {
      const world = new THREE.Matrix4().fromArray(node.getWorldMatrix())
      const normalMatrix = new THREE.Matrix3().getNormalMatrix(world)
      const flip = world.determinant() < 0
      for (const prim of mesh.listPrimitives()) {
        if (prim.getMode() !== 4) continue
        const posAttr = prim.getAttribute('POSITION')
        if (!posAttr) continue
        const count = posAttr.getCount()
        const nrmAttr = prim.getAttribute('NORMAL')
        const uvAttr = prim.getAttribute('TEXCOORD_0')
        const pos = new Float32Array(count * 3)
        const nrm = new Float32Array(count * 3)
        const uv = uvAttr ? new Float32Array(count * 2) : null
        const v = new THREE.Vector3()
        const t = [0, 0, 0]
        for (let i = 0; i < count; i++) {
          posAttr.getElement(i, t)
          v.set(t[0], t[1], t[2]).applyMatrix4(world)
          pos.set([v.x, v.y, v.z], i * 3)
          if (nrmAttr) {
            nrmAttr.getElement(i, t)
            v.set(t[0], t[1], t[2]).applyMatrix3(normalMatrix).normalize()
            nrm.set([v.x, v.y, v.z], i * 3)
          }
          if (uv) {
            uvAttr.getElement(i, t)
            uv[i * 2] = t[0]
            uv[i * 2 + 1] = t[1]
          }
        }
        const idxAttr = prim.getIndices()
        let idx
        if (idxAttr) idx = Uint32Array.from(idxAttr.getArray())
        else idx = Uint32Array.from({ length: count }, (_, i) => i)
        if (flip) {
          for (let i = 0; i < idx.length; i += 3) {
            const a = idx[i + 1]
            idx[i + 1] = idx[i + 2]
            idx[i + 2] = a
          }
        }
        const material = prim.getMaterial()
        parts.push({
          node: name,
          material: material?.getName() ?? 'none',
          baseColor: material?.getBaseColorFactor() ?? [1, 1, 1, 1],
          metallic: material?.getMetallicFactor() ?? 0,
          roughness: material?.getRoughnessFactor() ?? 1,
          alphaMode: material?.getAlphaMode() ?? 'OPAQUE',
          emissive: material?.getEmissiveFactor() ?? [0, 0, 0],
          hasNormals: !!nrmAttr,
          pos,
          nrm,
          uv,
          idx,
        })
      }
    }
    for (const child of node.listChildren()) visit(child, name)
  }
  for (const node of scene.listChildren()) visit(node, '')
  return parts
}

export function partBounds(part) {
  const box = new THREE.Box3()
  const v = new THREE.Vector3()
  for (let i = 0; i < part.pos.length; i += 3) box.expandByPoint(v.fromArray(part.pos, i))
  return box
}
