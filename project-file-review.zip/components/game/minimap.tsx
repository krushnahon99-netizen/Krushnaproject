'use client'

import { useEffect, useRef } from 'react'
import { game, getFocus } from '@/lib/game/state'
import { BEACH_START, BLOCK, BLOCK_CENTERS, HALF, SHORE_X, city } from '@/lib/game/world'

const SCALE = 2
const ORIGIN = 220
const MAP_SIZE = 1040
const VIEW_SCALE = 0.42

function toMap(value: number) {
  return (value + ORIGIN) * SCALE
}

function renderBaseMap() {
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = MAP_SIZE
  const ctx = canvas.getContext('2d')!
  ctx.fillStyle = '#5f6b5c'
  ctx.fillRect(0, 0, MAP_SIZE, MAP_SIZE)
  ctx.fillStyle = '#7d8590'
  ctx.fillRect(toMap(-HALF - 12), toMap(-HALF - 12), (BEACH_START + HALF + 12) * SCALE, (HALF * 2 + 24) * SCALE)
  ctx.fillStyle = '#d9c38f'
  ctx.fillRect(toMap(BEACH_START), 0, (SHORE_X - BEACH_START) * SCALE, MAP_SIZE)
  ctx.fillStyle = '#2f7fa0'
  ctx.fillRect(toMap(SHORE_X), 0, MAP_SIZE, MAP_SIZE)

  for (const x of BLOCK_CENTERS) {
    for (const z of BLOCK_CENTERS) {
      ctx.fillStyle = '#3e4652'
      ctx.fillRect(toMap(x - BLOCK / 2), toMap(z - BLOCK / 2), BLOCK * SCALE, BLOCK * SCALE)
    }
  }
  ctx.fillStyle = '#4d7a3c'
  for (const park of city.parks) {
    ctx.fillRect(toMap(park.x - BLOCK / 2 + 2), toMap(park.z - BLOCK / 2 + 2), (BLOCK - 4) * SCALE, (BLOCK - 4) * SCALE)
  }
  ctx.fillStyle = '#2a3039'
  for (const b of city.buildings) {
    ctx.fillRect(toMap(b.x - b.w / 2), toMap(b.z - b.d / 2), b.w * SCALE, b.d * SCALE)
  }
  return canvas
}

export function Minimap() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')!
    const base = renderBaseMap()
    let frame = 0

    const draw = () => {
      const size = canvas.width
      const focus = getFocus()
      ctx.clearRect(0, 0, size, size)
      ctx.save()
      ctx.translate(size / 2, size / 2)
      ctx.rotate(Math.PI + focus.heading)
      ctx.scale(VIEW_SCALE * (size / 160), VIEW_SCALE * (size / 160))
      ctx.translate(-toMap(focus.x), -toMap(focus.z))
      ctx.drawImage(base, 0, 0)

      ctx.fillStyle = '#4ade80'
      for (const pickup of game.pickups) {
        ctx.beginPath()
        ctx.arc(toMap(pickup.x), toMap(pickup.z), 7, 0, Math.PI * 2)
        ctx.fill()
      }
      for (const car of game.cars) {
        if (car.id === game.carId) continue
        ctx.fillStyle = car.kind === 'drivable' ? '#60a5fa' : 'rgba(255,255,255,0.7)'
        ctx.beginPath()
        ctx.arc(toMap(car.x), toMap(car.z), car.kind === 'drivable' ? 5 : 3.5, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.restore()

      ctx.save()
      ctx.translate(size / 2, size / 2)
      ctx.fillStyle = '#ffffff'
      ctx.strokeStyle = '#000000'
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.moveTo(0, -9)
      ctx.lineTo(7, 7)
      ctx.lineTo(0, 3)
      ctx.lineTo(-7, 7)
      ctx.closePath()
      ctx.fill()
      ctx.stroke()
      ctx.restore()

      frame = requestAnimationFrame(draw)
    }
    frame = requestAnimationFrame(draw)
    return () => cancelAnimationFrame(frame)
  }, [])

  return (
    <div className="relative size-32 overflow-hidden rounded-full border-4 border-black/80 bg-black shadow-2xl ring-2 ring-white/10 md:size-44">
      <canvas ref={canvasRef} width={176} height={176} className="size-full" aria-label="Minimap" role="img" />
    </div>
  )
}
