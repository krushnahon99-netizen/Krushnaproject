scoreboard players set dimension aihunter_dummy 2


#assume on the tick that player travel through dimension, area in the previous dimension is still loaded.

execute unless entity @e[type=minecraft:area_effect_cloud,tag=aihunter_end_spawn] run function krushna:aihunter/dimension/aec

execute at @e[type=minecraft:area_effect_cloud,tag=aihunter_end_spawn,limit=1] run function krushna:aihunter/dimension/cross/hunter