##as @e[type=minecraft:area_effect_cloud,tag=aihunter_simulate,tag=!aihunter_register] at server
#find distance to all players

execute if score dimension aihunter_dummy matches 0 run scoreboard players operation @a[predicate=krushna:aihunter/dimension/overworld] aihunter_x1 = @s aihunter_x1

execute if score dimension aihunter_dummy matches 0 run scoreboard players operation @a[predicate=krushna:aihunter/dimension/overworld] aihunter_z1 = @s aihunter_z1

execute if score dimension aihunter_dummy matches 1 run scoreboard players operation @a[predicate=krushna:aihunter/dimension/nether] aihunter_x1 = @s aihunter_x1

execute if score dimension aihunter_dummy matches 1 run scoreboard players operation @a[predicate=krushna:aihunter/dimension/nether] aihunter_z1 = @s aihunter_z1

execute if score dimension aihunter_dummy matches 2 run scoreboard players operation @a[predicate=krushna:aihunter/dimension/end] aihunter_x1 = @s aihunter_x1

execute if score dimension aihunter_dummy matches 2 run scoreboard players operation @a[predicate=krushna:aihunter/dimension/end] aihunter_z1 = @s aihunter_z1

execute if score dimension aihunter_dummy matches 0 as @a[predicate=krushna:aihunter/dimension/overworld] run function krushna:aihunter/simulation/check/distance

execute if score dimension aihunter_dummy matches 1 as @a[predicate=krushna:aihunter/dimension/nether] run function krushna:aihunter/simulation/check/distance

execute if score dimension aihunter_dummy matches 2 as @a[predicate=krushna:aihunter/dimension/end] run function krushna:aihunter/simulation/check/distance


#make lowest aihunter_d player's score = @s

scoreboard players set @s aihunter_d 2147483647

execute if score dimension aihunter_dummy matches 0 run scoreboard players operation @s aihunter_d < @a[predicate=krushna:aihunter/dimension/overworld] aihunter_d

execute if score dimension aihunter_dummy matches 1 run scoreboard players operation @s aihunter_d < @a[predicate=krushna:aihunter/dimension/nether] aihunter_d

execute if score dimension aihunter_dummy matches 2 run scoreboard players operation @s aihunter_d < @a[predicate=krushna:aihunter/dimension/end] aihunter_d


#find target player by making its aihunter_d = 0

execute if score dimension aihunter_dummy matches 0 run scoreboard players operation @a[predicate=krushna:aihunter/dimension/overworld] aihunter_d -= @s aihunter_d

execute if score dimension aihunter_dummy matches 1 run scoreboard players operation @a[predicate=krushna:aihunter/dimension/nether] aihunter_d -= @s aihunter_d

execute if score dimension aihunter_dummy matches 2 run scoreboard players operation @a[predicate=krushna:aihunter/dimension/end] aihunter_d -= @s aihunter_d


#check if simulation ends

execute if score @s aihunter_d <= #returnrange aihunter_dummy run function krushna:aihunter/simulation/end

execute unless score pause aihunter_dummy matches 1.. unless score @s aihunter_busy matches 1.. if score dimension aihunter_dummy matches 0 if entity @p[predicate=krushna:aihunter/dimension/overworld,gamemode=!creative,gamemode=!spectator,team=!aihunter] unless score @s aihunter_d <= #returnrange aihunter_dummy run function krushna:aihunter/simulation/run

execute unless score pause aihunter_dummy matches 1.. unless score @s aihunter_busy matches 1.. if score dimension aihunter_dummy matches 1 if entity @p[predicate=krushna:aihunter/dimension/nether,gamemode=!creative,gamemode=!spectator,team=!aihunter] unless score @s aihunter_d <= #returnrange aihunter_dummy run function krushna:aihunter/simulation/run

execute unless score pause aihunter_dummy matches 1.. unless score @s aihunter_busy matches 1.. if score dimension aihunter_dummy matches 2 if entity @p[predicate=krushna:aihunter/dimension/end,gamemode=!creative,gamemode=!spectator,team=!aihunter] unless score @s aihunter_d <= #returnrange aihunter_dummy run function krushna:aihunter/simulation/run

execute unless score pause aihunter_dummy matches 1.. if score @s aihunter_busy matches 1.. run scoreboard players remove @s aihunter_busy 6


#safety measure

execute if score @s aihunter_d matches ..-1 run function krushna:aihunter/simulation/delete