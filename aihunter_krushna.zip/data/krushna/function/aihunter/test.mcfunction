advancement revoke @s only krushna:aihunter/test
say aihunter test