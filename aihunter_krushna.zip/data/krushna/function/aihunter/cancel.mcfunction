function krushna:aihunter/stop

tellraw @a {"text":"[AI Hunter] The Challenge Has Been Cancelled.","color":"red","bold":true}