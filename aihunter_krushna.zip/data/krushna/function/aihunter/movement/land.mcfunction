function krushna:aihunter/find/vector/2d

execute unless predicate krushna:aihunter/slowed run function krushna:aihunter/movement/land/run

execute if predicate krushna:aihunter/slowed run function krushna:aihunter/movement/land/couch