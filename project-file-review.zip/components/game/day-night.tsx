'use client'

import { useEffect, useLayoutEffect, useMemo, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { Sky } from '@react-three/drei'
import * as THREE from 'three'
import type { BloomEffect } from 'postprocessing'
import { game, getFocus, getPlayerCar, input } from '@/lib/game/state'
import { advanceClock, clock, lighting, sampleLighting } from '@/lib/game/time-of-day'
import { city } from '@/lib/game/world'
import { QUALITY } from '@/lib/game/quality'
import { getGlowTexture } from '@/lib/game/textures'
import { createRandom } from '@/lib/game/random'
import { markSceneReady } from '@/lib/game/loading'
import { HEADLIGHT_BEAM_MATERIAL, SHARED_CAR_MATERIALS } from './car-materials'

type SkyMesh = THREE.Mesh<THREE.BoxGeometry, THREE.ShaderMaterial>

/** Advances the in-game clock and pushes the sampled lighting into the scene every frame. */
export function TimeOfDay({
  hemi,
  shadows,
  bloom,
}: {
  hemi: React.RefObject<THREE.HemisphereLight | null>
  shadows: boolean
  bloom: React.RefObject<BloomEffect | null>
}) {
  const scene = useThree((state) => state.scene)
  const gl = useThree((state) => state.gl)
  const sky = useRef<SkyMesh>(null)
  const headlight = SHARED_CAR_MATERIALS.headlight as THREE.MeshStandardMaterial
  const reflective = useRef<{ material: THREE.MeshStandardMaterial; base: number }[]>([])
  const seen = useRef(new WeakSet<THREE.Material>())
  const scanTimer = useRef(0)
  const scansLeft = useRef(6)
  const appliedEnv = useRef(-1)

  useFrame((_, dt) => {
    if (game.started) advanceClock(Math.min(dt, 0.1), input.timeWarp)
    const l = sampleLighting(clock.hour)

    // scene.environmentIntensity is only honoured on some draw calls, so reflections are dimmed per material.
    // Materials are collected a few times while the scene streams in, then the list is final.
    scanTimer.current -= dt
    let added = false
    if (scansLeft.current > 0 && scanTimer.current <= 0) {
      scansLeft.current--
      scanTimer.current = 2
      scene.traverse((object) => {
        const material = (object as THREE.Mesh).material as THREE.MeshStandardMaterial | undefined
        if (!material || !('envMapIntensity' in material) || seen.current.has(material)) return
        seen.current.add(material)
        reflective.current.push({ material, base: material.envMapIntensity })
        added = true
      })
    }
    if (added || Math.abs(appliedEnv.current - l.envIntensity) > 0.002) {
      appliedEnv.current = l.envIntensity
      for (const entry of reflective.current) entry.material.envMapIntensity = entry.base * l.envIntensity
    }

    if (hemi.current) {
      hemi.current.color.copy(l.skyColor)
      hemi.current.groundColor.copy(l.groundColor)
      hemi.current.intensity = l.hemiIntensity * (shadows ? 1 : 2.4)
    }
    const fog = scene.fog as THREE.FogExp2 | null
    if (fog) {
      fog.color.copy(l.fogColor)
      fog.density = l.fogDensity
    }
    if (scene.background instanceof THREE.Color) scene.background.copy(l.fogColor)
    scene.environmentIntensity = l.envIntensity
    gl.toneMappingExposure = l.exposure

    const uniforms = sky.current?.material.uniforms
    if (uniforms) {
      uniforms.sunPosition.value.copy(l.sunDirection).multiplyScalar(100)
      uniforms.turbidity.value = l.turbidity
      uniforms.rayleigh.value = l.rayleigh
    }

    headlight.emissiveIntensity = 1.6 + l.night * 4
    HEADLIGHT_BEAM_MATERIAL.opacity = l.night * 0.55
    HEADLIGHT_BEAM_MATERIAL.visible = l.night > 0.02

    if (bloom.current) {
      bloom.current.intensity = 0.45 + l.night * 0.55
      bloom.current.luminanceMaterial.threshold = 1.05 - l.night * 0.2
    }
  })

  return (
    <Sky
      ref={sky}
      sunPosition={[0, 100, 0]}
      distance={4500}
      turbidity={4}
      rayleigh={1.3}
      mieCoefficient={0.004}
      mieDirectionalG={0.82}
    />
  )
}

const STAR_COUNT = 1400
const SKY_RADIUS = 1100

/** Star field and moon. Both follow the camera so they read as infinitely far away. */
export function NightSky() {
  const camera = useThree((state) => state.camera)
  const group = useRef<THREE.Group>(null)
  const stars = useRef<THREE.PointsMaterial>(null)
  const moon = useRef<THREE.Mesh>(null)
  const moonMaterial = useRef<THREE.MeshBasicMaterial>(null)
  const halo = useRef<THREE.Mesh>(null)
  const haloMaterial = useRef<THREE.MeshBasicMaterial>(null)

  const geometry = useMemo(() => {
    const random = createRandom(5)
    const positions = new Float32Array(STAR_COUNT * 3)
    const colors = new Float32Array(STAR_COUNT * 3)
    for (let i = 0; i < STAR_COUNT; i++) {
      const theta = random() * Math.PI * 2
      const y = 0.04 + random() * 0.96
      const r = Math.sqrt(1 - y * y)
      positions.set([Math.cos(theta) * r * SKY_RADIUS, y * SKY_RADIUS, Math.sin(theta) * r * SKY_RADIUS], i * 3)
      const brightness = 0.35 + random() ** 3 * 0.65
      const warm = random()
      colors.set([brightness, brightness * (0.92 + warm * 0.08), brightness * (1.05 - warm * 0.15)], i * 3)
    }
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    g.setAttribute('color', new THREE.BufferAttribute(colors, 3))
    return g
  }, [])

  const dome = useMemo(() => {
    const g = new THREE.SphereGeometry(SKY_RADIUS * 1.1, 32, 16)
    const position = g.attributes.position as THREE.BufferAttribute
    const colors = new Float32Array(position.count * 3)
    const horizon = new THREE.Color('#1c2a48')
    const zenith = new THREE.Color('#02040b')
    const c = new THREE.Color()
    for (let i = 0; i < position.count; i++) {
      const t = Math.min(1, Math.max(0, position.getY(i) / (SKY_RADIUS * 1.1)))
      c.lerpColors(horizon, zenith, Math.pow(t, 0.55))
      colors.set([c.r, c.g, c.b], i * 3)
    }
    g.setAttribute('color', new THREE.BufferAttribute(colors, 3))
    return g
  }, [])
  const domeMaterial = useRef<THREE.MeshBasicMaterial>(null)

  useEffect(
    () => () => {
      geometry.dispose()
      dome.dispose()
    },
    [geometry, dome],
  )

  useFrame((state) => {
    if (!group.current) return
    if (domeMaterial.current) {
      domeMaterial.current.opacity = Math.min(1, Math.max(0, (lighting.night - 0.2) / 0.7)) * 0.96
      domeMaterial.current.visible = domeMaterial.current.opacity > 0.01
    }
    group.current.position.copy(camera.position)
    group.current.rotation.y = (clock.hour / 24) * Math.PI * 2 * 0.25
    const starsVisible = Math.max(0, lighting.night - 0.25) / 0.75
    if (stars.current) {
      stars.current.opacity = starsVisible * (0.85 + Math.sin(state.clock.elapsedTime * 1.7) * 0.05)
      stars.current.visible = starsVisible > 0.01
    }
    const moonUp = lighting.moonDirection.y > -0.05 && lighting.night > 0.05
    if (moon.current && halo.current) {
      moon.current.visible = moonUp
      halo.current.visible = moonUp
      moon.current.position.copy(lighting.moonDirection).multiplyScalar(SKY_RADIUS * 0.95).add(camera.position)
      halo.current.position.copy(moon.current.position)
      halo.current.lookAt(camera.position)
    }
    if (moonMaterial.current) moonMaterial.current.opacity = Math.min(1, lighting.night * 1.4)
    if (haloMaterial.current) haloMaterial.current.opacity = lighting.night * 0.35
  })

  return (
    <>
      <group ref={group} rotation-y={0}>
        <mesh geometry={dome} frustumCulled={false} renderOrder={-3}>
          <meshBasicMaterial
            ref={domeMaterial}
            vertexColors
            side={THREE.BackSide}
            transparent
            opacity={0}
            fog={false}
            depthWrite={false}
          />
        </mesh>
        <points geometry={geometry} frustumCulled={false} renderOrder={-2}>
          <pointsMaterial
            ref={stars}
            size={1.7}
            sizeAttenuation={false}
            vertexColors
            transparent
            depthWrite={false}
            fog={false}
            toneMapped={false}
          />
        </points>
      </group>
      <mesh ref={moon} frustumCulled={false} renderOrder={-1}>
        <sphereGeometry args={[24, 24, 16]} />
        <meshBasicMaterial ref={moonMaterial} color="#e6ebf5" transparent fog={false} toneMapped={false} depthWrite={false} />
      </mesh>
      <mesh ref={halo} frustumCulled={false} renderOrder={-1}>
        <planeGeometry args={[220, 220]} />
        <meshBasicMaterial
          ref={haloMaterial}
          map={getGlowTexture()}
          color="#9fb4e6"
          transparent
          blending={THREE.AdditiveBlending}
          fog={false}
          toneMapped={false}
          depthWrite={false}
        />
      </mesh>
    </>
  )
}

const LAMP_HEADS = city.lamps.map((lamp) => ({
  x: lamp.x + Math.sin(lamp.rotation) * 2.3,
  z: lamp.z + Math.cos(lamp.rotation) * 2.3,
}))

/** Warm light pools under every street lamp, drawn as one additive instanced decal. */
export function LampPools() {
  const ref = useRef<THREE.InstancedMesh>(null)
  const material = useRef<THREE.MeshBasicMaterial>(null)

  useLayoutEffect(() => {
    const mesh = ref.current
    if (!mesh) return
    const dummy = new THREE.Object3D()
    LAMP_HEADS.forEach((head, i) => {
      dummy.position.set(head.x, 0.27, head.z)
      dummy.rotation.set(-Math.PI / 2, 0, 0)
      dummy.scale.set(13, 13, 1)
      dummy.updateMatrix()
      mesh.setMatrixAt(i, dummy.matrix)
    })
    mesh.instanceMatrix.needsUpdate = true
    mesh.computeBoundingSphere()
  }, [])

  useFrame(() => {
    if (!material.current || !ref.current) return
    material.current.opacity = lighting.night * 0.5
    ref.current.visible = lighting.night > 0.02
  })

  return (
    <instancedMesh ref={ref} args={[undefined, undefined, LAMP_HEADS.length]} renderOrder={1}>
      <planeGeometry />
      <meshBasicMaterial
        ref={material}
        map={getGlowTexture()}
        color="#ffb35c"
        transparent
        opacity={0}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
        toneMapped={false}
        polygonOffset
        polygonOffsetFactor={-2}
      />
    </instancedMesh>
  )
}

/**
 * A handful of real point lights that sit in the street lamps closest to the player, so cars and
 * characters are actually lit when they pass underneath. Each light fades out before it would be
 * reassigned to another lamp, so there is never a visible pop.
 */
export function LampLights() {
  const count = QUALITY.lampLights
  const lights = useRef<(THREE.PointLight | null)[]>([])
  const distances = useMemo(() => new Float32Array(LAMP_HEADS.length), [])
  const order = useMemo(() => LAMP_HEADS.map((_, i) => i), [])

  useFrame(() => {
    if (!count) return
    const focus = getFocus()
    for (let i = 0; i < LAMP_HEADS.length; i++) {
      distances[i] = Math.hypot(LAMP_HEADS[i].x - focus.x, LAMP_HEADS[i].z - focus.z)
    }
    // Partial selection sort: only the closest count + 1 lamps matter.
    for (let k = 0; k <= count && k < order.length; k++) {
      let best = k
      for (let j = k + 1; j < order.length; j++) if (distances[order[j]] < distances[order[best]]) best = j
      const tmp = order[k]
      order[k] = order[best]
      order[best] = tmp
    }
    const cutoff = distances[order[count]] ?? Infinity
    for (let k = 0; k < count; k++) {
      const light = lights.current[k]
      if (!light) continue
      const index = order[k]
      const fade = Math.min(1, Math.max(0, (cutoff - distances[index]) / 8))
      light.position.set(LAMP_HEADS[index].x, 7.1, LAMP_HEADS[index].z)
      light.intensity = lighting.night * 34 * fade
    }
  })

  return (
    <>
      {Array.from({ length: count }, (_, i) => (
        <pointLight
          key={i}
          ref={(light) => {
            lights.current[i] = light
          }}
          color="#ffc47a"
          intensity={0}
          distance={18}
          decay={2}
        />
      ))}
    </>
  )
}

/** Real spot light from the player's car so the road, buildings and traffic ahead light up at night. */
export function PlayerHeadlights() {
  const light = useRef<THREE.SpotLight>(null)
  const target = useMemo(() => new THREE.Object3D(), [])

  useFrame(() => {
    const spot = light.current
    if (!spot) return
    const car = getPlayerCar()
    if (!car) {
      spot.intensity = 0
      return
    }
    const fx = Math.sin(car.heading)
    const fz = Math.cos(car.heading)
    spot.position.set(car.x + fx * 2.1, 0.8, car.z + fz * 2.1)
    target.position.set(car.x + fx * 22, 0, car.z + fz * 22)
    target.updateMatrixWorld()
    spot.intensity = lighting.night * 650
  })

  return (
    <>
      <primitive object={target} />
      <spotLight
        ref={light}
        target={target}
        color="#fff0d8"
        intensity={0}
        distance={70}
        angle={0.62}
        penumbra={0.75}
        decay={2}
      />
    </>
  )
}

/**
 * Uploads every texture and compiles every shader before the player can press Play,
 * so the first seconds of gameplay do not hitch on lazy GPU work.
 */
export function WarmUp() {
  const gl = useThree((state) => state.gl)
  const scene = useThree((state) => state.scene)
  const camera = useThree((state) => state.camera)

  useEffect(() => {
    let cancelled = false
    const hidden: THREE.Object3D[] = []
    const textures = new Set<THREE.Texture>()
    scene.traverse((object) => {
      if (!object.visible) {
        hidden.push(object)
        object.visible = true
      }
      const material = (object as THREE.Mesh).material
      if (!material) return
      for (const m of Array.isArray(material) ? material : [material]) {
        for (const value of Object.values(m)) if (value instanceof THREE.Texture) textures.add(value)
      }
    })
    textures.forEach((texture) => gl.initTexture(texture))
    const compiled = gl.compileAsync(scene, camera)
    hidden.forEach((object) => (object.visible = false))
    compiled
      .catch(() => undefined)
      .then(() => {
        // Let a couple of real frames render (shadow + post passes) before unlocking Play.
        requestAnimationFrame(() => requestAnimationFrame(() => !cancelled && markSceneReady()))
      })
    return () => {
      cancelled = true
    }
  }, [gl, scene, camera])

  return null
}
