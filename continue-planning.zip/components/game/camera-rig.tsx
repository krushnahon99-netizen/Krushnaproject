'use client'

import { useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { game, getFocus, getPlayerCar, input } from '@/lib/game/state'
import { updateGame } from '@/lib/game/update'
import { city } from '@/lib/game/world'
import { QUALITY } from '@/lib/game/quality'

const SUN_DIRECTION = new THREE.Vector3(120, 170, -90).normalize()
const SHADOW_EXTENT = 85
const LIGHT_RIGHT = new THREE.Vector3().crossVectors(new THREE.Vector3(0, 1, 0), SUN_DIRECTION).normalize()
const LIGHT_UP = new THREE.Vector3().crossVectors(SUN_DIRECTION, LIGHT_RIGHT).normalize()

const buildingBoxes = city.buildings.map((b) => ({
  minX: b.x - b.w / 2,
  maxX: b.x + b.w / 2,
  minZ: b.z - b.d / 2,
  maxZ: b.z + b.d / 2,
  h: b.h,
}))

function insideBuilding(x: number, y: number, z: number) {
  return buildingBoxes.some((b) => x > b.minX - 0.6 && x < b.maxX + 0.6 && z > b.minZ - 0.6 && z < b.maxZ + 0.6 && y < b.h + 1)
}

/** Vertical FOV needed so narrow/portrait screens still see at least `horizontalDeg` across. */
function minVerticalFov(horizontalDeg: number, aspect: number) {
  const half = THREE.MathUtils.degToRad(horizontalDeg / 2)
  return THREE.MathUtils.radToDeg(2 * Math.atan(Math.tan(half) / aspect))
}

/** Frame-rate independent smoothing factor. */
function damp(rate: number, dt: number) {
  return 1 - Math.exp(-rate * dt)
}

export function GameLoop() {
  const smoothDt = useRef(1 / 60)
  useFrame((_, dt) => {
    // rAF deltas jitter by a few ms even at a steady frame rate; averaging keeps motion even.
    const clamped = Math.min(dt, 0.05)
    smoothDt.current += (clamped - smoothDt.current) * 0.3
    updateGame(Math.abs(clamped - smoothDt.current) > 0.012 ? clamped : smoothDt.current)
  })
  return null
}

export function CameraRig() {
  const camera = useThree((state) => state.camera) as THREE.PerspectiveCamera
  const yaw = useRef(0)
  const lookTarget = useRef(new THREE.Vector3())
  const initialized = useRef(false)
  const running = useRef(0)
  const carSpeed = useRef(0)
  const clearance = useRef(1)

  useFrame((state, dt) => {
    const focus = getFocus()
    const car = getPlayerCar()
    const speed = car ? Math.hypot(car.vx, car.vz) : 0
    if (input.lookHeld || (!car && input.stickActive)) {
      input.lookIdle = 0
    } else {
      input.lookIdle += dt
      const recenterDelay = car && speed > 4 ? 0.8 : 2.5
      if (input.lookIdle > recenterDelay) {
        const decay = Math.exp(-dt * 1.6)
        input.cameraDrag = Math.atan2(Math.sin(input.cameraDrag), Math.cos(input.cameraDrag)) * decay
        input.cameraPitch *= decay
      }
    }
    const targetYaw = focus.heading + input.cameraDrag
    let delta = targetYaw - yaw.current
    delta = Math.atan2(Math.sin(delta), Math.cos(delta))
    yaw.current += delta * damp(input.lookHeld ? 14 : car ? 3.2 : 5, dt)

    const run = car ? 0 : Math.min(1, Math.max(0, (Math.abs(game.player.speed) - 4.6) / 3.9))
    running.current += (run - running.current) * damp(4, dt)
    carSpeed.current += (Math.min(speed, 46) - carSpeed.current) * damp(2.5, dt)
    const smoothSpeed = car ? carSpeed.current : 0

    const baseDistance = car ? 6.6 + smoothSpeed * 0.04 : 3.4 + running.current * 0.7
    const baseHeight = car ? 2.05 + smoothSpeed * 0.008 : 0.35
    const focusY = car ? 1.1 : game.player.y + 1.55
    const shoulder = car ? 0 : 0.45

    const orbit = Math.atan2(baseHeight, baseDistance) + input.cameraPitch
    const radius = Math.hypot(baseHeight, baseDistance)
    const distance = Math.cos(orbit) * radius
    const height = Math.max(0.4 - focusY + 0.5, Math.sin(orbit) * radius)
    const rightX = -Math.cos(yaw.current) * shoulder
    const rightZ = Math.sin(yaw.current) * shoulder

    const offX = -Math.sin(yaw.current) * distance + rightX
    const offY = height
    const offZ = -Math.cos(yaw.current) * distance + rightZ

    let clear = 1
    const steps = 10
    for (let i = 1; i <= steps; i++) {
      const t = i / steps
      if (insideBuilding(focus.x + offX * t, focusY + offY * t, focus.z + offZ * t)) {
        clear = Math.max(0.15, (i - 1) / steps)
        break
      }
    }
    if (!initialized.current) {
      yaw.current = targetYaw
      clearance.current = clear
      initialized.current = true
    }
    // Pull in fast when a wall blocks the view, ease back out slowly so the camera never pops.
    clearance.current += (clear - clearance.current) * damp(clear < clearance.current ? 18 : 3, dt)
    const c = clearance.current
    const lift = (1 - c) * 0.7

    // The camera is rigidly attached to the focus point; only yaw, distance and FOV are smoothed.
    // Chasing a moving target with a position lerp causes judder whenever frame times vary.
    camera.position.set(focus.x + offX * c, focusY + offY * c + lift, focus.z + offZ * c)

    if (game.shake > 0) {
      const t = state.clock.elapsedTime * 60
      camera.position.x += Math.sin(t) * game.shake * 0.25
      camera.position.y += Math.cos(t * 1.3) * game.shake * 0.25
    }

    const ahead = car ? 4 : 1.6
    lookTarget.current.set(
      focus.x + Math.sin(yaw.current) * ahead + rightX,
      focusY + (car ? 0.45 : 0.1),
      focus.z + Math.cos(yaw.current) * ahead + rightZ,
    )
    camera.lookAt(lookTarget.current)

    const verticalFov = car ? 56 + smoothSpeed * 0.26 : 52 + running.current * 7
    const horizontalFov = car ? 88 : 80
    const targetFov = Math.min(95, Math.max(verticalFov, minVerticalFov(horizontalFov, camera.aspect)))
    const nextFov = camera.fov + (targetFov - camera.fov) * damp(3, dt)
    if (Math.abs(nextFov - camera.fov) > 0.001) {
      camera.fov = nextFov
      camera.updateProjectionMatrix()
    }
  })

  return null
}

export function SunLight() {
  const light = useRef<THREE.DirectionalLight>(null)
  const target = useRef(new THREE.Object3D())

  useFrame(() => {
    const focus = getFocus()
    if (!light.current) return
    // Snap to whole shadow-map texels in light space so shadows follow smoothly without shimmering.
    const texel = (SHADOW_EXTENT * 2) / QUALITY.shadowMapSize
    const u = Math.round((focus.x * LIGHT_RIGHT.x + focus.z * LIGHT_RIGHT.z) / texel) * texel
    const v = Math.round((focus.x * LIGHT_UP.x + focus.z * LIGHT_UP.z) / texel) * texel
    const det = LIGHT_RIGHT.x * LIGHT_UP.z - LIGHT_RIGHT.z * LIGHT_UP.x
    const x = (u * LIGHT_UP.z - v * LIGHT_RIGHT.z) / det
    const z = (v * LIGHT_RIGHT.x - u * LIGHT_UP.x) / det
    target.current.position.set(x, 0, z)
    target.current.updateMatrixWorld()
    light.current.position.set(x + SUN_DIRECTION.x * 150, SUN_DIRECTION.y * 150, z + SUN_DIRECTION.z * 150)
    light.current.target = target.current
  })

  return (
    <>
      <primitive object={target.current} />
      <directionalLight
        ref={light}
        color="#fff1de"
        intensity={3.6}
        castShadow
        shadow-mapSize={[QUALITY.shadowMapSize, QUALITY.shadowMapSize]}
        shadow-camera-left={-85}
        shadow-camera-right={85}
        shadow-camera-top={85}
        shadow-camera-bottom={-85}
        shadow-camera-near={10}
        shadow-camera-far={450}
        shadow-bias={-0.0003}
        shadow-normalBias={0.05}
      />
    </>
  )
}

export const SUN_POSITION: [number, number, number] = [SUN_DIRECTION.x * 100, SUN_DIRECTION.y * 100, SUN_DIRECTION.z * 100]
