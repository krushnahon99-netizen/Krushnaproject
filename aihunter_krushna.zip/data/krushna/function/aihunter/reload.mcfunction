# Kill stale nametag entities from previous versions
kill @e[type=minecraft:text_display,tag=aihunter_name]
# Clear old JSON name from storage
data remove storage minecraft:aihunter_custom name

function krushna:aihunter/set

function krushna:aihunter_set/set

execute as @a run function krushna:aihunter/menu