##as at @e[type=minecraft:vindicator,tag=aihunter]
#set

scoreboard players set @s aihunter_upgrade 4

attribute @s minecraft:armor base set 18

attribute @s minecraft:armor_toughness base set 4

data merge entity @s {HandItems:[{},{}]}

execute unless data storage minecraft:aihunter_custom armor run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] {equipment:{feet:{id:"minecraft:iron_boots"},legs:{id:"minecraft:diamond_leggings"},chest:{id:"minecraft:diamond_chestplate"},head:{id:"minecraft:skeleton_skull"}}}


scoreboard players add @s aihunter_arrow 12


#message

execute if score notifyupgrade aihunter_dummy matches 1.. run function krushna:aihunter/message/upgrade