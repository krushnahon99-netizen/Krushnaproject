'use client'

import { useEffect, useState, useSyncExternalStore } from 'react'
import dynamic from 'next/dynamic'
import { input, startGame } from '@/lib/game/state'
import { markSceneReady, sceneReadyStore } from '@/lib/game/loading'
import { Hud } from './hud'
import { TouchControls } from './touch-controls'
import { StartScreen } from './start-screen'
import { RotateOverlay } from './rotate-overlay'
import { GraphicsNotice } from './graphics-notice'

const Scene = dynamic(() => import('./scene'), { ssr: false })

const KEY_MAP: Record<string, 'forward' | 'back' | 'left' | 'right' | 'handbrake' | 'sprint' | 'timeWarp'> = {
  KeyT: 'timeWarp',
  KeyW: 'forward',
  ArrowUp: 'forward',
  KeyS: 'back',
  ArrowDown: 'back',
  KeyA: 'left',
  ArrowLeft: 'left',
  KeyD: 'right',
  ArrowRight: 'right',
  Space: 'handbrake',
  ShiftLeft: 'sprint',
  ShiftRight: 'sprint',
}

async function enterLandscape() {
  if (!window.matchMedia('(pointer: coarse)').matches) return
  try {
    if (!document.fullscreenElement) await document.documentElement.requestFullscreen?.()
    const orientation = screen.orientation as ScreenOrientation & { lock?: (o: string) => Promise<void> }
    await orientation.lock?.('landscape')
  } catch {
    // Some browsers (iOS Safari, embedded previews) refuse fullscreen or orientation lock; the rotate overlay covers them.
  }
}

export function Game() {
  const [started, setStarted] = useState(false)
  const ready = useSyncExternalStore(sceneReadyStore.subscribe, sceneReadyStore.getSnapshot, sceneReadyStore.getServerSnapshot)

  useEffect(() => {
    // Safety net for drivers without async shader compilation: never block Play forever.
    const timer = setTimeout(markSceneReady, 15000)
    const onKey = (pressed: boolean) => (event: KeyboardEvent) => {
      if (event.code === 'KeyF' || event.code === 'KeyE') {
        if (pressed && !event.repeat) input.interactQueued = true
        return
      }
      const key = KEY_MAP[event.code]
      if (!key) return
      event.preventDefault()
      input[key] = pressed
    }
    const down = onKey(true)
    const up = onKey(false)
    const reset = () => {
      Object.values(KEY_MAP).forEach((key) => (input[key] = false))
    }
    window.addEventListener('keydown', down)
    window.addEventListener('keyup', up)
    window.addEventListener('blur', reset)
    return () => {
      clearTimeout(timer)
      window.removeEventListener('keydown', down)
      window.removeEventListener('keyup', up)
      window.removeEventListener('blur', reset)
    }
  }, [])

  return (
    <main className="fixed inset-0 overflow-hidden bg-black">
      <h1 className="sr-only">Vice Shores open world game</h1>
      <Scene />
      <Hud />
      <TouchControls />
      {!started && (
        <StartScreen
          ready={ready}
          onStart={() => {
            enterLandscape()
            startGame()
            setStarted(true)
          }}
        />
      )}
      <GraphicsNotice />
      <RotateOverlay />
    </main>
  )
}
