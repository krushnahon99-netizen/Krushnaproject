execute if block ~ ~ ~ minecraft:pale_oak_slab[waterlogged=true] run setblock ~ ~ ~ minecraft:pale_oak_slab[waterlogged=false] replace
execute if block ~ ~ ~ minecraft:tuff_slab[waterlogged=true] run setblock ~ ~ ~ minecraft:tuff_slab[waterlogged=false] replace
execute if block ~ ~ ~ minecraft:polished_tuff_slab[waterlogged=true] run setblock ~ ~ ~ minecraft:polished_tuff_slab[waterlogged=false] replace
execute if block ~ ~ ~ minecraft:tuff_brick_slab[waterlogged=true] run setblock ~ ~ ~ minecraft:tuff_brick_slab[waterlogged=false] replace
