import { createRandom, pick } from './random'

export const CELL = 60
export const ROAD = 16
export const BLOCK = CELL - ROAD
export const GRID = 6
export const HALF = (GRID * CELL) / 2
export const ROAD_LINES = Array.from({ length: GRID + 1 }, (_, i) => -HALF + i * CELL)
export const BLOCK_CENTERS = Array.from({ length: GRID }, (_, i) => -HALF + CELL / 2 + i * CELL)
export const BEACH_START = HALF + ROAD / 2
export const SHORE_X = 238
export const LANE_OFFSET = 4
export const SIDEWALK = 3

export const WORLD_BOUNDS = {
  minX: -HALF - 14,
  maxX: SHORE_X - 2,
  minZ: -HALF - 14,
  maxZ: HALF + 14,
}

export type Box = { minX: number; maxX: number; minZ: number; maxZ: number }

export type BuildingStyle = 'glass' | 'stucco' | 'concrete'

export type Building = {
  x: number
  z: number
  w: number
  d: number
  h: number
  style: BuildingStyle
  color: [number, number, number]
  tier: { w: number; d: number; h: number } | null
  neon: [number, number, number] | null
  uvOffset: [number, number]
}

export type City = {
  buildings: Building[]
  colliders: Box[]
  parks: { x: number; z: number }[]
  palms: { x: number; z: number; scale: number; lean: number }[]
  lamps: { x: number; z: number; rotation: number }[]
}

const STUCCO: [number, number, number][] = [
  [1, 1, 1],
  [1, 0.97, 0.9],
  [1, 0.9, 0.82],
  [0.88, 0.97, 0.93],
  [1, 0.94, 0.8],
  [0.96, 0.9, 0.9],
  [0.92, 0.94, 0.98],
]

const CONCRETE: [number, number, number][] = [
  [1, 1, 1],
  [0.92, 0.92, 0.92],
  [0.98, 0.94, 0.88],
  [0.82, 0.82, 0.84],
]

const GLASS_TOWERS: [number, number, number][] = [
  [1, 1, 1],
  [0.82, 0.92, 0.9],
  [0.78, 0.8, 0.86],
  [0.95, 0.92, 0.85],
]

const NEON: [number, number, number][] = [
  [2.2, 0.35, 1.4],
  [0.25, 1.8, 2.2],
  [2.2, 0.9, 0.3],
  [1.3, 0.35, 2.2],
]

export function isNearIntersection(value: number, margin: number) {
  return ROAD_LINES.some((line) => Math.abs(value - line) < margin)
}

export function generateCity(seed = 1986): City {
  const random = createRandom(seed)
  const buildings: Building[] = []
  const colliders: Box[] = []
  const parks: City['parks'] = []
  const palms: City['palms'] = []
  const lamps: City['lamps'] = []

  const addPalm = (x: number, z: number) => {
    palms.push({ x, z, scale: 0.85 + random() * 0.45, lean: (random() - 0.5) * 0.25 })
    colliders.push({ minX: x - 0.4, maxX: x + 0.4, minZ: z - 0.4, maxZ: z + 0.4 })
  }

  const interior = BLOCK - SIDEWALK * 2

  BLOCK_CENTERS.forEach((cx, i) => {
    BLOCK_CENTERS.forEach((cz, j) => {
      const isBeachfront = i === GRID - 1
      const isPark = (i === 2 && j === 3) || (i === 0 && j === 1) || (!isBeachfront && random() < 0.08)

      if (isPark) {
        parks.push({ x: cx, z: cz })
        for (let p = 0; p < 9; p++) {
          addPalm(cx + (random() - 0.5) * (interior - 6), cz + (random() - 0.5) * (interior - 6))
        }
        return
      }

      const distance = Math.hypot(cx + 30, cz)
      const skyline = Math.exp(-distance / 110)
      const fullLot = !isBeachfront && skyline > 0.55 && random() < 0.6

      const lots: { x: number; z: number; size: number }[] = fullLot
        ? [{ x: cx, z: cz, size: interior }]
        : [
            { x: cx - interior / 4, z: cz - interior / 4, size: interior / 2 },
            { x: cx + interior / 4, z: cz - interior / 4, size: interior / 2 },
            { x: cx - interior / 4, z: cz + interior / 4, size: interior / 2 },
            { x: cx + interior / 4, z: cz + interior / 4, size: interior / 2 },
          ]

      lots.forEach((lot) => {
        const inset = fullLot ? 2 : 1 + random() * 1.5
        const w = lot.size - inset * 2 - random() * 2
        const d = lot.size - inset * 2 - random() * 2
        const isTower = fullLot || random() < skyline * 0.7
        let h: number
        if (isBeachfront) h = 9 + random() * 14
        else if (isTower) h = 30 + skyline * 90 * (0.6 + random() * 0.6)
        else h = 8 + random() * 18 + skyline * 20

        const style: BuildingStyle =
          isTower && random() < 0.6 ? 'glass' : (isTower || h > 28 ? random() < 0.6 : random() < 0.22) ? 'concrete' : 'stucco'
        const color = pick(random, style === 'glass' ? GLASS_TOWERS : style === 'concrete' ? CONCRETE : STUCCO)
        const tier =
          h > 35 && random() < 0.7 ? { w: w * (0.55 + random() * 0.2), d: d * (0.55 + random() * 0.2), h: h * (0.15 + random() * 0.2) } : null
        const neon = h < 26 && random() < (isBeachfront ? 0.85 : 0.35) ? pick(random, NEON) : null

        buildings.push({
          x: lot.x,
          z: lot.z,
          w,
          d,
          h,
          style,
          color,
          tier,
          neon,
          uvOffset: [Math.floor(random() * 4) / 4, Math.floor(random() * 4) / 4],
        })
        colliders.push({ minX: lot.x - w / 2, maxX: lot.x + w / 2, minZ: lot.z - d / 2, maxZ: lot.z + d / 2 })
      })
    })
  })

  for (let z = -HALF + 6; z <= HALF - 6; z += 13) {
    if (!isNearIntersection(z, 10)) addPalm(BEACH_START + 5, z)
  }
  for (let z = -HALF + 12; z <= HALF - 12; z += 26) {
    addPalm(BEACH_START + 22 + random() * 8, z + random() * 8)
  }

  ROAD_LINES.forEach((line) => {
    for (let s = -HALF + 15; s < HALF; s += 30) {
      if (isNearIntersection(s, 10)) continue
      lamps.push({ x: line - ROAD / 2 - 1.2, z: s, rotation: Math.PI / 2 })
      lamps.push({ x: s, z: line + ROAD / 2 + 1.2, rotation: Math.PI })
    }
  })

  return { buildings, colliders, parks, palms, lamps }
}

export const city = generateCity()

export function randomRoadPoint(random: () => number = Math.random) {
  const line = ROAD_LINES[Math.floor(random() * ROAD_LINES.length)]
  const center = BLOCK_CENTERS[Math.floor(random() * BLOCK_CENTERS.length)]
  const along = center + (random() - 0.5) * (BLOCK - 10)
  const lane = (random() < 0.5 ? -1 : 1) * LANE_OFFSET
  return random() < 0.5 ? { x: line + lane, z: along } : { x: along, z: line + lane }
}

export function buildTrafficLoop(i1: number, i2: number, j1: number, j2: number, clockwise: boolean) {
  const x1 = ROAD_LINES[i1]
  const x2 = ROAD_LINES[i2]
  const z1 = ROAD_LINES[j1]
  const z2 = ROAD_LINES[j2]
  let corners = [
    { x: x1, z: z1 },
    { x: x2, z: z1 },
    { x: x2, z: z2 },
    { x: x1, z: z2 },
  ]
  if (!clockwise) corners = corners.reverse()

  return corners.map((corner, index) => {
    const prev = corners[(index + corners.length - 1) % corners.length]
    const next = corners[(index + 1) % corners.length]
    const inRight = rightOf(corner.x - prev.x, corner.z - prev.z)
    const outRight = rightOf(next.x - corner.x, next.z - corner.z)
    return {
      x: corner.x + (inRight.x + outRight.x) * LANE_OFFSET,
      z: corner.z + (inRight.z + outRight.z) * LANE_OFFSET,
    }
  })
}

function rightOf(dx: number, dz: number) {
  const length = Math.hypot(dx, dz) || 1
  const fx = dx / length
  const fz = dz / length
  return { x: -fz, z: fx }
}
