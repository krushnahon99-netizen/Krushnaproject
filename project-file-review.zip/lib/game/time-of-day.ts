import * as THREE from 'three'

/**
 * GTA V pacing: one in-game minute every two real seconds, so a full day lasts 48 real minutes.
 * Holding the time-warp key runs the clock 60x faster (one in-game hour every two seconds).
 */
export const GAME_MINUTES_PER_SECOND = 0.5
export const TIME_WARP = 60
const DEFAULT_START_HOUR = 9

function initialHour() {
  if (typeof window === 'undefined') return DEFAULT_START_HOUR
  const requested = Number(new URLSearchParams(window.location.search).get('hour'))
  return Number.isFinite(requested) && requested > 0 && requested < 24 ? requested : DEFAULT_START_HOUR
}

export const START_HOUR = initialHour()

export const clock = { hour: START_HOUR }

export function advanceClock(dt: number, warp: boolean) {
  const hours = (dt * GAME_MINUTES_PER_SECOND * (warp ? TIME_WARP : 1)) / 60
  clock.hour = (clock.hour + hours) % 24
}

export function formatClock(hour: number) {
  const total = Math.floor(hour * 60)
  const h = Math.floor(total / 60) % 24
  const m = total % 60
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`
}

const PHASES: [number, string][] = [
  [1, 'Midnight'],
  [5, 'Late night'],
  [6.3, 'Dawn'],
  [8, 'Sunrise'],
  [12, 'Morning'],
  [14, 'Noon'],
  [17.6, 'Afternoon'],
  [19.2, 'Golden hour'],
  [20.3, 'Sunset'],
  [22, 'Evening'],
  [24, 'Night'],
]

export function phaseName(hour: number) {
  return PHASES.find(([end]) => hour < end)?.[1] ?? 'Night'
}

type Keyframe = {
  h: number
  light: string
  lightIntensity: number
  sky: string
  ground: string
  hemi: number
  fog: string
  fogDensity: number
  env: number
  night: number
  turbidity: number
  rayleigh: number
  exposure: number
}

/** Hand-tuned lighting moods across the day. Values between keyframes are interpolated. */
const KEYFRAMES: Keyframe[] = [
  { h: 0, light: '#7d98d8', lightIntensity: 0.2, sky: '#2e4274', ground: '#0c0e14', hemi: 0.75, fog: '#0b1322', fogDensity: 0.0019, env: 0.035, night: 1, turbidity: 2, rayleigh: 0.4, exposure: 1.1 },
  { h: 4.8, light: '#7d98d8', lightIntensity: 0.2, sky: '#2e4274', ground: '#0d0f16', hemi: 0.75, fog: '#0f1a2e', fogDensity: 0.0019, env: 0.035, night: 1, turbidity: 2, rayleigh: 0.5, exposure: 1.1 },
  { h: 5.6, light: '#8d9fd0', lightIntensity: 0.1, sky: '#3c5180', ground: '#1a1b24', hemi: 0.5, fog: '#4a5a80', fogDensity: 0.0018, env: 0.1, night: 0.85, turbidity: 3, rayleigh: 2.2, exposure: 1.1 },
  { h: 6.0, light: '#ff9a5a', lightIntensity: 0.02, sky: '#6c709c', ground: '#2a2428', hemi: 0.55, fog: '#a27c84', fogDensity: 0.0017, env: 0.3, night: 0.55, turbidity: 6, rayleigh: 3, exposure: 1.08 },
  { h: 6.6, light: '#ffa868', lightIntensity: 1.6, sky: '#a2b2d2', ground: '#6a5040', hemi: 0.58, fog: '#e2aa8a', fogDensity: 0.0016, env: 0.7, night: 0.12, turbidity: 7, rayleigh: 2.6, exposure: 1.05 },
  { h: 8, light: '#ffe2c0', lightIntensity: 2.9, sky: '#bed3ec', ground: '#6e604c', hemi: 0.5, fog: '#c6d3df', fogDensity: 0.0013, env: 0.95, night: 0, turbidity: 5, rayleigh: 1.6, exposure: 1.05 },
  { h: 12.5, light: '#fff6ea', lightIntensity: 3.8, sky: '#cfe0f5', ground: '#6e604c', hemi: 0.45, fog: '#b8c9d8', fogDensity: 0.0012, env: 1, night: 0, turbidity: 4, rayleigh: 1.3, exposure: 1.05 },
  { h: 16, light: '#fff0d8', lightIntensity: 3.4, sky: '#c9daee', ground: '#72624c', hemi: 0.46, fog: '#c2cbd2', fogDensity: 0.0012, env: 1, night: 0, turbidity: 5, rayleigh: 1.5, exposure: 1.05 },
  { h: 18.3, light: '#ffc27a', lightIntensity: 2.6, sky: '#c9bbbd', ground: '#7a5a40', hemi: 0.5, fog: '#e8b68c', fogDensity: 0.0014, env: 0.85, night: 0, turbidity: 8, rayleigh: 2.2, exposure: 1.05 },
  { h: 19.4, light: '#ff7838', lightIntensity: 1.3, sky: '#a27c92', ground: '#4a3028', hemi: 0.5, fog: '#d27c5c', fogDensity: 0.0016, env: 0.45, night: 0.35, turbidity: 10, rayleigh: 3, exposure: 1.06 },
  { h: 20.0, light: '#ff6a40', lightIntensity: 0.02, sky: '#4c4c7a', ground: '#201a22', hemi: 0.46, fog: '#5c4c6a', fogDensity: 0.0017, env: 0.12, night: 0.75, turbidity: 6, rayleigh: 2.4, exposure: 1.1 },
  { h: 20.8, light: '#7d98d8', lightIntensity: 0.18, sky: '#23315c', ground: '#0e1018', hemi: 0.72, fog: '#1a233a', fogDensity: 0.0018, env: 0.04, night: 1, turbidity: 3, rayleigh: 0.8, exposure: 1.1 },
  { h: 24, light: '#7d98d8', lightIntensity: 0.2, sky: '#2e4274', ground: '#0c0e14', hemi: 0.75, fog: '#0b1322', fogDensity: 0.0019, env: 0.035, night: 1, turbidity: 2, rayleigh: 0.4, exposure: 1.1 },
]

const COLORS = KEYFRAMES.map((k) => ({
  light: new THREE.Color(k.light),
  sky: new THREE.Color(k.sky),
  ground: new THREE.Color(k.ground),
  fog: new THREE.Color(k.fog),
}))

/** Mutable lighting state, rewritten every frame to avoid allocations. */
export const lighting = {
  hour: START_HOUR,
  sunDirection: new THREE.Vector3(),
  moonDirection: new THREE.Vector3(),
  /** Direction of whichever body currently lights the scene, with a minimum elevation for sane shadows. */
  lightDirection: new THREE.Vector3(0, 1, 0),
  lightColor: new THREE.Color(),
  lightIntensity: 1,
  skyColor: new THREE.Color(),
  groundColor: new THREE.Color(),
  hemiIntensity: 0.5,
  fogColor: new THREE.Color(),
  fogDensity: 0.0012,
  envIntensity: 1,
  /** 0 during the day, 1 at full night. Drives street lamps, windows and headlights. */
  night: 0,
  turbidity: 4,
  rayleigh: 1.3,
  exposure: 1.05,
}

const lerp = (a: number, b: number, t: number) => a + (b - a) * t
const smooth = (t: number) => t * t * (3 - 2 * t)

export function sampleLighting(hour: number) {
  let i = 0
  while (i < KEYFRAMES.length - 2 && hour >= KEYFRAMES[i + 1].h) i++
  const a = KEYFRAMES[i]
  const b = KEYFRAMES[i + 1]
  const t = smooth(Math.min(1, Math.max(0, (hour - a.h) / (b.h - a.h))))
  const ca = COLORS[i]
  const cb = COLORS[i + 1]

  lighting.hour = hour
  lighting.lightColor.lerpColors(ca.light, cb.light, t)
  lighting.skyColor.lerpColors(ca.sky, cb.sky, t)
  lighting.groundColor.lerpColors(ca.ground, cb.ground, t)
  lighting.fogColor.lerpColors(ca.fog, cb.fog, t)
  lighting.lightIntensity = lerp(a.lightIntensity, b.lightIntensity, t)
  lighting.hemiIntensity = lerp(a.hemi, b.hemi, t)
  lighting.fogDensity = lerp(a.fogDensity, b.fogDensity, t)
  lighting.envIntensity = lerp(a.env, b.env, t)
  lighting.night = lerp(a.night, b.night, t)
  lighting.turbidity = lerp(a.turbidity, b.turbidity, t)
  lighting.rayleigh = lerp(a.rayleigh, b.rayleigh, t)
  lighting.exposure = lerp(a.exposure, b.exposure, t)

  // Sun rises over the ocean in the east (+x) at 06:00 and sets in the west at 20:00, arcing through the south.
  const dayArc = ((hour - 6) / 14) * Math.PI
  lighting.sunDirection.set(Math.cos(dayArc), Math.sin(dayArc) * 0.88, -0.38 * Math.max(0, Math.sin(dayArc)) - 0.12).normalize()
  const nightArc = ((((hour - 20) % 24) + 24) % 24 / 10) * Math.PI
  lighting.moonDirection.set(Math.cos(nightArc) * 0.9, Math.sin(nightArc) * 0.72, 0.32).normalize()

  const source = lighting.sunDirection.y > 0 ? lighting.sunDirection : lighting.moonDirection
  lighting.lightDirection.copy(source)
  if (lighting.lightDirection.y < 0.16) {
    lighting.lightDirection.y = 0.16
    lighting.lightDirection.normalize()
  }
  return lighting
}

sampleLighting(START_HOUR)
