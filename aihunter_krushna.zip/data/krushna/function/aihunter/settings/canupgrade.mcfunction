
scoreboard players add canupgrade aihunter_dummy 1

execute unless score canupgrade aihunter_dummy matches 0..1 run scoreboard players set canupgrade aihunter_dummy 0

function krushna:aihunter/settings/menu/2



