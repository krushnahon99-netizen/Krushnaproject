'use client'

import { useLayoutEffect, useMemo, useRef } from 'react'
import { useTexture } from '@react-three/drei'
import * as THREE from 'three'
import { city } from '@/lib/game/world'
import { TEXTURE_URLS, createFrondTexture, createNormalMap, setupTiling } from '@/lib/game/textures'

const FRONDS = 11
const TRUNK_HEIGHT = 9
const FROND_LENGTH = 4.4
const FROND_WIDTH = 1.9

function createFrondGeometry() {
  const geometry = new THREE.PlaneGeometry(FROND_WIDTH, FROND_LENGTH, 4, 10)
  geometry.translate(0, FROND_LENGTH / 2, 0)
  const position = geometry.attributes.position as THREE.BufferAttribute
  for (let i = 0; i < position.count; i++) {
    const along = position.getY(i) / FROND_LENGTH
    const across = position.getX(i)
    position.setXYZ(i, across, -along * along * 2.1 + Math.abs(across) * 0.35, along * FROND_LENGTH)
  }
  geometry.computeVertexNormals()
  return geometry
}

export function Palms() {
  const trunkRef = useRef<THREE.InstancedMesh>(null)
  const frondRef = useRef<THREE.InstancedMesh>(null)
  const bark = useTexture(TEXTURE_URLS.bark)

  const { frondGeometry, frondMaterial, frondDepth, trunkMaterial } = useMemo(() => {
    const frondMap = createFrondTexture()
    setupTiling(bark, 1, 3)
    return {
      frondGeometry: createFrondGeometry(),
      frondMaterial: new THREE.MeshStandardMaterial({
        map: frondMap,
        alphaTest: 0.45,
        side: THREE.DoubleSide,
        roughness: 0.75,
      }),
      frondDepth: new THREE.MeshDepthMaterial({
        depthPacking: THREE.RGBADepthPacking,
        map: frondMap,
        alphaTest: 0.45,
        side: THREE.DoubleSide,
      }),
      trunkMaterial: new THREE.MeshStandardMaterial({
        map: bark,
        normalMap: createNormalMap(bark, 4),
        roughness: 0.95,
      }),
    }
  }, [bark])

  useLayoutEffect(() => {
    const trunk = trunkRef.current
    const fronds = frondRef.current
    if (!trunk || !fronds) return
    fronds.customDepthMaterial = frondDepth
    const dummy = new THREE.Object3D()
    const color = new THREE.Color()
    let frondIndex = 0

    city.palms.forEach((palm, i) => {
      const height = TRUNK_HEIGHT * palm.scale
      dummy.position.set(palm.x + Math.sin(palm.lean) * height * 0.5, height / 2, palm.z)
      dummy.rotation.set(0, 0, -palm.lean)
      dummy.scale.set(palm.scale, palm.scale, palm.scale)
      dummy.updateMatrix()
      trunk.setMatrixAt(i, dummy.matrix)

      const topX = palm.x + Math.sin(palm.lean) * height
      const topY = Math.cos(palm.lean) * height
      for (let f = 0; f < FRONDS; f++) {
        const yaw = (f / FRONDS) * Math.PI * 2 + i
        dummy.position.set(topX, topY, palm.z)
        dummy.rotation.set(0, yaw, 0)
        dummy.rotateX(-0.45 + (f % 3) * 0.18)
        dummy.scale.setScalar(palm.scale * (0.85 + (f % 4) * 0.06))
        dummy.updateMatrix()
        fronds.setMatrixAt(frondIndex, dummy.matrix)
        color.setHSL(0.15 + ((f * 7 + i) % 5) * 0.01, 0.2, 0.82 + ((f + i) % 3) * 0.06)
        fronds.setColorAt(frondIndex, color)
        frondIndex++
      }
    })

    trunk.instanceMatrix.needsUpdate = true
    fronds.instanceMatrix.needsUpdate = true
    if (fronds.instanceColor) fronds.instanceColor.needsUpdate = true
    trunk.computeBoundingSphere()
    fronds.computeBoundingSphere()
  }, [frondDepth])

  return (
    <group>
      <instancedMesh ref={trunkRef} args={[undefined, trunkMaterial, city.palms.length]} castShadow receiveShadow>
        <cylinderGeometry args={[0.17, 0.3, TRUNK_HEIGHT, 14, 8]} />
      </instancedMesh>
      <instancedMesh ref={frondRef} args={[frondGeometry, frondMaterial, city.palms.length * FRONDS]} castShadow receiveShadow />
    </group>
  )
}
