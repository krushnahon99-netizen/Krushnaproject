import * as THREE from 'three'
import { loadParts, partBounds } from './car-source.mjs'

const file = process.argv[2]
const parts = await loadParts(file)
const all = new THREE.Box3()
const byMaterial = new Map()
for (const p of parts) {
  const b = partBounds(p)
  all.union(b)
  const entry = byMaterial.get(p.material) ?? { tris: 0, box: new THREE.Box3(), nodes: new Set(), color: p.baseColor, metal: p.metallic, rough: p.roughness, alpha: p.alphaMode, emissive: p.emissive }
  entry.tris += p.idx.length / 3
  entry.box.union(b)
  entry.nodes.add(p.node.split('/').slice(-2).join('/'))
  byMaterial.set(p.material, entry)
}
const f = (v) => [v.x, v.y, v.z].map((n) => n.toFixed(2)).join(',')
console.log(file, 'parts', parts.length, 'min', f(all.min), 'max', f(all.max), 'size', f(all.getSize(new THREE.Vector3())))
for (const [name, e] of [...byMaterial].sort((a, b) => b[1].tris - a[1].tris)) {
  console.log(
    `${name.padEnd(22)} tris ${String(e.tris).padStart(7)}  min ${f(e.box.min)}  max ${f(e.box.max)}  col ${e.color.map((c) => c.toFixed(2)).join(',')} m${e.metal.toFixed(2)} r${e.rough.toFixed(2)} ${e.alpha} em ${e.emissive.map((c) => c.toFixed(1)).join(',')}  nodes ${[...e.nodes].slice(0, 4).join(' | ')}`,
  )
}
