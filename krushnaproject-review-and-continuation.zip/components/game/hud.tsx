'use client'

import { useSyncExternalStore } from 'react'
import { hudStore } from '@/lib/game/state'
import { Minimap } from './minimap'
import { useIsTouchDevice } from './touch-controls'
import { cn } from '@/lib/utils'

const outline = { textShadow: '0 0 2px #000, 0 0 2px #000, 2px 2px 0 #000, -2px -2px 0 #000, 2px -2px 0 #000, -2px 2px 0 #000' }

export function Hud() {
  const hud = useSyncExternalStore(hudStore.subscribe, hudStore.getSnapshot, hudStore.getServerSnapshot)
  const touch = useIsTouchDevice()
  if (!hud.started) return null

  return (
    <div className="pointer-events-none fixed inset-0 z-10 select-none">
      {hud.prompt && (
        <div
          className={cn(
            'absolute max-w-56 rounded-md bg-black/75 px-4 py-3 text-sm text-white shadow-lg',
            touch ? 'bottom-[17rem] right-4' : 'left-4 top-4 md:left-8 md:top-6',
          )}
        >
          {touch ? hud.prompt.replace('Press F to', 'Tap Enter to').replace('Tap Enter to exit', 'Tap Exit to leave') : hud.prompt}
        </div>
      )}

      <div className="absolute inset-x-0 top-20 flex flex-col items-center gap-1 md:top-24" aria-live="polite">
        {hud.notices.map((notice) => (
          <p
            key={notice.id}
            className={cn(
              'font-display text-2xl tracking-wide animate-in fade-in slide-in-from-top-2 md:text-4xl',
              notice.tone === 'cash' ? 'text-[#7ee08a]' : 'text-[#ffcf4a]',
            )}
            style={outline}
          >
            {notice.text}
          </p>
        ))}
      </div>

      <div
        className={cn(
          'absolute',
          touch ? 'left-3 top-3 origin-top-left scale-[0.55]' : 'bottom-40 left-3 md:bottom-6 md:left-8',
        )}
      >
        <Minimap />
      </div>

      {hud.mode === 'car' && (
        <div className={cn('absolute text-right', touch ? 'bottom-44 right-5' : 'bottom-48 right-4 md:bottom-6 md:right-8')}>
          <p className={cn('font-display leading-none text-white', touch ? 'text-5xl' : 'text-5xl md:text-7xl')} style={outline}>
            {hud.speed}
          </p>
          <p className="font-display text-sm tracking-widest text-white/90 md:text-lg" style={outline}>
            KM/H
          </p>
        </div>
      )}
    </div>
  )
}
