execute if block ~ ~ ~ minecraft:pale_oak_sign[waterlogged=true] run setblock ~ ~ ~ minecraft:pale_oak_sign[waterlogged=false] replace
execute if block ~ ~ ~ minecraft:pale_oak_wall_sign[waterlogged=true] run setblock ~ ~ ~ minecraft:pale_oak_wall_sign[waterlogged=false] replace
