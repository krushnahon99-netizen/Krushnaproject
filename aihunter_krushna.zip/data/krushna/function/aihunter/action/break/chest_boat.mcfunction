execute if entity @s[nbt={Type:oak}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:oak_chest_boat",count:1}}

execute if entity @s[nbt={Type:spruce}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:spruce_chest_boat",count:1}}

execute if entity @s[nbt={Type:birch}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:birch_chest_boat",count:1}}

execute if entity @s[nbt={Type:jungle}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:jungle_chest_boat",count:1}}

execute if entity @s[nbt={Type:acacia}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:acacia_chest_boat",count:1}}

execute if entity @s[nbt={Type:dark_oak}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:dark_oak_chest_boat",count:1}}

execute if entity @s[nbt={Type:mangrove}] run summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:mangrove_chest_boat",count:1}}

kill @s
