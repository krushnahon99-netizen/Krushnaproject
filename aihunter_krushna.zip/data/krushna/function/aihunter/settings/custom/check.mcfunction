playsound minecraft:ui.button.click master @s ~ ~ ~ .1

execute if score started aihunter_dummy matches 0 run function krushna:aihunter/settings/custom/edit

execute if score started aihunter_dummy matches 1 run function krushna:aihunter/message/unchange