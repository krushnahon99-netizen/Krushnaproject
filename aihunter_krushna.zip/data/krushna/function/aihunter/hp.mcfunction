execute store result score @s aihunter_hp run data get entity @s Health 10

setblock 100 1 0 minecraft:oak_sign{Text1:'{"text":"Kyleong was here"}',Text3:'{"text":"and so does"}',Text4:'{"text":"AI Hunter"}'} replace

scoreboard players operation #temp aihunter_hp = @s aihunter_hp


#MC1.20+ signs nbt differences

execute if data storage minecraft:aihunter_custom name run data modify block 100 1 0 Text4 set value '[{"text":"["},{"score":{"name":"#temp","objective":"aihunter_hp"},"color":"red"},{"text":"/200] "},{"nbt":"name","storage":"aihunter_custom","interpret":true}]'

execute if data storage minecraft:aihunter_custom name run data modify block 100 1 0 front_text.messages[3] set value '[{"text":"["},{"score":{"name":"#temp","objective":"aihunter_hp"},"color":"red"},{"text":"/200] "},{"nbt":"name","storage":"aihunter_custom","interpret":true}]'

execute unless data storage minecraft:aihunter_custom name run data modify block 100 1 0 Text4 set value '[{"text":"["},{"score":{"name":"#temp","objective":"aihunter_hp"},"color":"red"},{"text":"/200] "},{"text":"Hunter"}]'

execute unless data storage minecraft:aihunter_custom name run data modify block 100 1 0 front_text.messages[3] set value '[{"text":"["},{"score":{"name":"#temp","objective":"aihunter_hp"},"color":"red"},{"text":"/200] "},{"text":"Hunter"}]'


data modify entity @e[limit=1,sort=nearest,type=minecraft:text_display,tag=aihunter_name] text set from block 100 1 0 Text4

data modify entity @e[limit=1,sort=nearest,type=minecraft:text_display,tag=aihunter_name] text set from block 100 1 0 front_text.messages[3]

