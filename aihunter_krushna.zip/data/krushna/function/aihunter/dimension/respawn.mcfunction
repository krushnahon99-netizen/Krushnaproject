execute unless predicate krushna:aihunter/dead if score dimension aihunter_dummy matches 0 unless predicate krushna:aihunter/dimension/overworld run function krushna:aihunter/dimension/cross/identify

execute unless predicate krushna:aihunter/dead if score dimension aihunter_dummy matches 1 unless predicate krushna:aihunter/dimension/nether run function krushna:aihunter/dimension/cross/identify

execute unless predicate krushna:aihunter/dead if predicate krushna:aihunter/dimension/overworld run scoreboard players set dimension aihunter_dummy 0

execute unless predicate krushna:aihunter/dead if predicate krushna:aihunter/dimension/nether run scoreboard players set dimension aihunter_dummy 1

execute if predicate krushna:aihunter/dead run scoreboard players set @s aihunter_death 999999999