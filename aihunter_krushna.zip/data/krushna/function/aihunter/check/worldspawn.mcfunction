setworldspawn ~ ~ ~

summon minecraft:area_effect_cloud ~ ~ ~ {Radius:0f,Duration:9000000,Radius:0f,Tags:["aihunter_worldspawn"]}

execute store result score worldspawnx aihunter_dummy run data get entity @e[type=area_effect_cloud,tag=aihunter_worldspawn,limit=1,sort=nearest] Pos[0] 10

execute store result score worldspawnz aihunter_dummy run data get entity @e[type=area_effect_cloud,tag=aihunter_worldspawn,limit=1,sort=nearest] Pos[2] 10