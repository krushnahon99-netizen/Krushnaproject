execute if block ~ ~ ~ minecraft:pale_oak_trapdoor[waterlogged=true] run setblock ~ ~ ~ minecraft:pale_oak_trapdoor[waterlogged=false] replace
