/**
 * Rebuilds <name>-lod1.glb (groups "lod1" + "lod2") from the full-detail <name>-lod0.glb.
 *
 * Each primitive is welded by position, simplified, then given crease-angle normals: hard edges
 * stay hard and curved panels stay smooth. The previous bake produced fully smoothed normals
 * across creases, which showed up as patchy camouflage-like shading on reflective paint.
 *
 *   node tools/rebuild-car-lods.mjs
 */
import { NodeIO } from '@gltf-transform/core'
import { ALL_EXTENSIONS } from '@gltf-transform/extensions'
import { dedup, dequantize, meshopt, mergeDocuments, prune } from '@gltf-transform/functions'
import { MeshoptDecoder, MeshoptEncoder, MeshoptSimplifier } from 'meshoptimizer'
import * as THREE from 'three'
import { mergeVertices, toCreasedNormals } from 'three/examples/jsm/utils/BufferGeometryUtils.js'

const DIR = new URL('../public/models/cars/', import.meta.url).pathname

const CARS = {
  sports: { lod1: 0.12, lod2: 0.03 },
  suv: { lod1: 0.2, lod2: 0.05 },
  sedan: { lod1: 0.6, lod2: 0.25 },
}

/** Allowed deviation in metres; roughly a pixel or two at the distance each level appears. */
const ERROR = { lod1: 0.006, lod2: 0.025 }
const CREASE_ANGLE = THREE.MathUtils.degToRad(38)
/** Interior parts are only dropped at the far level; open-top cars show their cabin at mid range. */
const DROP_MATERIALS = new Set(['interior', 'accent'])

await Promise.all([MeshoptDecoder.ready, MeshoptEncoder.ready, MeshoptSimplifier.ready])
const io = new NodeIO()
  .registerExtensions(ALL_EXTENSIONS)
  .registerDependencies({ 'meshopt.decoder': MeshoptDecoder, 'meshopt.encoder': MeshoptEncoder })

function rebuildPrimitive(doc, prim, ratio, error) {
  const source = prim.getAttribute('POSITION').getArray()
  const indices = prim.getIndices()?.getArray()
  let geometry = new THREE.BufferGeometry()
  geometry.setAttribute('position', new THREE.BufferAttribute(Float32Array.from(source), 3))
  if (indices) geometry.setIndex(Array.from(indices))
  geometry = mergeVertices(geometry, 1e-4)

  const pos = geometry.getAttribute('position').array
  const idx = Uint32Array.from(geometry.index.array)
  const target = Math.max(12, Math.floor((idx.length * ratio) / 3) * 3)
  const [simplified] = MeshoptSimplifier.simplify(idx, pos, 3, target, error, ['ErrorAbsolute'])
  if (simplified.length < 3) return false
  geometry.setIndex(Array.from(simplified))

  const creased = mergeVertices(toCreasedNormals(geometry, CREASE_ANGLE), 1e-4)
  const buffer = doc.getRoot().listBuffers()[0]
  for (const semantic of prim.listSemantics()) prim.setAttribute(semantic, null)
  prim.setAttribute(
    'POSITION',
    doc.createAccessor().setType('VEC3').setArray(new Float32Array(creased.getAttribute('position').array)).setBuffer(buffer),
  )
  prim.setAttribute(
    'NORMAL',
    doc.createAccessor().setType('VEC3').setArray(new Float32Array(creased.getAttribute('normal').array)).setBuffer(buffer),
  )
  prim.setIndices(doc.createAccessor().setType('SCALAR').setArray(Uint32Array.from(creased.index.array)).setBuffer(buffer))
  return true
}

async function buildLevel(name, level, ratio) {
  const doc = await io.read(`${DIR}${name}-lod0.glb`)
  await doc.transform(dequantize())
  let tris = 0
  for (const mesh of doc.getRoot().listMeshes()) {
    for (const prim of mesh.listPrimitives()) {
      const dropped = level === 'lod2' && DROP_MATERIALS.has(prim.getMaterial()?.getName())
      if (dropped || !rebuildPrimitive(doc, prim, ratio, ERROR[level])) {
        prim.dispose()
        continue
      }
      tris += prim.getIndices().getCount() / 3
    }
  }
  for (const node of doc.getRoot().listNodes()) node.setName(node.getName().replace(/^lod0/, level))
  await doc.transform(prune())
  console.log(`${name} ${level}: ${tris} tris`)
  return doc
}

for (const [name, cfg] of Object.entries(CARS)) {
  const lod1 = await buildLevel(name, 'lod1', cfg.lod1)
  const lod2 = await buildLevel(name, 'lod2', cfg.lod2)
  const [mainScene] = lod1.getRoot().listScenes()
  mergeDocuments(lod1, lod2)
  for (const scene of lod1.getRoot().listScenes()) {
    if (scene === mainScene) continue
    for (const node of scene.listChildren()) mainScene.addChild(node)
    scene.dispose()
  }
  const [buffer, ...extraBuffers] = lod1.getRoot().listBuffers()
  for (const accessor of lod1.getRoot().listAccessors()) accessor.setBuffer(buffer)
  for (const extra of extraBuffers) extra.dispose()
  await lod1.transform(dedup(), prune(), meshopt({ encoder: MeshoptEncoder, level: 'medium' }))
  await io.write(`${DIR}${name}-lod1.glb`, lod1)
}
