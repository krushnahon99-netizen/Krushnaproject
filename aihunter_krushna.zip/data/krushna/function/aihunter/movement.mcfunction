##as at @e[type=minecraft:vindicator,tag=aihunter] (non-idle, non-red, target available, every 6t)
#moves unless preparing upgrade (intent = 2)

execute unless score @s aihunter_intent matches 2 unless score version aihunter_dummy matches 120.. if predicate krushna:aihunter/onground_116 unless predicate krushna:aihunter/towering unless predicate krushna:aihunter/water unless block ~ ~ ~ minecraft:lava run function krushna:aihunter/movement/land

execute unless score @s aihunter_intent matches 2 if score version aihunter_dummy matches 120.. if predicate krushna:aihunter/onground_120 unless predicate krushna:aihunter/towering unless predicate krushna:aihunter/water unless block ~ ~ ~ minecraft:lava run function krushna:aihunter/movement/land


execute unless score @s aihunter_intent matches 2 if predicate krushna:aihunter/water unless predicate krushna:aihunter/towering run function krushna:aihunter/movement/water

execute unless score @s aihunter_intent matches 2 if block ~ ~ ~ minecraft:lava unless predicate krushna:aihunter/towering run function krushna:aihunter/movement/lava


#not movement related

execute unless score @s aihunter_busy matches 1 as @e[distance=..2,type=#krushna:aihunter/vehicle,limit=1,sort=nearest] at @s run function krushna:aihunter/action/break/vehicle

execute unless score @s aihunter_busy matches 1 as @e[distance=..2,type=#krushna:aihunter/chest_boat,limit=1,sort=nearest] at @s run function krushna:aihunter/action/break/chest_boat

execute if score quality aihunter_dummy matches 1 unless score @s aihunter_intent matches 2 as @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] run function krushna:aihunter/animation/standard