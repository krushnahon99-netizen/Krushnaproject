#cannot be put in one because version complications 

execute unless score version aihunter_dummy matches 117.. run function krushna:aihunter/find/action/underground/situation/1/116

execute if score version aihunter_dummy matches 117..118 run function krushna:aihunter/find/action/underground/situation/1/117

execute if score version aihunter_dummy matches 119 run function krushna:aihunter/find/action/underground/situation/1/119

execute if score version aihunter_dummy matches 120 run function krushna:aihunter/find/action/underground/situation/1/120
execute if score version aihunter_dummy matches 121.. run function krushna:aihunter/find/action/underground/situation/1/121
