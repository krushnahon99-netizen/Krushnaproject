execute if score @s aihunter_upgrade matches ..0 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] {HandItems:[{},{}]}

execute if score @s aihunter_upgrade matches 1 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] {HandItems:[{},{}]}

execute if score @s aihunter_upgrade matches 2 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] {HandItems:[{},{}]}

execute if score @s aihunter_upgrade matches 3 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] {HandItems:[{},{}]}

execute if score @s aihunter_upgrade matches 4 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] {HandItems:[{},{}]}

execute if score @s aihunter_upgrade matches 5 run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] {HandItems:[{},{}]}

execute if score @s aihunter_upgrade matches 6.. run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter,tag=aihunter_tped] {HandItems:[{},{}]}


execute if score @s aihunter_upgrade matches ..0 run data merge entity @s {HandItems:[{},{}]}

execute if score @s aihunter_upgrade matches 1 run data merge entity @s {HandItems:[{},{}]}

execute if score @s aihunter_upgrade matches 2 run data merge entity @s {HandItems:[{},{}]}

execute if score @s aihunter_upgrade matches 3 run data merge entity @s {HandItems:[{},{}]}

execute if score @s aihunter_upgrade matches 4 run data merge entity @s {HandItems:[{},{}]}

execute if score @s aihunter_upgrade matches 5 run data merge entity @s {HandItems:[{},{}]}

execute if score @s aihunter_upgrade matches 6.. run data merge entity @s {HandItems:[{},{}]}


scoreboard players set @s aihunter_weapon 1