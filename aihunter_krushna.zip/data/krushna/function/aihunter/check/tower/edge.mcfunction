
execute positioned ~ ~ ~-0.3 unless block ~ ~-0.5 ~ #krushna:aihunter/passable unless block ~ ~-1.5 ~ #krushna:aihunter/passable unless block ~ ~-2.5 ~ #krushna:aihunter/passable run function krushna:aihunter/check/tower/side/1

execute positioned ~-0.3 ~ ~ unless block ~ ~-0.5 ~ #krushna:aihunter/passable unless block ~ ~-1.5 ~ #krushna:aihunter/passable unless block ~ ~-2.5 ~ #krushna:aihunter/passable run function krushna:aihunter/check/tower/side/2

execute positioned ~ ~ ~0.3 unless block ~ ~-0.5 ~ #krushna:aihunter/passable unless block ~ ~-1.5 ~ #krushna:aihunter/passable unless block ~ ~-2.5 ~ #krushna:aihunter/passable run function krushna:aihunter/check/tower/side/3

execute positioned ~0.3 ~ ~ unless block ~ ~-0.5 ~ #krushna:aihunter/passable unless block ~ ~-1.5 ~ #krushna:aihunter/passable unless block ~ ~-2.5 ~ #krushna:aihunter/passable run function krushna:aihunter/check/tower/side/4


execute unless score @s aihunter_tower matches 7.. run function krushna:aihunter/check/tower/corner