import type { CarVariant } from './state'

export type CarModelName = 'sports' | 'suv' | 'sedan'

export type CarSpec = {
  model: CarModelName
  /** Body width without mirrors, metres. */
  width: number
  length: number
  /** Highest point of the cabin roof above the ground. */
  roof: number
  /** Driver hip position in car space (+x driver side, +z forward) and seat cushion height. */
  seat: { x: number; z: number; cushion: number }
}

export const CAR_SPECS: Record<CarVariant, CarSpec> = {
  sports: { model: 'sports', width: 1.94, length: 4.53, roof: 1.17, seat: { x: 0.36, z: -0.18, cushion: 0.3 } },
  sedan: { model: 'sedan', width: 1.78, length: 4.29, roof: 1.31, seat: { x: 0.38, z: -0.3, cushion: 0.38 } },
  taxi: { model: 'sedan', width: 1.78, length: 4.29, roof: 1.31, seat: { x: 0.38, z: -0.3, cushion: 0.38 } },
  suv: { model: 'suv', width: 2.02, length: 5.11, roof: 1.62, seat: { x: 0.42, z: 0.05, cushion: 0.68 } },
}

export const CAR_CREDITS = [
  'Ferrari 458 Italia by vicent091036 (CC-BY 4.0)',
  'Lamborghini Urus by Steven Grey (CC-BY 4.0)',
  'Porsche 911 930 Turbo by Lionsharp Studios (CC-BY 4.0)',
]

const SEATED_HIP_HEIGHT = 0.85
const SEATED_HEAD_TOP = 1.7

export type SeatLayout = {
  seatX: number
  seatZ: number
  /** Height of the character root above the ground while seated (negative sinks the legs into the body). */
  rootY: number
  doorX: number
  doorZ: number
}

const layouts = new Map<CarVariant, SeatLayout>()

/** Car-local positions (+x is the driver/left side, +z is forward) for the driver seat and door. */
export function seatLayout(variant: CarVariant): SeatLayout {
  const cached = layouts.get(variant)
  if (cached) return cached
  const spec = CAR_SPECS[variant]
  const layout: SeatLayout = {
    seatX: spec.seat.x,
    seatZ: spec.seat.z,
    rootY: Math.min(spec.seat.cushion - SEATED_HIP_HEIGHT, spec.roof - 0.06 - SEATED_HEAD_TOP),
    doorX: spec.width / 2 + 0.5,
    doorZ: spec.seat.z - 0.05,
  }
  layouts.set(variant, layout)
  return layout
}
