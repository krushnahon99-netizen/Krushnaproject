execute unless block ~ ~ ~ #krushna:aihunter/space unless block ~ ~ ~ #krushna:aihunter/unbreakable run function krushna:aihunter/action/break/block1
