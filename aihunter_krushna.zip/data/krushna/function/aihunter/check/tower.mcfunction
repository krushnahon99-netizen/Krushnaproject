#as, at player

scoreboard players set @s aihunter_tower 0

execute unless predicate krushna:aihunter/onground unless block ~ ~-0.5 ~ #krushna:aihunter/passable unless block ~ ~-1.5 ~ #krushna:aihunter/passable unless block ~ ~-2.5 ~ #krushna:aihunter/passable run function krushna:aihunter/check/tower/centre

execute unless predicate krushna:aihunter/onground if block ~ ~-0.5 ~ #krushna:aihunter/passable if block ~ ~-1.5 ~ #krushna:aihunter/passable if block ~ ~-2.5 ~ #krushna:aihunter/passable rotated ~ 0 run function krushna:aihunter/check/tower/edge


execute if entity @s[x_rotation=51..90,scores={aihunter_tower=7..}] run scoreboard players set @s aihunter_tower -33
