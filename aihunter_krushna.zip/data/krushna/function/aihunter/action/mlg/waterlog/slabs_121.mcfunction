execute if block ~ ~ ~ minecraft:pale_oak_slab[waterlogged=false] run setblock ~ ~ ~ minecraft:pale_oak_slab[waterlogged=true] replace
execute if block ~ ~ ~ minecraft:tuff_slab[waterlogged=false] run setblock ~ ~ ~ minecraft:tuff_slab[waterlogged=true] replace
execute if block ~ ~ ~ minecraft:polished_tuff_slab[waterlogged=false] run setblock ~ ~ ~ minecraft:polished_tuff_slab[waterlogged=true] replace
execute if block ~ ~ ~ minecraft:tuff_brick_slab[waterlogged=false] run setblock ~ ~ ~ minecraft:tuff_brick_slab[waterlogged=true] replace
