'use client'

import { Suspense, useEffect } from 'react'
import { Canvas } from '@react-three/fiber'
import { useAnimations, useGLTF } from '@react-three/drei'
import { useSearchParams } from 'next/navigation'

function Model({ clip }: { clip: string }) {
  const { scene, animations } = useGLTF('/models/character.glb')
  const { actions } = useAnimations(animations, scene)
  useEffect(() => {
    actions[clip]?.reset().play()
  }, [actions, clip])
  return <primitive object={scene} />
}

function Inner() {
  const params = useSearchParams()
  const clip = params.get('clip') ?? 'Idle'
  const angle = Number(params.get('angle') ?? 0)
  const zoom = params.get('zoom') === 'face'
  const r = zoom ? 0.7 : 3.4
  const y = zoom ? 1.55 : 1
  return (
    <Canvas camera={{ position: [Math.sin(angle) * r, y, Math.cos(angle) * r], fov: 35 }} onCreated={({ camera }) => camera.lookAt(0, y, 0)}>
      <color attach="background" args={['#8fa3b8']} />
      <hemisphereLight args={['#ffffff', '#555555', 1.2]} />
      <directionalLight position={[2, 4, 3]} intensity={2.2} />
      <Suspense fallback={null}>
        <Model clip={clip} />
      </Suspense>
    </Canvas>
  )
}

export default function Page() {
  return (
    <main className="h-dvh w-full">
      <Suspense fallback={null}>
        <Inner />
      </Suspense>
    </main>
  )
}
