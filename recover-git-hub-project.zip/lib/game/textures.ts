import * as THREE from 'three'
import { createRandom } from './random'
import { QUALITY } from './quality'

export const TEXTURE_URLS = {
  asphalt: '/textures/asphalt.jpg',
  sidewalk: '/textures/sidewalk.jpg',
  sand: '/textures/sand.jpg',
  grass: '/textures/grass.jpg',
  roof: '/textures/roof.jpg',
  bark: '/textures/palm-bark.jpg',
  facadeGlass: '/textures/facade-glass.jpg',
  facadeStucco: '/textures/facade-stucco.jpg',
  facadeConcrete: '/textures/facade-concrete.jpg',
} as const

export function setupTiling(texture: THREE.Texture, repeatX = 1, repeatY = repeatX, srgb = true) {
  texture.wrapS = THREE.RepeatWrapping
  texture.wrapT = THREE.RepeatWrapping
  texture.repeat.set(repeatX, repeatY)
  texture.anisotropy = QUALITY.anisotropy
  texture.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace
  texture.needsUpdate = true
  return texture
}

function linearTexture(canvas: HTMLCanvasElement, source?: THREE.Texture) {
  const texture = new THREE.CanvasTexture(canvas)
  texture.wrapS = THREE.RepeatWrapping
  texture.wrapT = THREE.RepeatWrapping
  texture.anisotropy = QUALITY.anisotropy
  texture.colorSpace = THREE.NoColorSpace
  if (source) texture.repeat.copy(source.repeat)
  return texture
}

function readLuminance(source: THREE.Texture, size: number) {
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = size
  const ctx = canvas.getContext('2d', { willReadFrequently: true })!
  ctx.drawImage(source.image as CanvasImageSource, 0, 0, size, size)
  const { data } = ctx.getImageData(0, 0, size, size)
  const lum = new Float32Array(size * size)
  for (let i = 0; i < lum.length; i++) {
    lum[i] = (data[i * 4] * 0.299 + data[i * 4 + 1] * 0.587 + data[i * 4 + 2] * 0.114) / 255
  }
  return { canvas, ctx, lum }
}

export function createNormalMap(source: THREE.Texture, strength = 2, size = 512) {
  const { canvas, ctx, lum } = readLuminance(source, size)
  const out = ctx.createImageData(size, size)
  const at = (x: number, y: number) => lum[((y + size) % size) * size + ((x + size) % size)]
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const dx = (at(x + 1, y) - at(x - 1, y)) * strength
      const dy = (at(x, y - 1) - at(x, y + 1)) * strength
      const length = Math.hypot(dx, dy, 1)
      const i = (y * size + x) * 4
      out.data[i] = (-dx / length * 0.5 + 0.5) * 255
      out.data[i + 1] = (-dy / length * 0.5 + 0.5) * 255
      out.data[i + 2] = (1 / length * 0.5 + 0.5) * 255
      out.data[i + 3] = 255
    }
  }
  ctx.putImageData(out, 0, 0)
  return linearTexture(canvas, source)
}

export function createGlossMap(source: THREE.Texture, threshold: number, glossy: number, matte: number, size = 512) {
  const { canvas, ctx, lum } = readLuminance(source, size)
  const out = ctx.createImageData(size, size)
  for (let i = 0; i < lum.length; i++) {
    const t = Math.min(1, Math.max(0, (lum[i] - threshold + 0.08) / 0.16))
    const roughness = (glossy + (matte - glossy) * t) * 255
    out.data[i * 4] = roughness
    out.data[i * 4 + 1] = roughness
    out.data[i * 4 + 2] = roughness
    out.data[i * 4 + 3] = 255
  }
  ctx.putImageData(out, 0, 0)
  return linearTexture(canvas, source)
}

export function createWaterNormalMap(size = 256) {
  const random = createRandom(42)
  const waves = Array.from({ length: 14 }, () => {
    const kx = Math.round((random() - 0.5) * 16)
    const ky = Math.round((random() - 0.5) * 16) || 1
    return { kx, ky, phase: random() * Math.PI * 2, amp: 1 / Math.hypot(kx, ky) }
  })
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = size
  const ctx = canvas.getContext('2d')!
  const out = ctx.createImageData(size, size)
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let dx = 0
      let dy = 0
      for (const w of waves) {
        const c = Math.cos(Math.PI * 2 * (w.kx * x / size + w.ky * y / size) + w.phase) * w.amp
        dx += c * w.kx
        dy += c * w.ky
      }
      dx *= 0.09
      dy *= 0.09
      const length = Math.hypot(dx, dy, 1)
      const i = (y * size + x) * 4
      out.data[i] = (-dx / length * 0.5 + 0.5) * 255
      out.data[i + 1] = (dy / length * 0.5 + 0.5) * 255
      out.data[i + 2] = (1 / length * 0.5 + 0.5) * 255
      out.data[i + 3] = 255
    }
  }
  ctx.putImageData(out, 0, 0)
  return linearTexture(canvas)
}

export function createFrondTexture() {
  const width = 256
  const height = 1024
  const canvas = document.createElement('canvas')
  canvas.width = width
  canvas.height = height
  const ctx = canvas.getContext('2d')!
  const random = createRandom(11)
  const mid = width / 2
  ctx.lineCap = 'round'

  for (let i = 0; i < 70; i++) {
    const t = 0.04 + (i / 70) * 0.94
    const y = height - t * height
    const length = Math.sin(Math.PI * Math.min(1, t * 1.05 + 0.04)) * mid * 0.96
    for (const side of [-1, 1]) {
      const droop = 26 + t * 60 + random() * 14
      const shade = 34 + Math.floor(random() * 26)
      const gradient = ctx.createLinearGradient(mid, y, mid + side * length, y + droop)
      gradient.addColorStop(0, `hsl(${84 + random() * 10}, 48%, ${shade - 6}%)`)
      gradient.addColorStop(1, `hsl(${70 + random() * 14}, 42%, ${shade + 8}%)`)
      ctx.strokeStyle = gradient
      ctx.lineWidth = 7 - t * 3
      ctx.beginPath()
      ctx.moveTo(mid, y)
      ctx.quadraticCurveTo(mid + side * length * 0.5, y + droop * 0.25, mid + side * length, y + droop)
      ctx.stroke()
    }
  }
  ctx.strokeStyle = '#6b6a3a'
  ctx.lineWidth = 7
  ctx.beginPath()
  ctx.moveTo(mid, height)
  ctx.lineTo(mid, 12)
  ctx.stroke()

  const texture = new THREE.CanvasTexture(canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  texture.anisotropy = Math.min(8, QUALITY.anisotropy)
  return texture
}

let blobShadow: THREE.Texture | null = null
export function getBlobShadowTexture() {
  if (blobShadow) return blobShadow
  const size = 128
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = size
  const ctx = canvas.getContext('2d')!
  const gradient = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2)
  gradient.addColorStop(0, 'rgba(0,0,0,0.85)')
  gradient.addColorStop(0.55, 'rgba(0,0,0,0.55)')
  gradient.addColorStop(1, 'rgba(0,0,0,0)')
  ctx.fillStyle = gradient
  ctx.fillRect(0, 0, size, size)
  blobShadow = new THREE.CanvasTexture(canvas)
  return blobShadow
}
