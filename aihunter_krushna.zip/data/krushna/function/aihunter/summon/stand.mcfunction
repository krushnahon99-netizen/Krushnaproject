execute if score glow aihunter_dummy matches 1 run summon minecraft:armor_stand ~ ~ ~ {Marker:1b,ShowArms:1b,NoBasePlate:1b,PersistenceRequired:1b,attributes:[{id:"minecraft:knockback_resistance",base:1}],Tags:["aihunter"],PortalCooldown:9000000,DisabledSlots:4144959,Glowing:1b}

execute unless score glow aihunter_dummy matches 1 run summon minecraft:armor_stand ~ ~ ~ {Marker:1b,ShowArms:1b,NoBasePlate:1b,PersistenceRequired:1b,attributes:[{id:"minecraft:knockback_resistance",base:1}],Tags:["aihunter"],PortalCooldown:9000000,DisabledSlots:4144959}

# Equip armor immediately on the freshly spawned stand (nearest unequipped one)
execute as @e[type=minecraft:armor_stand,tag=aihunter,limit=1,sort=nearest] run function krushna:aihunter/summon/set_buff

# Spawn nametag on the fresh armor_stand (same as initial spawn in summon/hunter)
execute as @e[type=minecraft:armor_stand,tag=aihunter,limit=1,sort=nearest] at @s unless entity @e[type=minecraft:text_display,tag=aihunter_name,distance=..4] run function krushna:aihunter/summon/nametag
