scoreboard players set @s[type=minecraft:vindicator] aihunter_hp 200

execute if score showhp aihunter_dummy matches 1 in minecraft:the_end as @s[type=minecraft:vindicator] run function krushna:aihunter/hp

data modify entity @s[type=minecraft:armor_stand] ArmorItems set from storage minecraft:aihunter_custom armor

data modify entity @s[type=minecraft:vindicator] CustomName set from storage minecraft:aihunter_custom name

execute as @e[type=minecraft:text_display,tag=aihunter_name] run data modify entity @s text set from storage minecraft:aihunter_custom name

execute if entity @s[type=minecraft:armor_stand] unless data storage minecraft:aihunter_custom armor run function krushna:aihunter/summon/return/set_buff


function krushna:aihunter/adjust/damage

execute if score difficulty aihunter_dummy matches 4.. run execute if entity @s[type=minecraft:vindicator] run effect give @s minecraft:resistance 999999 6 true