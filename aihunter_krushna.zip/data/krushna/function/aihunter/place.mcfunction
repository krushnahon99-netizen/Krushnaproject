advancement revoke @s only krushna:aihunter/place

execute if score started aihunter_dummy matches 1 unless score pause aihunter_dummy matches 1 unless score @s aihunter_tower matches ..-1 run function krushna:aihunter/check/tower