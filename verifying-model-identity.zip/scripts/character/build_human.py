"""
Builds the player character from scratch inside headless Blender using MPFB2 and the CC0 MakeHuman asset pack,
retargets Xbot's idle / walk / run onto it, authors the car Sit / Reach poses and exports a game-ready GLB.

    blender -b -P scripts/character/build_human.py -- <xbot.glb> <out.glb>

The character only wears boxer briefs for now; clothing is added in a later pass.
"""

import bpy
import bmesh
import json
import sys
from mathutils import Quaternion, Vector

from bl_ext.user_default.mpfb.services.humanservice import HumanService

ARGS = sys.argv[sys.argv.index("--") + 1 :]
XBOT_PATH = ARGS[0]
OUT_PATH = ARGS[1]
FPS = 30

HUMAN = {
    "name": "Player",
    "phenotype": {
        "gender": 1.0,
        "age": 0.5,
        "muscle": 0.7,
        "weight": 0.55,
        "height": 0.42,
        "proportions": 0.9,
        "cupsize": 0.5,
        "firmness": 0.5,
        "race": {"african": 0.1, "asian": 0.05, "caucasian": 0.85},
    },
    "rig": "mixamo",
    "eyes": "high-poly/high-poly.mhclo",
    "eyebrows": "eyebrow006/eyebrow006.mhclo",
    "eyelashes": "eyelashes02/eyelashes02.mhclo",
    "teeth": "",
    "tongue": "",
    "hair": "short02/short02.mhclo",
    "proxy": "",
    "targets": [
        {"target": "chin-width-incr", "value": 0.25},
        {"target": "chin-prominent-incr", "value": 0.2},
        {"target": "l-cheek-bones-incr", "value": 0.3},
        {"target": "r-cheek-bones-incr", "value": 0.3},
        {"target": "nose-scale-horiz-decr", "value": 0.15},
        {"target": "nose-hump-decr", "value": 0.2},
        {"target": "eyebrows-trans-down", "value": 0.25},
        {"target": "head-square", "value": 0.25},
        {"target": "neck-scale-horiz-incr", "value": 0.2},
        {"target": "measure-shoulder-dist-incr", "value": 0.25},
        {"target": "measure-waist-circ-decr", "value": 0.2},
        {"target": "stomach-tone-incr", "value": 0.4},
        {"target": "torso-muscle-pectoral-incr", "value": 0.25},
        {"target": "torso-muscle-dorsi-incr", "value": 0.3},
    ],
    "clothes": [],
    "skin_mhmat": "young_caucasian_male/young_caucasian_male.mhmat",
    "skin_material_type": "MAKESKIN",
    "eyes_material_type": "MAKESKIN",
    "skin_material_settings": {},
    "eyes_material_settings": {},
    "expressions": [],
    "makeup": [],
}


def log(*a):
    print("[build]", *a, flush=True)


def rotq(matrix):
    return matrix.to_3x3().normalized().to_quaternion()


def activate(obj):
    if bpy.context.object and bpy.context.object.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    for o in bpy.context.view_layer.objects:
        o.select_set(False)
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj


# ---------------------------------------------------------------- 1. Generate the human
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
scene.render.fps = FPS

settings = HumanService.get_default_deserialization_settings()
settings["subdiv_levels"] = 0
settings["load_clothes"] = False
body = HumanService.deserialize_from_dict(HUMAN, settings)
arm = next(o for o in bpy.data.objects if o.type == "ARMATURE")
arm.name = "Player"
body.name = "Body"

# Bake the morph stack into the mesh and strip the helper geometry.
activate(body)
if body.data.shape_keys:
    bpy.ops.object.shape_key_remove(all=True, apply_mix=True)
for mod in list(body.modifiers):
    if mod.type == "MASK":
        body.modifiers.remove(mod)
body_group = body.vertex_groups["body"].index
bm = bmesh.new()
bm.from_mesh(body.data)
deform = bm.verts.layers.deform.active
bmesh.ops.delete(bm, geom=[v for v in bm.verts if body_group not in v[deform]], context="VERTS")
bm.to_mesh(body.data)
bm.free()
for g in list(body.vertex_groups):
    if not g.name.startswith("mixamorig:"):
        body.vertex_groups.remove(g)

# One level of Catmull-Clark gives smooth hands, knuckles and silhouette; weights and UVs interpolate.
sub = body.modifiers.new("Subdivision", "SUBSURF")
sub.levels = 1
sub.render_levels = 1
sub.uv_smooth = "PRESERVE_BOUNDARIES"
bpy.ops.object.modifier_move_to_index(modifier="Subdivision", index=0)
bpy.ops.object.modifier_apply(modifier="Subdivision")
bpy.ops.object.shade_smooth()
log("body verts", len(body.data.vertices))

for o in list(bpy.data.objects):
    if o.type != "MESH" or o is body:
        continue
    if "teeth" in o.name or "tongue" in o.name:
        bpy.data.objects.remove(o)
        continue
    if "eyebrow" in o.name:
        o.name = "Eyebrows"
    elif "eyelash" in o.name:
        o.name = "Eyelashes"
    elif "high-poly" in o.name:
        o.name = "Eyes"
    elif "short" in o.name:
        o.name = "Hair"
    activate(o)
    if o.data.shape_keys:
        bpy.ops.object.shape_key_remove(all=True, apply_mix=True)
    bpy.ops.object.shade_smooth()

# ---------------------------------------------------------------- 2. Skeleton reference data
REST = {}
for b in arm.data.bones:
    REST[b.name] = {
        "q": rotq(arm.matrix_world @ b.matrix_local),
        "head": arm.matrix_world @ b.head_local,
        "parent": b.parent.name if b.parent else None,
    }
BONES = [b.name for b in arm.data.bones]
ORDER = sorted(BONES, key=lambda n: len(arm.data.bones[n].parent_recursive))


def S(n):
    return "mixamorig:" + n


hips_z = REST[S("Hips")]["head"].z
log("hips height", round(hips_z, 3))

# ---------------------------------------------------------------- 3. Boxer briefs fitted to the body
def dominant_bone(vert):
    best, weight = None, -1.0
    for g in vert.groups:
        if g.weight > weight:
            best, weight = body.vertex_groups[g.group].name, g.weight
    return best


TRUNK = {S("Hips"), S("Spine"), S("LeftUpLeg"), S("RightUpLeg")}
WAIST_FRONT = hips_z - 0.005
WAIST_BACK = hips_z + 0.03
LEG_CUT = hips_z - 0.215


def waist_top(co):
    back = max(0.0, min(1.0, (co.y + 0.02) / 0.1))
    return WAIST_FRONT + (WAIST_BACK - WAIST_FRONT) * back


def thigh_cut(co):
    return LEG_CUT + max(0.0, abs(co.x) - 0.05) * 0.18


def in_briefs(v):
    if dominant_bone(v) not in TRUNK:
        return False
    return thigh_cut(v.co) < v.co.z <= waist_top(v.co)


inside = {v.index for v in body.data.vertices if in_briefs(v)}
log("briefs region verts", len(inside))

briefs_mesh = body.data.copy()
briefs_mesh.name = "Briefs"
briefs = bpy.data.objects.new("Briefs", briefs_mesh)
scene.collection.objects.link(briefs)
briefs.parent = arm
for vg in body.vertex_groups:
    briefs.vertex_groups.new(name=vg.name)
briefs.modifiers.new("Armature", "ARMATURE").object = arm

bm = bmesh.new()
bm.from_mesh(briefs_mesh)
keep_faces = {f for f in bm.faces if all(v.index in inside for v in f.verts)}
bmesh.ops.delete(bm, geom=[f for f in bm.faces if f not in keep_faces], context="FACES")
bmesh.ops.delete(bm, geom=[v for v in bm.verts if not v.link_faces], context="VERTS")
interior = [v for v in bm.verts if not v.is_boundary]
for _ in range(6):
    bmesh.ops.smooth_vert(bm, verts=interior, factor=0.5, use_axis_x=True, use_axis_y=True, use_axis_z=True)
bm.normal_update()
for v in bm.verts:
    v.co += v.normal * (0.0065 if not v.is_boundary else 0.0045)
for f in bm.faces:
    c = f.calc_center_median()
    f.material_index = 1 if c.z > waist_top(c) - 0.032 or c.z < thigh_cut(c) + 0.012 else 0
bm.to_mesh(briefs_mesh)
bm.free()
briefs_mesh.materials.clear()

# Hide skin the fabric fully covers so nothing pokes through while animating.
bm = bmesh.new()
bm.from_mesh(body.data)
covered = []
for f in bm.faces:
    if all(v.index in inside and all(n.index in inside for e in v.link_edges for n in e.verts) for v in f.verts):
        covered.append(f)
bmesh.ops.delete(bm, geom=covered, context="FACES_ONLY")
bmesh.ops.delete(bm, geom=[v for v in bm.verts if not v.link_faces], context="VERTS")
bm.to_mesh(body.data)
bm.free()
log("hidden skin faces", len(covered))

# ---------------------------------------------------------------- 4. Clean glTF-friendly materials
def image_from(obj):
    for mat in obj.data.materials:
        if mat and mat.use_nodes:
            for n in mat.node_tree.nodes:
                if n.type == "TEX_IMAGE" and n.image:
                    return n.image
    return None


def make_material(name, image=None, color=(1, 1, 1, 1), roughness=0.6, alpha=None, specular=0.5, sheen=0.0):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    bsdf = nt.nodes["Principled BSDF"]
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["Specular IOR Level"].default_value = specular
    bsdf.inputs["Base Color"].default_value = color
    if sheen:
        bsdf.inputs["Sheen Weight"].default_value = sheen
    if image:
        tex = nt.nodes.new("ShaderNodeTexImage")
        tex.image = image
        if tuple(color) != (1, 1, 1, 1):
            mix = nt.nodes.new("ShaderNodeMix")
            mix.data_type = "RGBA"
            mix.blend_type = "MULTIPLY"
            mix.inputs["Factor"].default_value = 1.0
            nt.links.new(tex.outputs["Color"], mix.inputs[6])
            mix.inputs[7].default_value = color
            nt.links.new(mix.outputs[2], bsdf.inputs["Base Color"])
        else:
            nt.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
        if alpha:
            nt.links.new(tex.outputs["Alpha"], bsdf.inputs["Alpha"])
    if alpha == "CLIP":
        mat.blend_method = "CLIP"
        mat.alpha_threshold = 0.45
    elif alpha == "BLEND":
        mat.blend_method = "BLEND"
    return mat


def resize(image, size):
    if image and max(image.size) > size:
        image.scale(size, size)


skin = make_material("Skin", image_from(body), (0.95, 0.8, 0.68, 1), roughness=0.52, specular=0.35)
body.data.materials.clear()
body.data.materials.append(skin)

briefs_mesh.materials.append(make_material("BriefsFabric", None, (0.035, 0.045, 0.07, 1), roughness=0.88, specular=0.2, sheen=0.4))
briefs_mesh.materials.append(make_material("BriefsBand", None, (0.82, 0.83, 0.86, 1), roughness=0.7, specular=0.25))

for o in bpy.data.objects:
    if o.type != "MESH" or o in (body, briefs):
        continue
    img = image_from(o)
    if o.name == "Hair":
        resize(img, 1024)
        mat = make_material("Hair", img, (0.16, 0.11, 0.075, 1), roughness=0.62, alpha="CLIP", specular=0.4)
    elif o.name == "Eyebrows":
        resize(img, 256)
        mat = make_material("Eyebrows", img, (0.2, 0.14, 0.1, 1), roughness=0.8, alpha="BLEND")
    elif o.name == "Eyelashes":
        resize(img, 256)
        mat = make_material("Eyelashes", img, (0.08, 0.06, 0.05, 1), roughness=0.8, alpha="BLEND")
    elif o.name == "Eyes":
        resize(img, 512)
        mat = make_material("Eyes", img, roughness=0.08, specular=0.8)
    else:
        continue
    o.data.materials.clear()
    o.data.materials.append(mat)

# ---------------------------------------------------------------- 5. Retarget helpers
PRIMARY_CHILD = {
    "Hips": "Spine", "Spine": "Spine1", "Spine1": "Spine2", "Spine2": "Neck", "Neck": "Head",
    "LeftShoulder": "LeftArm", "RightShoulder": "RightArm",
    "LeftArm": "LeftForeArm", "RightArm": "RightForeArm",
    "LeftForeArm": "LeftHand", "RightForeArm": "RightHand",
    "LeftHand": "LeftHandMiddle1", "RightHand": "RightHandMiddle1",
    "LeftUpLeg": "LeftLeg", "RightUpLeg": "RightLeg",
    "LeftLeg": "LeftFoot", "RightLeg": "RightFoot",
    "LeftFoot": "LeftToeBase", "RightFoot": "RightToeBase",
}


def rest_dir(rest, name):
    child = PRIMARY_CHILD.get(name.replace("mixamorig:", ""))
    if child and S(child) in rest:
        return (rest[S(child)]["head"] - rest[name]["head"]).normalized()
    return None


def solve_locals(world):
    """world: bone -> desired armature-space rotation. Returns bone -> pose basis quaternion."""
    out = {}
    for name in ORDER:
        parent = REST[name]["parent"]
        frame = world[parent] @ REST[parent]["q"].inverted() @ REST[name]["q"] if parent else REST[name]["q"]
        out[name] = frame.inverted() @ world[name]
    return out


# Relaxed, natural finger curl, applied in rest space and accumulated along each finger.
CURL = {"Thumb": (0.1, 0.15, 0.12), "Index": (0.2, 0.35, 0.22), "Middle": (0.26, 0.42, 0.25), "Ring": (0.31, 0.47, 0.28), "Pinky": (0.38, 0.52, 0.3)}
CURL_SIGN = float(ARGS[2]) if len(ARGS) > 2 else 1.0


def finger_curl(name):
    short = name.replace("mixamorig:", "")
    for side, sign in (("Left", 1.0), ("Right", -1.0)):
        for finger, amounts in CURL.items():
            prefix = f"{side}Hand{finger}"
            if short.startswith(prefix) and short[len(prefix):].isdigit():
                seg = int(short[len(prefix):])
                knuckles = REST[S(f"{side}HandPinky1")]["head"] - REST[S(f"{side}HandIndex1")]["head"]
                axis = knuckles.normalized()
                if finger == "Thumb":
                    palm = (REST[S(f"{side}HandMiddle1")]["head"] - REST[S(f"{side}Hand")]["head"]).normalized()
                    axis = palm
                return Quaternion(axis, sum(amounts[:seg]) * sign * CURL_SIGN)
    return None


def hand_of(name):
    return S(("Left" if "Left" in name else "Right") + "Hand")


def compose_world(delta_of):
    """delta_of(name) -> world rotation applied to the (corrected) rest orientation."""
    world = {}
    for name in ORDER:
        curl = finger_curl(name)
        if curl is not None:
            world[name] = delta_of(hand_of(name)) @ curl @ REST[name]["q"]
        else:
            world[name] = delta_of(name) @ REST[name]["q"]
    return world


def new_action(name, frames, hips_offsets):
    action = bpy.data.actions.new(name)
    action.use_fake_user = True
    n = len(frames)
    for bone in BONES:
        path = f'pose.bones["{bone}"].rotation_quaternion'
        series, prev = [], None
        for f in range(n):
            q = frames[f][bone].copy()
            if prev is not None and prev.dot(q) < 0:
                q.negate()
            prev = q
            series.append(q)
        for i in range(4):
            fc = action.fcurves.new(path, index=i, action_group=bone)
            fc.keyframe_points.add(n)
            fc.keyframe_points.foreach_set("co", [c for f, q in enumerate(series) for c in (f, q[i])])
            for kp in fc.keyframe_points:
                kp.interpolation = "LINEAR"
            fc.update()
    hips = S("Hips")
    rest_inv = REST[hips]["q"].to_matrix().inverted()
    for i in range(3):
        fc = action.fcurves.new(f'pose.bones["{hips}"].location', index=i, action_group=hips)
        fc.keyframe_points.add(n)
        fc.keyframe_points.foreach_set("co", [c for f, off in enumerate(hips_offsets) for c in (f, (rest_inv @ off)[i])])
        for kp in fc.keyframe_points:
            kp.interpolation = "LINEAR"
        fc.update()
    return action


# ---------------------------------------------------------------- 6. Import Xbot and retarget its idle / walk / run
before = set(bpy.data.objects)
before_actions = set(bpy.data.actions)
bpy.ops.import_scene.gltf(filepath=XBOT_PATH)
xbot_objects = [o for o in bpy.data.objects if o not in before]
src = next(o for o in xbot_objects if o.type == "ARMATURE")
src_actions = {a.name.replace("_Armature", ""): a for a in bpy.data.actions if a not in before_actions}
src.animation_data_create()

SRC_REST = {b.name: {"q": rotq(src.matrix_world @ b.matrix_local), "head": src.matrix_world @ b.head_local} for b in src.data.bones}

CORRECTED = {"LeftShoulder", "RightShoulder", "LeftArm", "RightArm", "LeftForeArm", "RightForeArm", "LeftHand", "RightHand",
             "LeftUpLeg", "RightUpLeg", "LeftLeg", "RightLeg", "LeftFoot", "RightFoot"}
CORR = {}
for name in ORDER:
    parent = REST[name]["parent"]
    if name.replace("mixamorig:", "") in CORRECTED and name in SRC_REST:
        CORR[name] = rest_dir(REST, name).rotation_difference(rest_dir(SRC_REST, name))
    else:
        CORR[name] = CORR[parent].copy() if parent else Quaternion()

hip_scale = hips_z / SRC_REST[S("Hips")]["head"].z
src_hips_rest = SRC_REST[S("Hips")]["head"]
clip_info = {}
for src_name, dst_name in (("idle", "Idle"), ("walk", "Walk"), ("run", "Run")):
    action = src_actions[src_name]
    src.animation_data.action = action
    start, end = int(round(action.frame_range[0])), int(round(action.frame_range[1]))
    frames, hips_raw = [], []
    for f in range(start, end + 1):
        scene.frame_set(f)
        delta = {}
        for name in ORDER:
            pb = src.pose.bones.get(name)
            if pb:
                delta[name] = rotq(src.matrix_world @ pb.matrix) @ SRC_REST[name]["q"].inverted()
            else:
                parent = REST[name]["parent"]
                delta[name] = delta[parent].copy() if parent else Quaternion()
        frames.append(solve_locals(compose_world(lambda n: delta[n] @ CORR[n])))
        hips_raw.append((src.matrix_world @ src.pose.bones[S("Hips")].matrix).translation.copy())
    drift = hips_raw[-1] - hips_raw[0]
    drift.z = 0
    first = hips_raw[0] - src_hips_rest
    offsets = []
    for i, h in enumerate(hips_raw):
        d = h - src_hips_rest - drift * (i / max(1, len(hips_raw) - 1))
        d.x -= first.x
        d.y -= first.y
        offsets.append(d * hip_scale)
    new_action(dst_name, frames, offsets)
    clip_info[dst_name] = {"frames": len(frames), "duration": (len(frames) - 1) / FPS}

for o in xbot_objects:
    bpy.data.objects.remove(o, do_unlink=True)
for a in src_actions.values():
    bpy.data.actions.remove(a)

# ---------------------------------------------------------------- 7. Hand-authored car poses (directions in glTF space: +X left, +Y up, +Z forward)
def gl(v):
    return Vector((v[0], -v[2], v[1])).normalized()


def pose(spec):
    delta = {}
    for name in ORDER:
        short = name.replace("mixamorig:", "")
        parent = REST[name]["parent"]
        if short in spec and rest_dir(REST, name) is not None:
            delta[name] = rest_dir(REST, name).rotation_difference(gl(spec[short]))
        else:
            delta[name] = delta[parent].copy() if parent else Quaternion()
    return solve_locals(compose_world(lambda n: delta[n]))


def keep(*names):
    out = {}
    for n in names:
        d = rest_dir(REST, S(n))
        if d is not None:
            out[n] = (d.x, d.z, -d.y)
    return out


SIT = pose({
    **keep("LeftShoulder", "RightShoulder", "Neck"),
    "Hips": (0, 0.97, -0.22), "Spine": (0, 0.97, -0.24), "Spine1": (0, 0.98, -0.18), "Spine2": (0, 0.99, -0.1),
    "LeftUpLeg": (0.14, -0.08, 0.99), "RightUpLeg": (-0.14, -0.08, 0.99),
    "LeftLeg": (0.05, -0.86, 0.5), "RightLeg": (-0.05, -0.86, 0.5),
    "LeftFoot": (0.05, -0.45, 0.89), "RightFoot": (-0.05, -0.45, 0.89),
    "LeftArm": (0.28, -0.55, 0.78), "RightArm": (-0.28, -0.55, 0.78),
    "LeftForeArm": (-0.2, 0.32, 0.93), "RightForeArm": (0.2, 0.32, 0.93),
    "LeftHand": (-0.25, 0.15, 0.95), "RightHand": (0.25, 0.15, 0.95),
})
REACH = pose({
    **keep("LeftShoulder", "RightShoulder", "Neck", "Hips"),
    "Spine": (0, 0.99, 0.12), "Spine1": (0, 0.99, 0.1), "Spine2": (0, 0.99, 0.05),
    "LeftUpLeg": (0.05, -1, 0.02), "RightUpLeg": (-0.05, -1, 0.02),
    "LeftLeg": (0.02, -1, -0.03), "RightLeg": (-0.02, -1, -0.03),
    "LeftFoot": (0.05, -0.5, 0.86), "RightFoot": (-0.05, -0.5, 0.86),
    "LeftArm": (0.18, -0.98, 0.05), "LeftForeArm": (0.08, -0.98, 0.15),
    "RightArm": (-0.2, -0.32, 0.93), "RightForeArm": (-0.05, -0.12, 0.99), "RightHand": (-0.02, -0.25, 0.97),
})
zero = [Vector((0, 0, 0)), Vector((0, 0, 0))]
new_action("Sit", [SIT, SIT], zero)
new_action("Reach", [REACH, REACH], zero)

# ---------------------------------------------------------------- 8. Measure stance speed so the game can match playback to ground speed
arm.animation_data_create()
for pb in arm.pose.bones:
    pb.rotation_mode = "QUATERNION"
for name in ("Walk", "Run"):
    arm.animation_data.action = bpy.data.actions[name]
    n = clip_info[name]["frames"]
    speeds = []
    for side in ("Left", "Right"):
        pts = []
        for f in range(n):
            scene.frame_set(f)
            pts.append((arm.matrix_world @ arm.pose.bones[S(f"{side}Foot")].head).copy())
        low = min(p.z for p in pts)
        for f in range(1, n):
            if pts[f].z < low + 0.03 and pts[f - 1].z < low + 0.03:
                speeds.append((pts[f].y - pts[f - 1].y) * FPS)
    clip_info[name]["stanceSpeed"] = sum(speeds) / len(speeds) if speeds else 0

# Each clip goes on its own NLA track so the exporter writes all of them as separate animations.
arm.animation_data.action = None
for name in ("Idle", "Walk", "Run", "Sit", "Reach"):
    track = arm.animation_data.nla_tracks.new()
    track.name = name
    track.strips.new(name, 0, bpy.data.actions[name])
    track.mute = True
for pb in arm.pose.bones:
    pb.rotation_quaternion = (1, 0, 0, 0)
    pb.location = (0, 0, 0)
scene.frame_set(0)

# ---------------------------------------------------------------- 9. Export
activate(arm)
for o in bpy.context.view_layer.objects:
    o.select_set(o.type in ("MESH", "ARMATURE"))
bpy.ops.export_scene.gltf(
    filepath=OUT_PATH,
    export_format="GLB",
    use_selection=True,
    export_yup=True,
    export_texcoords=True,
    export_normals=True,
    export_tangents=False,
    export_materials="EXPORT",
    export_image_format="WEBP",
    export_image_quality=88,
    export_skins=True,
    export_all_influences=False,
    export_morph=False,
    export_animations=True,
    export_animation_mode="NLA_TRACKS",
    export_force_sampling=True,
    export_frame_step=1,
    export_anim_single_armature=True,
    export_reset_pose_bones=True,
)
bounds = [o.matrix_world @ Vector(c) for o in bpy.data.objects if o.type == "MESH" for c in o.bound_box]
info = {
    "clips": clip_info,
    "hipsHeight": hips_z,
    "height": max(v.z for v in bounds) - min(v.z for v in bounds),
    "meshes": {o.name: len(o.data.vertices) for o in bpy.data.objects if o.type == "MESH"},
}
print("BUILD_INFO", json.dumps(info))
bpy.ops.wm.save_as_mainfile(filepath=OUT_PATH.replace(".glb", ".blend"))
