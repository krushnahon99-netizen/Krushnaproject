##as at @e[type=minecraft:vindicator,tag=aihunter]
#set

scoreboard players set @s aihunter_upgrade 2

attribute @s minecraft:armor base set 8

attribute @s minecraft:armor_toughness base set 0

data merge entity @s {HandItems:[{},{}]}

execute unless data storage minecraft:aihunter_custom armor run data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] {equipment:{feet:{id:"minecraft:iron_boots"},legs:{id:"minecraft:leather_leggings"},chest:{id:"minecraft:iron_chestplate"},head:{id:"minecraft:skeleton_skull"}}}


#message

execute if score notifyupgrade aihunter_dummy matches 1.. run function krushna:aihunter/message/upgrade