import { game, input, getPlayerCar, publishHud, pushNotice, randomCashValue, type Car } from './state'
import { BLOCK, BLOCK_CENTERS, WORLD_BOUNDS, city, randomRoadPoint, type Box } from './world'
import { CAR_SCALE, seatLayout } from './cars'

const CAR_RADIUS = 1.05 * CAR_SCALE
const CAR_AXLE_OFFSET = 1.25 * CAR_SCALE
const PLAYER_RADIUS = 0.4
const MAX_SPEED = 46
const ENGINE = 16
const BRAKE = 32
const REVERSE_MAX = 12
const WHEELBASE = 2.6
const INTERACT_RANGE = 3.6 * CAR_SCALE

let hudTimer = 0

export function groundHeight(x: number, z: number) {
  const half = BLOCK / 2
  const inX = BLOCK_CENTERS.some((c) => Math.abs(x - c) < half)
  const inZ = BLOCK_CENTERS.some((c) => Math.abs(z - c) < half)
  return inX && inZ ? 0.25 : 0
}

function forwardOf(heading: number) {
  return { x: Math.sin(heading), z: Math.cos(heading) }
}

function carCircles(car: Car) {
  const f = forwardOf(car.heading)
  return [
    { x: car.x + f.x * CAR_AXLE_OFFSET, z: car.z + f.z * CAR_AXLE_OFFSET },
    { x: car.x - f.x * CAR_AXLE_OFFSET, z: car.z - f.z * CAR_AXLE_OFFSET },
  ]
}

function pushOutOfBox(px: number, pz: number, radius: number, box: Box) {
  if (px < box.minX - radius || px > box.maxX + radius || pz < box.minZ - radius || pz > box.maxZ + radius) return null
  const cx = Math.max(box.minX, Math.min(px, box.maxX))
  const cz = Math.max(box.minZ, Math.min(pz, box.maxZ))
  let dx = px - cx
  let dz = pz - cz
  let distance = Math.hypot(dx, dz)
  if (distance >= radius) return null
  if (distance === 0) {
    const left = px - box.minX
    const right = box.maxX - px
    const top = pz - box.minZ
    const bottom = box.maxZ - pz
    const min = Math.min(left, right, top, bottom)
    if (min === left) return { nx: -1, nz: 0, depth: left + radius }
    if (min === right) return { nx: 1, nz: 0, depth: right + radius }
    if (min === top) return { nx: 0, nz: -1, depth: top + radius }
    return { nx: 0, nz: 1, depth: bottom + radius }
  }
  dx /= distance
  dz /= distance
  return { nx: dx, nz: dz, depth: radius - distance }
}

function collideCarWithWorld(car: Car) {
  for (const circle of carCircles(car)) {
    for (const box of city.colliders) {
      const hit = pushOutOfBox(circle.x, circle.z, CAR_RADIUS, box)
      if (!hit) continue
      car.x += hit.nx * hit.depth
      car.z += hit.nz * hit.depth
      circle.x += hit.nx * hit.depth
      circle.z += hit.nz * hit.depth
      const into = car.vx * hit.nx + car.vz * hit.nz
      if (into < 0) {
        car.vx -= hit.nx * into * 1.35
        car.vz -= hit.nz * into * 1.35
        car.vx *= 0.82
        car.vz *= 0.82
        if (car.id === game.carId && into < -7) game.shake = Math.min(1, -into / 25)
        if (car.kind === 'traffic') car.speed *= 0.3
      }
    }
  }
  if (car.x < WORLD_BOUNDS.minX || car.x > WORLD_BOUNDS.maxX) {
    car.x = Math.max(WORLD_BOUNDS.minX, Math.min(WORLD_BOUNDS.maxX, car.x))
    car.vx *= -0.3
  }
  if (car.z < WORLD_BOUNDS.minZ || car.z > WORLD_BOUNDS.maxZ) {
    car.z = Math.max(WORLD_BOUNDS.minZ, Math.min(WORLD_BOUNDS.maxZ, car.z))
    car.vz *= -0.3
  }
}

function collideCars(a: Car, b: Car) {
  if (Math.abs(a.x - b.x) > 6 || Math.abs(a.z - b.z) > 6) return
  for (const ca of carCircles(a)) {
    for (const cb of carCircles(b)) {
      const dx = ca.x - cb.x
      const dz = ca.z - cb.z
      const distance = Math.hypot(dx, dz)
      const minDistance = CAR_RADIUS * 2
      if (distance >= minDistance || distance === 0) continue
      const nx = dx / distance
      const nz = dz / distance
      const depth = minDistance - distance
      const aStatic = a.kind === 'traffic' && b.kind !== 'traffic' ? 0.35 : 0.5
      a.x += nx * depth * aStatic
      a.z += nz * depth * aStatic
      b.x -= nx * depth * (1 - aStatic)
      b.z -= nz * depth * (1 - aStatic)

      const relative = (a.vx - b.vx) * nx + (a.vz - b.vz) * nz
      if (relative < 0) {
        const impulse = -relative * 0.75
        a.vx += nx * impulse
        a.vz += nz * impulse
        b.vx -= nx * impulse
        b.vz -= nz * impulse
      }

      const involvesPlayer = a.id === game.carId || b.id === game.carId
      if (involvesPlayer) {
        const other = a.id === game.carId ? b : a
        if (other.kind === 'traffic') other.stun = 1.6
        if (-relative > 5) {
          game.shake = Math.min(1, -relative / 20)
          commitCrime()
        }
      }
    }
  }
}

function commitCrime() {
  if (game.time - game.lastCrime < 1.2) return
  game.lastCrime = game.time
  if (game.wanted < 5) {
    game.wanted += 1
    pushNotice(game.wanted === 1 ? 'Wanted level raised' : `Wanted level ${game.wanted}`, 'alert')
  }
}

function updateDrivableCar(car: Car, dt: number, driven: boolean) {
  const stick = driven && input.stickActive
  const stickThrottle = stick && input.stickY > 0.25 ? Math.min(1, (input.stickY - 0.25) / 0.6) : 0
  const stickBrake = stick && input.stickY < -0.35 ? 1 : 0
  const throttle = driven ? Math.max(input.forward ? 1 : 0, stickThrottle) : 0
  const brake = driven ? Math.max(input.back ? 1 : 0, stickBrake) : 0
  const handbrake = driven && input.handbrake
  const keySteer = (input.left ? 1 : 0) - (input.right ? 1 : 0)
  const steerInput = driven ? Math.max(-1, Math.min(1, keySteer - (stick ? input.stickX : 0))) : 0

  let f = forwardOf(car.heading)
  let fwd = car.vx * f.x + car.vz * f.z

  car.steer += (steerInput - car.steer) * Math.min(1, dt * 7)
  const steerMax = 0.6 * (1 - Math.min(Math.abs(fwd) / MAX_SPEED, 1) * 0.6)
  let yawRate = (fwd / WHEELBASE) * Math.tan(car.steer * steerMax)
  if (handbrake) yawRate *= 1.45
  car.heading += yawRate * dt

  f = forwardOf(car.heading)
  const r = { x: -f.z, z: f.x }
  fwd = car.vx * f.x + car.vz * f.z
  let lat = car.vx * r.x + car.vz * r.z
  const prevFwd = fwd

  if (throttle) {
    fwd += ENGINE * throttle * (1 - Math.max(0, fwd) / MAX_SPEED) * dt * (fwd < 0 ? 2.2 : 1)
  }
  if (brake) {
    if (fwd > 0.5) fwd -= BRAKE * dt
    else fwd = Math.max(-REVERSE_MAX, fwd - 9 * dt)
  }
  if (!throttle && !brake) {
    const rolling = driven ? 3.5 : 14
    fwd -= Math.sign(fwd) * Math.min(Math.abs(fwd), rolling * dt)
  }
  if (handbrake) fwd -= Math.sign(fwd) * Math.min(Math.abs(fwd), 9 * dt)
  fwd = Math.min(fwd, MAX_SPEED)

  const grip = handbrake ? 1.6 : 9
  lat *= Math.exp(-grip * dt)

  car.vx = f.x * fwd + r.x * lat
  car.vz = f.z * fwd + r.z * lat
  car.x += car.vx * dt
  car.z += car.vz * dt

  const accel = (fwd - prevFwd) / Math.max(dt, 0.0001)
  car.braking = brake === 1 && fwd > 0.5
  car.slip = lat
  car.wheelSpin += (fwd / 0.38) * dt
  car.roll += (Math.max(-0.08, Math.min(0.08, -yawRate * fwd * 0.004 - lat * 0.01)) - car.roll) * Math.min(1, dt * 6)
  car.pitch += (Math.max(-0.05, Math.min(0.05, -accel * 0.0025)) - car.pitch) * Math.min(1, dt * 6)
}

function updateTrafficCar(car: Car, dt: number) {
  if (car.stun > 0) {
    car.stun -= dt
    car.x += car.vx * dt
    car.z += car.vz * dt
    car.vx *= Math.exp(-3 * dt)
    car.vz *= Math.exp(-3 * dt)
    car.speed = 0
    car.braking = true
    return
  }

  const target = car.loop[car.segment]
  const previous = car.loop[(car.segment + car.loop.length - 1) % car.loop.length]
  const realDistance = Math.hypot(target.x - car.x, target.z - car.z)
  if (realDistance < 1.5) {
    car.segment = (car.segment + 1) % car.loop.length
    return
  }

  car.bypass = Math.max(0, car.bypass - dt)
  let tx = target.x
  let tz = target.z
  if (car.bypass > 0 && realDistance > 16) {
    const segLength = Math.hypot(target.x - previous.x, target.z - previous.z) || 1
    const sx = (target.x - previous.x) / segLength
    const sz = (target.z - previous.z) / segLength
    const along = (car.x - previous.x) * sx + (car.z - previous.z) * sz + 10
    tx = previous.x + sx * along + sz * 3.2
    tz = previous.z + sz * along - sx * 3.2
  }
  const dx = tx - car.x
  const dz = tz - car.z
  const distance = realDistance

  const desiredHeading = Math.atan2(dx, dz)
  let delta = desiredHeading - car.heading
  delta = Math.atan2(Math.sin(delta), Math.cos(delta))
  car.heading += delta * Math.min(1, dt * 4)

  let targetSpeed = distance < 14 ? 6.5 : car.bypass > 0 ? 7 : car.cruiseSpeed
  const obstacle = obstacleAhead(car)
  if (obstacle) {
    targetSpeed = 0
    car.blocked += dt
    if (obstacle === 'parked' && car.blocked > 1.5) {
      car.bypass = 3.5
      car.blocked = 0
    }
  } else {
    car.blocked = 0
  }
  const rate = targetSpeed < car.speed ? 18 : 5
  car.speed += Math.sign(targetSpeed - car.speed) * Math.min(Math.abs(targetSpeed - car.speed), rate * dt)
  car.braking = targetSpeed < car.speed - 0.5 || targetSpeed === 0

  const f = forwardOf(car.heading)
  car.vx = f.x * car.speed
  car.vz = f.z * car.speed
  car.x += car.vx * dt
  car.z += car.vz * dt
  car.wheelSpin += (car.speed / 0.38) * dt
  car.steer = Math.max(-1, Math.min(1, delta * 2))
  car.roll *= 0.9
  car.pitch *= 0.9
}

function obstacleAhead(car: Car): 'traffic' | 'parked' | 'player' | null {
  const f = forwardOf(car.heading)
  const check = (x: number, z: number, range: number) => {
    const dx = x - car.x
    const dz = z - car.z
    const ahead = dx * f.x + dz * f.z
    if (ahead <= 0 || ahead > range) return false
    const lateral = Math.abs(dx * -f.z + dz * f.x)
    return lateral < 2.2
  }
  for (const other of game.cars) {
    if (other === car) continue
    if (!check(other.x, other.z, 9.5)) continue
    if (other.kind === 'traffic') {
      const of = forwardOf(other.heading)
      const sameDirection = of.x * f.x + of.z * f.z > 0.5
      if (sameDirection || other.id < car.id) return 'traffic'
    } else if (other.id === game.carId && Math.hypot(other.vx, other.vz) > 1) {
      return 'player'
    } else if (car.bypass <= 0) {
      return 'parked'
    }
  }
  if (game.mode === 'foot' && check(game.player.x, game.player.z, 8)) return 'player'
  return null
}

function updatePlayerOnFoot(dt: number) {
  const p = game.player
  let target: number
  const stickAmount = Math.min(1, Math.hypot(input.stickX, input.stickY))
  if (input.stickActive && stickAmount > 0.05) {
    // Stick is camera-relative; offset cameraDrag by the turn so the camera holds its world direction.
    const cameraYaw = p.heading + input.cameraDrag
    const desired = cameraYaw - Math.atan2(input.stickX, input.stickY)
    let delta = desired - p.heading
    delta = Math.atan2(Math.sin(delta), Math.cos(delta))
    const step = Math.sign(delta) * Math.min(Math.abs(delta), 12 * dt)
    p.heading += step
    input.cameraDrag -= step
    const facing = Math.max(0, Math.cos(delta))
    target = stickAmount * (input.sprint || stickAmount > 0.92 ? 8.5 : 4.6) * facing
  } else {
    const turn = (input.left ? 1 : 0) - (input.right ? 1 : 0)
    p.heading += turn * 2.8 * dt
    target = input.forward ? (input.sprint ? 8.5 : 4.2) : input.back ? -2.4 : 0
  }
  p.speed += (target - p.speed) * Math.min(1, dt * 8)

  const f = forwardOf(p.heading)
  p.x += f.x * p.speed * dt
  p.z += f.z * p.speed * dt

  const ground = groundHeight(p.x, p.z)
  if (input.handbrake && p.y <= ground + 0.01) p.vy = 6.5
  p.vy -= 22 * dt
  p.y += p.vy * dt
  if (p.y < ground) {
    p.y = ground
    p.vy = 0
  }

  for (const box of city.colliders) {
    const hit = pushOutOfBox(p.x, p.z, PLAYER_RADIUS, box)
    if (hit) {
      p.x += hit.nx * hit.depth
      p.z += hit.nz * hit.depth
    }
  }
  for (const car of game.cars) {
    for (const circle of carCircles(car)) {
      const dx = p.x - circle.x
      const dz = p.z - circle.z
      const distance = Math.hypot(dx, dz)
      const minDistance = CAR_RADIUS + PLAYER_RADIUS
      if (distance < minDistance && distance > 0) {
        p.x += (dx / distance) * (minDistance - distance)
        p.z += (dz / distance) * (minDistance - distance)
      }
    }
  }
  p.x = Math.max(WORLD_BOUNDS.minX, Math.min(WORLD_BOUNDS.maxX, p.x))
  p.z = Math.max(WORLD_BOUNDS.minZ, Math.min(WORLD_BOUNDS.maxZ, p.z))
  p.phase += Math.abs(p.speed) * dt * 1.9
}

function nearestCar() {
  let best: Car | null = null
  let bestDistance = INTERACT_RANGE
  for (const car of game.cars) {
    const d = Math.hypot(car.x - game.player.x, car.z - game.player.z)
    if (d < bestDistance) {
      bestDistance = d
      best = car
    }
  }
  return best
}

function beginTransition(kind: 'enter' | 'exit', car: Car) {
  const p = game.player
  game.transition = { kind, carId: car.id, t: 0, fromX: p.x, fromZ: p.z, fromY: p.y, fromHeading: p.heading }
  game.carId = car.id
  game.prompt = null
}

function handleInteraction() {
  const queued = input.interactQueued
  input.interactQueued = false

  if (game.transition) {
    game.prompt = null
    return
  }

  if (game.mode === 'foot') {
    const car = nearestCar()
    game.prompt = car ? (car.kind === 'traffic' ? 'Press F to steal car' : 'Press F to drive') : null
    if (!queued || !car) return
    if (car.kind === 'traffic') {
      const f = forwardOf(car.heading)
      car.vx = f.x * car.speed * 0.3
      car.vz = f.z * car.speed * 0.3
      car.kind = 'drivable'
      commitCrime()
    }
    beginTransition('enter', car)
    return
  }

  const car = getPlayerCar()
  if (!car) return
  const speed = Math.hypot(car.vx, car.vz)
  game.prompt = speed < 1 ? 'Press F to exit' : null
  if (!queued) return
  if (speed > 9) {
    pushNotice('Slow down to exit', 'alert')
    return
  }
  beginTransition('exit', car)
}

const ENTER = { approach: 0.45, open: 0.85, slide: 1.35, end: 1.7 }
const EXIT = { open: 0.3, slide: 0.8, end: 1.25 }

const lerp = (a: number, b: number, t: number) => a + (b - a) * t
const ease = (t: number) => {
  const k = Math.min(1, Math.max(0, t))
  return k * k * (3 - 2 * k)
}
const lerpAngle = (a: number, b: number, t: number) => a + Math.atan2(Math.sin(b - a), Math.cos(b - a)) * t

/** Car-local to world: local +x is the driver (left) side, local +z is forward. */
function carLocalToWorld(car: Car, lx: number, lz: number) {
  const f = forwardOf(car.heading)
  return { x: car.x + f.z * lx + f.x * lz, z: car.z - f.x * lx + f.z * lz }
}

function placeAtSeat(car: Car) {
  const layout = seatLayout(car.variant)
  const seat = carLocalToWorld(car, layout.seatX, layout.seatZ)
  const p = game.player
  p.x = seat.x
  p.z = seat.z
  p.y = groundHeight(car.x, car.z) + layout.rootY
  p.heading = car.heading
  p.speed = 0
  p.vy = 0
  p.sit = 1
  p.reach = 0
}

function updateTransition(dt: number) {
  const tr = game.transition
  if (!tr) return
  const car = game.cars[tr.carId]
  const p = game.player
  const layout = seatLayout(car.variant)
  const door = carLocalToWorld(car, layout.doorX, layout.doorZ)
  const seat = carLocalToWorld(car, layout.seatX, layout.seatZ)
  const doorGround = groundHeight(door.x, door.z)
  const seatY = groundHeight(car.x, car.z) + layout.rootY
  const facingCar = car.heading - Math.PI / 2
  const facingOut = car.heading + Math.PI / 2
  tr.t += dt
  const t = tr.t
  p.vy = 0

  if (tr.kind === 'enter') {
    if (t < ENTER.approach) {
      const k = ease(t / ENTER.approach)
      p.x = lerp(tr.fromX, door.x, k)
      p.z = lerp(tr.fromZ, door.z, k)
      p.y = lerp(tr.fromY, doorGround, k)
      p.heading = lerpAngle(tr.fromHeading, facingCar, ease(t / (ENTER.approach * 0.7)))
      p.speed = Math.hypot(door.x - tr.fromX, door.z - tr.fromZ) / ENTER.approach
      p.phase += p.speed * dt * 1.9
      p.sit = 0
      p.reach = 0
      car.door = 0
    } else if (t < ENTER.open) {
      const k = ease((t - ENTER.approach) / (ENTER.open - ENTER.approach))
      p.x = door.x
      p.z = door.z
      p.y = doorGround
      p.heading = facingCar
      p.speed = 0
      p.reach = k
      car.door = k
    } else if (t < ENTER.slide) {
      const k = ease((t - ENTER.open) / (ENTER.slide - ENTER.open))
      p.x = lerp(door.x, seat.x, k)
      p.z = lerp(door.z, seat.z, k)
      p.y = lerp(doorGround, seatY, k)
      p.heading = lerpAngle(facingCar, car.heading, k)
      p.reach = 1 - k
      p.sit = k
      car.door = 1
    } else {
      placeAtSeat(car)
      car.door = 1 - ease((t - ENTER.slide) / (ENTER.end - ENTER.slide))
    }
    if (t >= ENTER.end) {
      car.door = 0
      game.mode = 'car'
      game.transition = null
    }
    return
  }

  if (t < EXIT.open) {
    placeAtSeat(car)
    car.door = ease(t / EXIT.open)
  } else if (t < EXIT.slide) {
    const k = ease((t - EXIT.open) / (EXIT.slide - EXIT.open))
    p.x = lerp(seat.x, door.x, k)
    p.z = lerp(seat.z, door.z, k)
    p.y = lerp(seatY, doorGround, k)
    p.heading = lerpAngle(car.heading, facingOut, k)
    p.sit = 1 - k
    p.reach = Math.sin(k * Math.PI) * 0.6
    car.door = 1
  } else {
    const k = ease((t - EXIT.slide) / (EXIT.end - EXIT.slide))
    const clear = carLocalToWorld(car, layout.doorX + 0.45, layout.doorZ - 0.35)
    p.x = lerp(door.x, clear.x, k)
    p.z = lerp(door.z, clear.z, k)
    p.y = lerp(doorGround, groundHeight(clear.x, clear.z), k)
    p.heading = lerpAngle(facingOut, car.heading, k)
    p.speed = k < 1 ? Math.hypot(clear.x - door.x, clear.z - door.z) / (EXIT.end - EXIT.slide) : 0
    p.phase += p.speed * dt * 1.9
    p.sit = 0
    p.reach = 0
    car.door = 1 - ease((t - EXIT.slide - 0.1) / (EXIT.end - EXIT.slide - 0.1))
  }
  if (t >= EXIT.end) {
    car.door = 0
    p.speed = 0
    game.mode = 'foot'
    game.carId = null
    game.transition = null
  }
}

function updatePickups() {
  const focus = getPlayerCar() ?? game.player
  const radius = game.mode === 'car' ? 3.4 : 1.8
  for (const pickup of game.pickups) {
    if (Math.hypot(pickup.x - focus.x, pickup.z - focus.z) < radius) {
      game.money += pickup.value
      pushNotice(`+$${pickup.value.toLocaleString()}`, 'cash')
      Object.assign(pickup, randomRoadPoint(), { value: randomCashValue() })
    }
  }
}

function updateWanted() {
  if (game.wanted > 0 && game.time - game.lastCrime > 18) {
    game.wanted -= 1
    game.lastCrime = game.time - 6
    if (game.wanted === 0) pushNotice('You lost the heat', 'cash')
  }
}

export function updateGame(dt: number) {
  if (!game.started) return
  game.time += dt

  handleInteraction()

  for (const car of game.cars) {
    if (car.kind === 'traffic') updateTrafficCar(car, dt)
    else updateDrivableCar(car, dt, car.id === game.carId && game.mode === 'car' && !game.transition)
  }

  for (let i = 0; i < game.cars.length; i++) {
    for (let j = i + 1; j < game.cars.length; j++) collideCars(game.cars[i], game.cars[j])
  }
  for (const car of game.cars) {
    if (car.kind === 'drivable' || car.stun > 0) collideCarWithWorld(car)
  }

  if (game.transition) updateTransition(dt)
  else if (game.mode === 'foot') updatePlayerOnFoot(dt)
  else {
    const car = getPlayerCar()
    if (car) placeAtSeat(car)
  }

  updatePickups()
  updateWanted()
  game.shake = Math.max(0, game.shake - dt * 2.5)

  hudTimer += dt
  if (hudTimer > 0.1) {
    hudTimer = 0
    publishHud()
  }
}
