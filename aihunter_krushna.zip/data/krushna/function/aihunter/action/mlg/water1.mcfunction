execute if block ~ ~ ~ #krushna:aihunter/liquid_replaceable run setblock ~ ~ ~ minecraft:water destroy

execute unless block ~ ~ ~ #krushna:aihunter/liquid_replaceable run setblock ~ ~1 ~ minecraft:water keep

playsound minecraft:item.bucket.empty master @a ~ ~ ~


#debug reporting

execute if score debug aihunter_dummy matches 1 run say mlg: executed (water)