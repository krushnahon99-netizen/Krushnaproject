import { NodeIO } from '@gltf-transform/core'
import * as THREE from 'three'

const io = new NodeIO()
const doc = await io.read('/tmp/mh.glb')
const src = await io.read('/tmp/xbot.glb')
const root = doc.getRoot()
const buffer = root.listBuffers()[0]

// ---------- 1. Bake a middle-aged, broad-shouldered man from the morph targets ----------
const MORPHS = {
  bodyMasculine: 1,
  bodyCaucasian: 1,
  bodyOlder: 0.4,
  headAged: 0.45,
  bodyHeavier: 0.12,
  bellyBigger: 0.18,
  chestWider: 0.25,
  chestPectoralsLess: 0.6,
  shouldersWider: 0.35,
  neckThicker: 0.35,
  armsThicker: 0.15,
  jawBonesStronger: 0.6,
  jawWider: 0.3,
  headSquare: 0.35,
  browsDown: 0.35,
  noseBigger: 0.15,
  mouthNarrower: 0.15,
  mouthUpperLipThinner: 0.5,
  mouthLowerLipThinner: 0.5,
  cheekHollowLeft: 0.2,
  cheekHollowRight: 0.2,
}

for (const mesh of root.listMeshes()) {
  const names = mesh.getExtras()?.targetNames ?? []
  for (const prim of mesh.listPrimitives()) {
    const targets = prim.listTargets()
    const pos = prim.getAttribute('POSITION')
    const nor = prim.getAttribute('NORMAL')
    const P = pos.getArray().slice()
    const N = nor ? nor.getArray().slice() : null
    targets.forEach((t, i) => {
      const w = MORPHS[names[i]]
      if (!w) return
      const tp = t.getAttribute('POSITION')?.getArray()
      if (tp) for (let k = 0; k < P.length; k++) P[k] += w * tp[k]
      const tn = t.getAttribute('NORMAL')?.getArray()
      if (tn && N) for (let k = 0; k < N.length; k++) N[k] += w * tn[k]
    })
    pos.setArray(P)
    if (N) {
      for (let k = 0; k < N.length; k += 3) {
        const l = Math.hypot(N[k], N[k + 1], N[k + 2]) || 1
        N[k] /= l
        N[k + 1] /= l
        N[k + 2] /= l
      }
      nor.setArray(N)
    }
    for (const t of targets) {
      prim.removeTarget(t)
      t.listAttributes().forEach((a) => a.dispose())
      t.dispose()
    }
    prim.setAttribute('TEXCOORD_0', null)
  }
  mesh.setWeights([])
  mesh.setExtras({})
}

for (const node of root.listNodes()) {
  if (node.getName() === 'Tongue') {
    node.getMesh()?.listPrimitives().forEach((p) => p.listAttributes().forEach((a) => a.dispose()))
    node.getMesh()?.dispose()
    node.dispose()
  }
}

// ---------- 2. Skeleton rest data (all rest rotations are identity, so world = summed offsets) ----------
const skin = root.listSkins()[0]
const joints = skin.listJoints()
const byName = new Map(joints.map((j) => [j.getName(), j]))
const restWorld = new Map()
function worldOf(node) {
  if (restWorld.has(node)) return restWorld.get(node)
  const t = new THREE.Vector3(...node.getTranslation())
  const parent = node.getParentNode()
  const w = parent && byName.has(parent.getName()) ? worldOf(parent).clone().add(t) : t
  restWorld.set(node, w)
  return w
}
joints.forEach(worldOf)
const J = (n) => restWorld.get(byName.get('mixamorig:' + n))

const neckY = J('Neck').y
const hipsY = J('Hips').y

// ---------- 3. Paint the outfit with vertex colours, using each vertex's dominant bone ----------
const srgb = (hex) => {
  const c = new THREE.Color(hex)
  return [c.r, c.g, c.b]
}
const COLORS = {
  skin: srgb('#c99574'),
  lips: srgb('#b27a6a'),
  brow: srgb('#2b211b'),
  hair: srgb('#2a221d'),
  hairGrey: srgb('#4a443f'),
  shirt: srgb('#c3d0dc'),
  shirtCollar: srgb('#b4c3d1'),
  belt: srgb('#17120f'),
  buckle: srgb('#9a9488'),
  pants: srgb('#2c2e33'),
  shoes: srgb('#22150e'),
  sock: srgb('#141416'),
}

const eyeNode = root.listNodes().find((n) => n.getName() === 'Eyes')
const eyePos = eyeNode.getMesh().listPrimitives()[0].getAttribute('POSITION').getArray()
let eyeL = { x: 0, y: 0, z: -9, n: 0 }
let eyeR = { x: 0, y: 0, z: -9, n: 0 }
for (let i = 0; i < eyePos.length; i += 3) {
  const e = eyePos[i] > 0 ? eyeL : eyeR
  e.x += eyePos[i]
  e.y += eyePos[i + 1]
  e.z = Math.max(e.z, eyePos[i + 2])
  e.n++
}
eyeL = { x: eyeL.x / eyeL.n, y: eyeL.y / eyeL.n, z: eyeL.z }
eyeR = { x: eyeR.x / eyeR.n, y: eyeR.y / eyeR.n, z: eyeR.z }
const eyeY = (eyeL.y + eyeR.y) / 2
const eyeZ = Math.max(eyeL.z, eyeR.z)

const body = root.listMeshes().find((m) => m.getName() === 'Body').listPrimitives()[0]
const BP = body.getAttribute('POSITION').getArray()
const BJ = body.getAttribute('JOINTS_0').getArray()
const BW = body.getAttribute('WEIGHTS_0').getArray()
const jointName = joints.map((j) => j.getName().replace('mixamorig:', ''))

const footY = Math.max(J('LeftFoot').y, J('RightFoot').y)
const beltY = hipsY + 0.075

const colors = new Float32Array(BP.length)
const clothKind = new Int8Array(BP.length / 3)
for (let v = 0; v < BP.length / 3; v++) {
  const x = BP[v * 3]
  const y = BP[v * 3 + 1]
  const z = BP[v * 3 + 2]
  let best = 0
  let bestW = -1
  for (let k = 0; k < 4; k++) {
    if (BW[v * 4 + k] > bestW) {
      bestW = BW[v * 4 + k]
      best = BJ[v * 4 + k]
    }
  }
  const bone = jointName[best]
  let c = COLORS.skin

  if (/Hand|Thumb|Index|Middle|Ring|Pinky/.test(bone)) c = COLORS.skin
  else if (bone === 'Head' || bone === 'HeadTop_End' || bone === 'Neck' || /Eye/.test(bone)) {
    c = COLORS.skin
    const back = eyeZ - z
    if (back < 0.035 && y > eyeY + 0.05 + Math.abs(x) * 0.12) c = COLORS.hair
    else if (back >= 0.035 && back < 0.085 && y > eyeY + 0.03 - (back - 0.035) * 0.4) c = COLORS.hair
    else if (back >= 0.085 && y > eyeY - 0.055 - (back - 0.085) * 0.6) c = COLORS.hair
    if (c === COLORS.hair && back > 0.04 && back < 0.12 && Math.abs(x) > 0.07 && y < eyeY + 0.035) c = COLORS.hairGrey
    if (back > 0.06 && back < 0.13 && Math.abs(x) > 0.075 && y < eyeY + 0.01 && y > eyeY - 0.06) c = COLORS.skin
    for (const e of [eyeL, eyeR]) {
      const dx = Math.abs(x - e.x)
      if (back < 0.03 && dx < 0.024 && Math.abs(x) > 0.011 && y > e.y + 0.015 && y < e.y + 0.023 - dx * 0.12) c = COLORS.brow
    }
    const mouthY = eyeY - 0.075
    if (back < 0.02 && Math.abs(x) < 0.022 && Math.abs(y - mouthY) < 0.006) c = COLORS.lips
    if (bone === 'Neck' && y < neckY + 0.035) {
      const front = z > J('Neck').z + 0.02
      const vNeck = front && Math.abs(x) < 0.05 - (neckY + 0.035 - y) * 0.2
      c = vNeck ? COLORS.skin : COLORS.shirtCollar
    }
  } else if (/Spine|Shoulder|Arm/.test(bone)) {
    c = COLORS.shirt
    if (bone === 'Spine2' && y > neckY - 0.02) c = COLORS.shirtCollar
    if (bone === 'LeftForeArm' || bone === 'RightForeArm') {
      const hand = x > 0 ? J('LeftHand') : J('RightHand')
      const elbow = x > 0 ? J('LeftForeArm') : J('RightForeArm')
      const along = new THREE.Vector3(x, y, z).sub(elbow).dot(hand.clone().sub(elbow).normalize())
      if (along > hand.distanceTo(elbow) - 0.012) c = COLORS.skin
    }
    if (y < beltY + 0.005 && /Spine$/.test(bone)) c = y < beltY - 0.03 ? COLORS.pants : COLORS.belt
  } else if (bone === 'Hips') {
    c = y > beltY ? COLORS.shirt : y > beltY - 0.035 ? COLORS.belt : COLORS.pants
    if (c === COLORS.belt && z > 0.05 && Math.abs(x) < 0.022) c = COLORS.buckle
  } else if (/UpLeg|Leg$/.test(bone)) {
    c = COLORS.pants
    if (y < footY + 0.035) c = COLORS.sock
    if (y < footY + 0.012) c = COLORS.shoes
  } else if (/Foot|Toe/.test(bone)) {
    c = y > footY + 0.035 ? COLORS.pants : COLORS.shoes
  }
  colors.set(c, v * 3)
  clothKind[v] =
    c === COLORS.shirt || c === COLORS.shirtCollar ? 1 : c === COLORS.pants || c === COLORS.belt || c === COLORS.buckle ? 2 : c === COLORS.shoes || c === COLORS.sock ? 3 : 0
}

// Smooth away anatomy under the clothes and puff the fabric out so it reads as a shirt, slacks and shoes.
{
  const count = BP.length / 3
  const weld = new Int32Array(count)
  const keyMap = new Map()
  for (let v = 0; v < count; v++) {
    const key = `${Math.round(BP[v * 3] * 1e5)},${Math.round(BP[v * 3 + 1] * 1e5)},${Math.round(BP[v * 3 + 2] * 1e5)}`
    if (!keyMap.has(key)) keyMap.set(key, keyMap.size)
    weld[v] = keyMap.get(key)
  }
  const groups = keyMap.size
  const gp = new Float64Array(groups * 3)
  const gKind = new Int8Array(groups)
  for (let v = 0; v < count; v++) {
    const g = weld[v]
    gp[g * 3] = BP[v * 3]
    gp[g * 3 + 1] = BP[v * 3 + 1]
    gp[g * 3 + 2] = BP[v * 3 + 2]
    gKind[g] = Math.max(gKind[g], clothKind[v])
  }
  const idx = body.getIndices().getArray()
  const neighbors = Array.from({ length: groups }, () => new Set())
  for (let i = 0; i < idx.length; i += 3) {
    const a = weld[idx[i]]
    const b = weld[idx[i + 1]]
    const c = weld[idx[i + 2]]
    neighbors[a].add(b).add(c)
    neighbors[b].add(a).add(c)
    neighbors[c].add(a).add(b)
  }
  const computeNormals = () => {
    const n = new Float64Array(groups * 3)
    for (let i = 0; i < idx.length; i += 3) {
      const a = weld[idx[i]]
      const b = weld[idx[i + 1]]
      const c = weld[idx[i + 2]]
      const ax = gp[a * 3]
      const ay = gp[a * 3 + 1]
      const az = gp[a * 3 + 2]
      const ux = gp[b * 3] - ax
      const uy = gp[b * 3 + 1] - ay
      const uz = gp[b * 3 + 2] - az
      const vx = gp[c * 3] - ax
      const vy = gp[c * 3 + 1] - ay
      const vz = gp[c * 3 + 2] - az
      const nx = uy * vz - uz * vy
      const ny = uz * vx - ux * vz
      const nz = ux * vy - uy * vx
      for (const g of [a, b, c]) {
        n[g * 3] += nx
        n[g * 3 + 1] += ny
        n[g * 3 + 2] += nz
      }
    }
    for (let g = 0; g < groups; g++) {
      const l = Math.hypot(n[g * 3], n[g * 3 + 1], n[g * 3 + 2]) || 1
      n[g * 3] /= l
      n[g * 3 + 1] /= l
      n[g * 3 + 2] /= l
    }
    return n
  }
  const ITER = { 1: 6, 2: 5, 3: 10 }
  for (let it = 0; it < 10; it++) {
    const next = gp.slice()
    for (let g = 0; g < groups; g++) {
      const k = gKind[g]
      if (!k || it >= ITER[k]) continue
      let sx = 0
      let sy = 0
      let sz = 0
      for (const nb of neighbors[g]) {
        sx += gp[nb * 3]
        sy += gp[nb * 3 + 1]
        sz += gp[nb * 3 + 2]
      }
      const m = neighbors[g].size || 1
      next[g * 3] += (sx / m - gp[g * 3]) * 0.55
      next[g * 3 + 1] += (sy / m - gp[g * 3 + 1]) * 0.55
      next[g * 3 + 2] += (sz / m - gp[g * 3 + 2]) * 0.55
    }
    gp.set(next)
  }
  const PUFF = { 1: 0.009, 2: 0.013, 3: 0.008 }
  const n0 = computeNormals()
  for (let g = 0; g < groups; g++) {
    const k = gKind[g]
    if (!k) continue
    gp[g * 3] += n0[g * 3] * PUFF[k]
    gp[g * 3 + 1] += n0[g * 3 + 1] * PUFF[k]
    gp[g * 3 + 2] += n0[g * 3 + 2] * PUFF[k]
  }
  const gc = new Float64Array(groups * 3)
  for (let v = 0; v < count; v++) {
    gc[weld[v] * 3] = colors[v * 3]
    gc[weld[v] * 3 + 1] = colors[v * 3 + 1]
    gc[weld[v] * 3 + 2] = colors[v * 3 + 2]
  }
  for (let it = 0; it < 2; it++) {
    const next = gc.slice()
    for (let g = 0; g < groups; g++) {
      const m = neighbors[g].size
      if (!m) continue
      let r = 0
      let gg = 0
      let b = 0
      for (const nb of neighbors[g]) {
        r += gc[nb * 3]
        gg += gc[nb * 3 + 1]
        b += gc[nb * 3 + 2]
      }
      next[g * 3] = gc[g * 3] * 0.5 + (r / m) * 0.5
      next[g * 3 + 1] = gc[g * 3 + 1] * 0.5 + (gg / m) * 0.5
      next[g * 3 + 2] = gc[g * 3 + 2] * 0.5 + (b / m) * 0.5
    }
    gc.set(next)
  }
  for (let v = 0; v < count; v++) {
    colors[v * 3] = gc[weld[v] * 3]
    colors[v * 3 + 1] = gc[weld[v] * 3 + 1]
    colors[v * 3 + 2] = gc[weld[v] * 3 + 2]
  }
  const n1 = computeNormals()
  const NB = body.getAttribute('NORMAL').getArray().slice()
  for (let v = 0; v < count; v++) {
    const g = weld[v]
    BP[v * 3] = gp[g * 3]
    BP[v * 3 + 1] = gp[g * 3 + 1]
    BP[v * 3 + 2] = gp[g * 3 + 2]
    NB[v * 3] = n1[g * 3]
    NB[v * 3 + 1] = n1[g * 3 + 1]
    NB[v * 3 + 2] = n1[g * 3 + 2]
  }
  body.getAttribute('POSITION').setArray(BP)
  body.getAttribute('NORMAL').setArray(NB)
}

body.setAttribute('COLOR_0', doc.createAccessor('bodyColor').setType('VEC3').setArray(colors).setBuffer(buffer))
body.getMaterial().setName('MichaelOutfit').setBaseColorFactor([1, 1, 1, 1]).setRoughnessFactor(0.78).setMetallicFactor(0)
for (const node of root.listNodes()) {
  if (node.getName() === 'Eyes') node.getMesh().listPrimitives()[0].getMaterial().setBaseColorFactor([0.09, 0.07, 0.06, 1]).setRoughnessFactor(0.12)
}

// ---------- 4. Retarget Xbot's natural idle / walk / run onto this skeleton ----------
const srcRoot = src.getRoot()
const srcNodes = new Map(srcRoot.listNodes().map((n) => [n.getName(), n]))
const srcRest = new Map()
function srcWorld(node) {
  if (srcRest.has(node)) return srcRest.get(node)
  const t = new THREE.Vector3(...node.getTranslation()).multiplyScalar(0.01)
  const parent = node.getParentNode()
  const w = parent && parent.getName().startsWith('mixamorig') ? srcWorld(parent).clone().add(t) : t
  srcRest.set(node, w)
  return w
}

const PRIMARY_CHILD = { Hips: 'Spine', Spine2: 'Neck', LeftHand: 'LeftHandMiddle1', RightHand: 'RightHandMiddle1', Neck: 'Head' }
function depth(n) {
  let d = 0
  let p = n.getParentNode()
  while (p && byName.has(p.getName())) {
    d++
    p = p.getParentNode()
  }
  return d
}
const orderedJoints = [...joints].sort((a, b) => depth(a) - depth(b))
const parentOf = (n) => {
  const p = n.getParentNode()
  return p && byName.has(p.getName()) ? p : null
}
const childDir = (node, worldFn) => {
  const short = node.getName().replace('mixamorig:', '')
  const kids = node.listChildren().filter((c) => c.getName().startsWith('mixamorig'))
  if (!kids.length) return null
  const preferred = PRIMARY_CHILD[short] && kids.find((k) => k.getName() === 'mixamorig:' + PRIMARY_CHILD[short])
  const kid = preferred ?? kids[0]
  return worldFn(kid).clone().sub(worldFn(node)).normalize()
}

const correction = new Map()
for (const j of orderedJoints) {
  const s = srcNodes.get(j.getName())
  const dt = childDir(j, worldOf)
  const ds = s ? childDir(s, srcWorld) : null
  const limb = /^mixamorig:(Left|Right)(Arm|ForeArm|UpLeg|Leg)$/.test(j.getName())
  if (limb && dt && ds) correction.set(j, new THREE.Quaternion().setFromUnitVectors(dt, ds))
  else correction.set(j, parentOf(j) ? correction.get(parentOf(j)).clone() : new THREE.Quaternion())
}

function sampler(channel) {
  const s = channel.getSampler()
  const times = s.getInput().getArray()
  const values = s.getOutput().getArray()
  const size = channel.getTargetPath() === 'rotation' ? 4 : 3
  return (t) => {
    let i = 0
    while (i < times.length - 2 && times[i + 1] < t) i++
    const t0 = times[i]
    const i1 = Math.min(i + 1, times.length - 1)
    const t1 = times[i1]
    const a = Math.max(0, Math.min(1, t1 > t0 ? (t - t0) / (t1 - t0) : 0))
    if (size === 4) return new THREE.Quaternion().fromArray(values, i * 4).slerp(new THREE.Quaternion().fromArray(values, i1 * 4), a)
    return new THREE.Vector3().fromArray(values, i * 3).lerp(new THREE.Vector3().fromArray(values, i1 * 3), a)
  }
}

const hipScale = hipsY / srcWorld(srcNodes.get('mixamorig:Hips')).y
const out = {}

function writeClip(name, times, localFrames, hipsFrames) {
  const anim = doc.createAnimation(name)
  const input = doc.createAccessor(name + '_t').setType('SCALAR').setArray(new Float32Array(times)).setBuffer(buffer)
  for (const j of joints) {
    const arr = new Float32Array(times.length * 4)
    const finger = /Thumb|Index|Middle|Ring|Pinky/.test(j.getName())
    localFrames.forEach((frame, f) => {
      if (finger) {
        const curl = /Thumb/.test(j.getName()) ? 0.15 : /1$/.test(j.getName()) ? 0.25 : 0.35
        const axis = new THREE.Vector3(0, 0, j.getName().includes('Left') ? 1 : -1)
        new THREE.Quaternion().setFromAxisAngle(axis, -curl).toArray(arr, f * 4)
      } else frame.get(j).toArray(arr, f * 4)
    })
    const s = doc
      .createAnimationSampler()
      .setInput(input)
      .setOutput(doc.createAccessor().setType('VEC4').setArray(arr).setBuffer(buffer))
      .setInterpolation('LINEAR')
    anim.addSampler(s).addChannel(doc.createAnimationChannel().setTargetNode(j).setTargetPath('rotation').setSampler(s))
  }
  const hips = byName.get('mixamorig:Hips')
  const harr = new Float32Array(times.length * 3)
  hipsFrames.forEach((v, f) => v.toArray(harr, f * 3))
  const hs = doc
    .createAnimationSampler()
    .setInput(input)
    .setOutput(doc.createAccessor().setType('VEC3').setArray(harr).setBuffer(buffer))
    .setInterpolation('LINEAR')
  anim.addSampler(hs).addChannel(doc.createAnimationChannel().setTargetNode(hips).setTargetPath('translation').setSampler(hs))
}

function footWorld(frame, hipsPos, side) {
  const chain = ['Hips', `${side}UpLeg`, `${side}Leg`, `${side}Foot`]
  let q = new THREE.Quaternion()
  let p = hipsPos.clone()
  for (let i = 1; i < chain.length; i++) {
    const parent = byName.get('mixamorig:' + chain[i - 1])
    const node = byName.get('mixamorig:' + chain[i])
    q = q.clone().multiply(frame.get(parent))
    p = p.clone().add(new THREE.Vector3(...node.getTranslation()).applyQuaternion(q))
  }
  return p
}

const restHips = new THREE.Vector3(...byName.get('mixamorig:Hips').getTranslation())

for (const [srcName, dstName] of [
  ['idle', 'Idle'],
  ['walk', 'Walk'],
  ['run', 'Run'],
]) {
  const anim = srcRoot.listAnimations().find((a) => a.getName() === srcName)
  const rot = new Map()
  let hipsT = null
  let times = null
  for (const ch of anim.listChannels()) {
    const n = ch.getTargetNode().getName()
    if (ch.getTargetPath() === 'rotation') rot.set(n, sampler(ch))
    if (ch.getTargetPath() === 'translation' && n === 'mixamorig:Hips') hipsT = sampler(ch)
    if (n === 'mixamorig:Hips' && ch.getTargetPath() === 'rotation') times = [...ch.getSampler().getInput().getArray()]
  }
  const hipsRest = srcWorld(srcNodes.get('mixamorig:Hips'))
  const rawHips = times.map((t) => (hipsT ? hipsT(t).multiplyScalar(0.01) : hipsRest.clone()))
  const drift = rawHips[rawHips.length - 1].z - rawHips[0].z
  const frames = []
  const hipsFrames = []
  times.forEach((t, f) => {
    const srcWorldRot = new Map()
    const worldT = new Map()
    const local = new Map()
    for (const j of orderedJoints) {
      const name = j.getName()
      const sNode = srcNodes.get(name)
      const parent = parentOf(j)
      let ws
      if (sNode) {
        const sp = sNode.getParentNode()
        const parentWs = sp && srcWorldRot.has(sp.getName()) ? srcWorldRot.get(sp.getName()) : new THREE.Quaternion()
        const q = rot.has(name) ? rot.get(name)(t) : new THREE.Quaternion()
        ws = parentWs.clone().multiply(q)
      } else {
        ws = parent ? srcWorldRot.get(parent.getName()).clone() : new THREE.Quaternion()
      }
      srcWorldRot.set(name, ws)
      const wt = ws.clone().multiply(correction.get(j))
      worldT.set(j, wt)
      const pw = parent ? worldT.get(parent) : new THREE.Quaternion()
      local.set(j, pw.clone().invert().multiply(wt))
    }
    frames.push(local)
    const h = rawHips[f].clone()
    h.z -= (drift * f) / Math.max(1, times.length - 1)
    hipsFrames.push(
      new THREE.Vector3(
        restHips.x + (h.x - hipsRest.x) * hipScale,
        restHips.y + (h.y - hipsRest.y) * hipScale,
        restHips.z + (h.z - rawHips[0].z) * hipScale,
      ),
    )
  })
  let speedSum = 0
  let speedN = 0
  const duration = times[times.length - 1] - times[0]
  for (const side of ['Left', 'Right']) {
    const feet = frames.map((fr, f) => footWorld(fr, hipsFrames[f], side))
    const minY = Math.min(...feet.map((p) => p.y))
    for (let f = 1; f < feet.length; f++) {
      if (feet[f].y < minY + 0.025 && feet[f - 1].y < minY + 0.025) {
        speedSum += -(feet[f].z - feet[f - 1].z) / (times[f] - times[f - 1])
        speedN++
      }
    }
  }
  out[dstName] = { duration, stanceSpeed: speedN ? speedSum / speedN : 0 }
  writeClip(dstName, times, frames, hipsFrames)
}

// ---------- 5. Hand-authored poses for the car sequence ----------
const restDir = new Map()
for (const j of joints) restDir.set(j.getName().replace('mixamorig:', ''), childDir(j, worldOf))

function pose(spec) {
  const world = new Map()
  const local = new Map()
  for (const j of orderedJoints) {
    const short = j.getName().replace('mixamorig:', '')
    const parent = parentOf(j)
    const pw = parent ? world.get(parent) : new THREE.Quaternion()
    let w
    if (spec[short] && restDir.get(short)) {
      w = new THREE.Quaternion().setFromUnitVectors(restDir.get(short), new THREE.Vector3(...spec[short]).normalize())
    } else {
      w = pw.clone()
    }
    world.set(j, w)
    local.set(j, pw.clone().invert().multiply(w))
  }
  return local
}

const keep = (...names) => Object.fromEntries(names.filter((n) => restDir.get(n)).map((n) => [n, restDir.get(n).toArray()]))

const SIT = pose({
  ...keep('LeftShoulder', 'RightShoulder', 'Neck', 'Head'),
  Hips: [0, 0.97, -0.22],
  Spine: [0, 0.97, -0.24],
  Spine1: [0, 0.98, -0.18],
  Spine2: [0, 0.99, -0.1],
  LeftUpLeg: [0.14, -0.08, 0.99],
  RightUpLeg: [-0.14, -0.08, 0.99],
  LeftLeg: [0.05, -0.86, 0.5],
  RightLeg: [-0.05, -0.86, 0.5],
  LeftFoot: [0.05, -0.45, 0.89],
  RightFoot: [-0.05, -0.45, 0.89],
  LeftArm: [0.28, -0.55, 0.78],
  RightArm: [-0.28, -0.55, 0.78],
  LeftForeArm: [-0.2, 0.32, 0.93],
  RightForeArm: [0.2, 0.32, 0.93],
  LeftHand: [-0.25, 0.15, 0.95],
  RightHand: [0.25, 0.15, 0.95],
})

const REACH = pose({
  ...keep('LeftShoulder', 'RightShoulder', 'Neck', 'Head', 'Hips'),
  Spine: [0, 0.99, 0.12],
  Spine1: [0, 0.99, 0.1],
  Spine2: [0, 0.99, 0.05],
  LeftUpLeg: [0.05, -1, 0.02],
  RightUpLeg: [-0.05, -1, 0.02],
  LeftLeg: [0.02, -1, -0.03],
  RightLeg: [-0.02, -1, -0.03],
  LeftFoot: [0.05, -0.5, 0.86],
  RightFoot: [-0.05, -0.5, 0.86],
  LeftArm: [0.18, -0.98, 0.05],
  LeftForeArm: [0.08, -0.98, 0.15],
  RightArm: [-0.2, -0.32, 0.93],
  RightForeArm: [-0.05, -0.12, 0.99],
  RightHand: [-0.02, -0.25, 0.97],
})

writeClip('Sit', [0, 1], [SIT, SIT], [restHips.clone(), restHips.clone()])
writeClip('Reach', [0, 1], [REACH, REACH], [restHips.clone(), restHips.clone()])

await io.write('/vercel/share/v0-project/public/models/character.glb', doc)
console.log(JSON.stringify({ out, hipsY, eyeY }, null, 1))
