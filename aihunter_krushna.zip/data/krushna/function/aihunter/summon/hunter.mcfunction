function krushna:aihunter/summon/attacker

effect give @e[type=minecraft:vindicator,tag=aihunter] minecraft:invisibility 999999 0 true

function krushna:aihunter/summon/stand

# Spawn nametag on armor_stand as passenger
execute as @e[type=minecraft:armor_stand,tag=aihunter] at @s unless entity @e[type=minecraft:text_display,tag=aihunter_name,distance=..4] run function krushna:aihunter/summon/nametag

execute store result score existing aihunter_dummy if entity @e[type=minecraft:vindicator,tag=aihunter]

execute unless score hunters aihunter_dummy matches 1..50 run scoreboard players set hunters aihunter_dummy 1


execute if score hunters aihunter_dummy > existing aihunter_dummy run function krushna:aihunter/summon/hunter