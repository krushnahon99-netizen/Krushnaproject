function krushna:aihunter/find/vector/2d

execute store result entity @s Motion[0] double 0.00013 run scoreboard players get @s aihunter_vx

execute store result entity @s Motion[2] double 0.00013 run scoreboard players get @s aihunter_vz

execute positioned ~-0.3 ~-1 ~-0.3 if entity @p[dx=0.6,dy=-257,dz=0.6,gamemode=!creative,gamemode=!spectator] positioned ~0.3 ~1 ~0.3 store result entity @s Motion[1] double 0.01 run scoreboard players set motion aihunter_dummy -20

execute positioned ~-0.3 ~2 ~-0.3 if entity @p[dx=0.6,dy=257,dz=0.6,gamemode=!creative,gamemode=!spectator,nbt={OnGround:1b}] positioned ~0.1 ~-2 ~0.1 store result entity @s Motion[1] double 0.01 run scoreboard players set motion aihunter_dummy -20

execute positioned ~-0.3 ~2 ~-0.3 if entity @p[dx=0.6,dy=257,dz=0.6,gamemode=!creative,gamemode=!spectator,nbt={OnGround:0b}] positioned ~0.1 ~-2 ~0.1 store result entity @s Motion[1] double 0.01 run scoreboard players set motion aihunter_dummy 23


execute unless predicate krushna:aihunter/dimension/nether unless block ~ ~-1 ~ minecraft:lava run function krushna:aihunter/action/build/water

#function krushna:aihunter/action/build/tower

function krushna:aihunter/act/inliquid