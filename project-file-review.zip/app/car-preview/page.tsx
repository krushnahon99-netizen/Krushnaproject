'use client'

import { Suspense, useMemo } from 'react'
import { Canvas } from '@react-three/fiber'
import { Environment, Lightformer } from '@react-three/drei'
import * as THREE from 'three'
import { useSearchParams } from 'next/navigation'
import { CarModel } from '@/components/game/car-model'
import { game } from '@/lib/game/state'
import type { CarVariant } from '@/lib/game/state'

function Inner() {
  const params = useSearchParams()
  const variant = (params.get('variant') ?? 'sports') as CarVariant
  const angle = Number(params.get('angle') ?? 0.7)
  const r = Number(params.get('r') ?? 7)
  const h = Number(params.get('h') ?? 1.6)
  const fov = Number(params.get('fov') ?? 35)
  const car = useMemo(() => {
    const source = game.cars.find((c) => c.variant === variant) ?? game.cars[0]
    return { ...source, x: 0, z: 0, heading: 0, speed: 0, roll: 0, pitch: 0, steer: Number(params.get('steer') ?? 0.4), braking: params.get('brake') === '1' }
  }, [variant, params])
  return (
    <Canvas
      shadows
      gl={{ toneMapping: THREE.AgXToneMapping }}
      camera={{ position: [Math.sin(angle) * r, h, Math.cos(angle) * r], fov }}
      onCreated={({ camera }) => camera.lookAt(0, 0.6, 0)}
    >
      <color attach="background" args={['#9fb4c8']} />
      <hemisphereLight args={['#cfe0f5', '#6e604c', 0.35]} />
      <directionalLight position={[8, 14, 6]} intensity={3} castShadow shadow-mapSize={[2048, 2048]} />
      <Environment frames={1} resolution={128}>
        <color attach="background" args={['#9fb9d1']} />
        <Lightformer form="rect" intensity={2.2} color="#dcebff" scale={[60, 60, 1]} position={[0, 30, 0]} rotation-x={Math.PI / 2} />
        <Lightformer form="rect" intensity={3} color="#fff1de" scale={[20, 12, 1]} position={[30, 20, -20]} target={[0, 0, 0]} />
        <Lightformer form="rect" intensity={0.8} color="#c9d6e2" scale={[40, 10, 1]} position={[-30, 6, 10]} target={[0, 0, 0]} />
        <Lightformer form="rect" intensity={0.5} color="#8a7c66" scale={[60, 60, 1]} position={[0, -10, 0]} rotation-x={-Math.PI / 2} />
      </Environment>
      <mesh rotation-x={-Math.PI / 2} receiveShadow>
        <planeGeometry args={[60, 60]} />
        <meshStandardMaterial color="#3a3c40" roughness={0.9} />
      </mesh>
      <Suspense fallback={null}>
        <CarModel car={car} />
      </Suspense>
    </Canvas>
  )
}

export default function Page() {
  return (
    <main className="h-dvh w-full">
      <Suspense fallback={null}>
        <Inner />
      </Suspense>
    </main>
  )
}
