playsound minecraft:ui.button.click master @s ~ ~ ~ .1
tellraw @s {"text":"----------------------------------------","color":"yellow","bold":true}


tellraw @s {"text":"Misode's Predicate Generator is used:","color":"gold"}


tellraw @s {"text":"[URL] Misode's Twitter (@misode_)","color":"yellow","hoverEvent":{"action":"show_text","contents":[{"text":"URL To: twitter.com","color":"gold"}]},"clickEvent":{"action":"open_url","value":"https://twitter.com/misode_"}}


tellraw @s {"text":"[URL] Misode's Youtube","color":"yellow","hoverEvent":{"action":"show_text","contents":[{"text":"URL To: youtube.com","color":"gold"}]},"clickEvent":{"action":"open_url","value":"https://www.youtube.com/c/misode"}}


tellraw @s {"text":"[URL] Misode's Data Pack Generators","color":"yellow","hoverEvent":{"action":"show_text","contents":[{"text":"URL To: github.io","color":"gold"}]},"clickEvent":{"action":"open_url","value":"https://misode.github.io"}}



tellraw @s {"text":"TheDestruc7i0n's Advancements Generator is used:","color":"gold"}


tellraw @s {"text":"[URL] TheDestruc7i0n's Twitter (@thedestruc7i0n)","color":"yellow","hoverEvent":{"action":"show_text","contents":[{"text":"URL To: twitter.com","color":"gold"}]},"clickEvent":{"action":"open_url","value":"https://twitter.com/thedestruc7i0n"}}


tellraw @s {"text":"[URL] TheDestruc7i0n's Youtube","color":"yellow","hoverEvent":{"action":"show_text","contents":[{"text":"URL To: youtube.com","color":"gold"}]},"clickEvent":{"action":"open_url","value":"https://www.youtube.com/c/TheDestruc7i0n"}}


tellraw @s {"text":"[URL] TheDestruc7i0n's Website","color":"yellow","hoverEvent":{"action":"show_text","contents":[{"text":"URL To: TheDestruc7i0n's website","color":"gold"}]},"clickEvent":{"action":"open_url","value":"https://thedestruc7i0n.ca"}}

tellraw @s {"text":"MCStacker's Command Generator is used:","color":"gold"}


tellraw @s {"text":"[URL] McStacker's Twitter (@PyroStunts)","color":"yellow","hoverEvent":{"action":"show_text","contents":[{"text":"URL To: twitter.com","color":"gold"}]},"clickEvent":{"action":"open_url","value":"https://twitter.com/PyroStunts"}}


tellraw @s {"text":"[URL] MCStacker's Discord","color":"yellow","hoverEvent":{"action":"show_text","contents":[{"text":"URL To: discord.com","color":"gold"}]},"clickEvent":{"action":"open_url","value":"https://discord.com/invite/WCb6GNf"}}


tellraw @s {"text":"[URL] MCStacker's Command Generator","color":"yellow","hoverEvent":{"action":"show_text","contents":[{"text":"URL To: mcstacker.net","color":"gold"}]},"clickEvent":{"action":"open_url","value":"mcstacker.net"}}


tellraw @s {"text":"About me (Kyleong):","color":"gold"}


#tellraw @s {"text":"[URL] My Twitter (@krushna123)","color":"yellow","hoverEvent":{"action":"show_text","contents":[{"text":"URL To: twitter.com","color":"gold"}]},"clickEvent":{"action":"open_url","value":"https://twitter.com/krushna123"}}


tellraw @s {"text":"[URL] My Youtube","color":"yellow","hoverEvent":{"action":"show_text","contents":[{"text":"URL To: youtube.com","color":"gold"}]},"clickEvent":{"action":"open_url","value":"https://www.youtube.com/channel/UCGclCRGdWUjJdVcHLZfdaOg"}}


tellraw @s {"text":"[URL] My Planet Minecraft, where I post my creations","color":"yellow","hoverEvent":{"action":"show_text","contents":[{"text":"URL To: planetminecraft.com","color":"gold"}]},"clickEvent":{"action":"open_url","value":"https://www.planetminecraft.com/member/krushna/"}}


tellraw @s {"text":" "}
tellraw @s {"text":"<Start Menu>","color":"aqua","hoverEvent":{"action":"show_text","contents":[{"text":"Go back to the main menu.","color":"aqua"}]},"underlined":true,"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/menu"}}


tellraw @s {"text":"----------------------------------------","color":"yellow","bold":true}