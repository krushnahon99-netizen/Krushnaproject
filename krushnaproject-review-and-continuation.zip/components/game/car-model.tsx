'use client'

import { useEffect, useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { useGLTF } from '@react-three/drei'
import * as THREE from 'three'
import type { Car } from '@/lib/game/state'
import { CAR_SCALE, CAR_SPECS, type CarModelName } from '@/lib/game/cars'
import { groundHeight } from '@/lib/game/update'
import { getBlobShadowTexture } from '@/lib/game/textures'
import { QUALITY } from '@/lib/game/quality'
import { SHARED_CAR_MATERIALS, createTaillightMaterial, paintMaterial } from './car-materials'

const WHEELS = ['fl', 'fr', 'rl', 'rr'] as const

const nearUrl = (model: CarModelName) => `/models/cars/${model}-lod0.glb`
const farUrl = (model: CarModelName) => `/models/cars/${model}-lod1.glb`

/** Distances (metres from the camera) where each level of detail takes over. */
const LOD_DISTANCES = QUALITY.mobile ? [0, 22, 70] : [0, 24, 75]

type Rig = {
  root: THREE.LOD
  bodies: THREE.Object3D[]
  wheels: { node: THREE.Object3D; front: boolean }[]
  taillight: THREE.MeshStandardMaterial
}

function cloneLevel(source: THREE.Object3D, rig: Omit<Rig, 'root'>, paint: THREE.Material, shadows: boolean) {
  const level = source.clone(true)
  level.position.set(0, 0, 0)
  level.traverse((object) => {
    const mesh = object as THREE.Mesh
    if (!mesh.isMesh) return
    const name = (mesh.material as THREE.Material).name
    mesh.material = name === 'paint' ? paint : name === 'taillight' ? rig.taillight : (SHARED_CAR_MATERIALS[name] ?? SHARED_CAR_MATERIALS.plastic)
    const transparent = (mesh.material as THREE.Material).transparent
    mesh.castShadow = shadows && !transparent
    mesh.receiveShadow = !transparent
  })
  const prefix = source.name
  const body = level.getObjectByName(`${prefix}_body`)
  if (body) {
    // Body roll and pitch pivot around the car origin, independently of the wheels.
    const pivot = new THREE.Group()
    level.add(pivot)
    pivot.add(body)
    rig.bodies.push(pivot)
  }
  for (const w of WHEELS) {
    const node = level.getObjectByName(`${prefix}_wheel_${w}`)
    if (!node) continue
    node.rotation.order = 'YXZ'
    rig.wheels.push({ node, front: w[0] === 'f' })
  }
  return level
}

function CarBody({ car, model }: { car: Car; model: CarModelName }) {
  const near = useGLTF(nearUrl(model))
  const far = useGLTF(farUrl(model))
  const paint = paintMaterial(car.color, car.variant !== 'taxi')

  const rig = useMemo<Rig>(() => {
    const partial = { bodies: [], wheels: [], taillight: createTaillightMaterial() } as Omit<Rig, 'root'>
    const sources = [near.scene.getObjectByName('lod0'), far.scene.getObjectByName('lod1'), far.scene.getObjectByName('lod2')]
    const root = new THREE.LOD()
    sources.forEach((source, i) => {
      if (!source) return
      const castsShadow = QUALITY.mobile ? i === 0 : i < sources.length - 1
      root.addLevel(cloneLevel(source, partial, paint, castsShadow), LOD_DISTANCES[i], 4)
    })
    return { root, ...partial }
  }, [near, far, paint])

  useEffect(() => () => rig.taillight.dispose(), [rig])

  useFrame(() => {
    for (const body of rig.bodies) {
      body.rotation.z = car.roll
      body.rotation.x = car.pitch
    }
    for (const { node, front } of rig.wheels) {
      node.rotation.x = car.wheelSpin
      node.rotation.y = front ? car.steer * 0.45 : 0
    }
    rig.taillight.emissiveIntensity = car.braking ? 5 : 0.7
  })

  return <primitive object={rig.root} />
}

function TaxiSign({ roof }: { roof: number }) {
  return (
    <group position={[0, roof, -0.2]}>
      <mesh castShadow>
        <boxGeometry args={[0.62, 0.16, 0.26]} />
        <meshStandardMaterial color="#f4ecd2" emissive="#ffcf6a" emissiveIntensity={1.4} roughness={0.35} toneMapped={false} />
      </mesh>
      <mesh position={[0, -0.09, 0]}>
        <boxGeometry args={[0.66, 0.03, 0.3]} />
        <meshStandardMaterial color="#111" roughness={0.6} />
      </mesh>
    </group>
  )
}

export function CarModel({ car }: { car: Car }) {
  const groupRef = useRef<THREE.Group>(null)
  const spec = CAR_SPECS[car.variant]
  const y = useRef(0)
  const shadowTexture = useMemo(() => getBlobShadowTexture(), [])

  useFrame((_, dt) => {
    const group = groupRef.current
    if (!group) return
    y.current += (groundHeight(car.x, car.z) - y.current) * Math.min(1, dt * 12)
    group.position.set(car.x, y.current, car.z)
    group.rotation.y = car.heading
  })

  return (
    <group ref={groupRef}>
      <group scale={CAR_SCALE}>
        <CarBody car={car} model={spec.model} />
        {car.variant === 'taxi' && <TaxiSign roof={spec.roof} />}
        <mesh rotation-x={-Math.PI / 2} position={[0, 0.03 / CAR_SCALE, 0]} renderOrder={-1}>
          <planeGeometry args={[spec.width + 0.9, spec.length + 1]} />
          <meshBasicMaterial map={shadowTexture} color="#000000" transparent opacity={0.85} depthWrite={false} />
        </mesh>
      </group>
    </group>
  )
}

for (const model of ['sports', 'suv', 'sedan'] as const) {
  useGLTF.preload(nearUrl(model))
  useGLTF.preload(farUrl(model))
}
