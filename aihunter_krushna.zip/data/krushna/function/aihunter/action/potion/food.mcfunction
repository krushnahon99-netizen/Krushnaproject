
scoreboard players add @s aihunter_busy 1
scoreboard players set @s aihunter_weapon 0

data merge entity @s {HandItems:[{id:"minecraft:bread",count:1},{}]}

data merge entity @e[limit=1,sort=nearest,type=minecraft:armor_stand,tag=aihunter] {HandItems:[{id:"minecraft:bread",count:1},{}]}

playsound minecraft:entity.generic.eat master @a ~ ~ ~ .8 .8

effect give @s minecraft:luck 3 42 true

effect give @s minecraft:weakness 3 10 true

effect give @s minecraft:regeneration 6 1 true

execute if score @s aihunter_hp matches 161.. if predicate krushna:aihunter/chance/30 run scoreboard players set @s aihunter_intent 1