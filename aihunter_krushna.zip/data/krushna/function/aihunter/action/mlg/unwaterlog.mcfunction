##block ~ ~ ~ is waterlogable
#as at @e[type=minecraft:area_effect_cloud,tag=aihunter_waterlog]

function krushna:aihunter/action/mlg/unwaterlog/glass_panes

function krushna:aihunter/action/mlg/unwaterlog/chests

function krushna:aihunter/action/mlg/unwaterlog/slabs_116

function krushna:aihunter/action/mlg/unwaterlog/slabs_117

function krushna:aihunter/action/mlg/unwaterlog/slabs_119

function krushna:aihunter/action/mlg/unwaterlog/slabs_120


function krushna:aihunter/action/mlg/unwaterlog/stairs_116

function krushna:aihunter/action/mlg/unwaterlog/stairs_117

function krushna:aihunter/action/mlg/unwaterlog/stairs_119

function krushna:aihunter/action/mlg/unwaterlog/stairs_120


function krushna:aihunter/action/mlg/unwaterlog/fences_116

function krushna:aihunter/action/mlg/unwaterlog/fences_119

function krushna:aihunter/action/mlg/unwaterlog/fences_120


function krushna:aihunter/action/mlg/unwaterlog/trapdoors_116

function krushna:aihunter/action/mlg/unwaterlog/trapdoors_119

function krushna:aihunter/action/mlg/unwaterlog/trapdoors_120


execute if block ~ ~ ~ #minecraft:signs[waterlogged=true] run function krushna:aihunter/action/mlg/unwaterlog/signs


function krushna:aihunter/action/mlg/unwaterlog/walls_116

function krushna:aihunter/action/mlg/unwaterlog/walls_117

function krushna:aihunter/action/mlg/unwaterlog/walls_119


function krushna:aihunter/action/mlg/unwaterlog/others_117

function krushna:aihunter/action/mlg/unwaterlog/others_119

function krushna:aihunter/action/mlg/unwaterlog/others_120


#ladder

execute if block ~ ~ ~ minecraft:ladder[waterlogged=true,facing=east] run setblock ~ ~ ~ minecraft:ladder[waterlogged=false,facing=east] replace

execute if block ~ ~ ~ minecraft:ladder[waterlogged=true,facing=north] run setblock ~ ~ ~ minecraft:ladder[waterlogged=false,facing=north] replace

execute if block ~ ~ ~ minecraft:ladder[waterlogged=true,facing=south] run setblock ~ ~ ~ minecraft:ladder[waterlogged=false,facing=south] replace

execute if block ~ ~ ~ minecraft:ladder[waterlogged=true,facing=west] run setblock ~ ~ ~ minecraft:ladder[waterlogged=false,facing=west] replace


#chain





#campfire

execute if block ~ ~ ~ minecraft:campfire[waterlogged=true,facing=east] run setblock ~ ~ ~ minecraft:campfire[waterlogged=false,lit=false,facing=east] replace

execute if block ~ ~ ~ minecraft:campfire[waterlogged=true,facing=north] run setblock ~ ~ ~ minecraft:campfire[waterlogged=false,lit=false,facing=north] replace

execute if block ~ ~ ~ minecraft:campfire[waterlogged=true,facing=south] run setblock ~ ~ ~ minecraft:campfire[waterlogged=false,lit=false,facing=south] replace

execute if block ~ ~ ~ minecraft:campfire[waterlogged=true,facing=west] run setblock ~ ~ ~ minecraft:campfire[waterlogged=false,lit=false,facing=west] replace


#others

execute if block ~ ~ ~ minecraft:iron_bars[waterlogged=true] run setblock ~ ~ ~ minecraft:iron_bars[waterlogged=false] replace

execute if block ~ ~ ~ minecraft:conduit[waterlogged=true] run setblock ~ ~ ~ minecraft:conduit[waterlogged=false] replace


#sound

playsound minecraft:item.bucket.fill master @a ~ ~ ~


#debug reporting

execute if score debug aihunter_dummy matches 1 run say unwaterloged

kill @s
function krushna:aihunter/action/mlg/unwaterlog/slabs_121

function krushna:aihunter/action/mlg/unwaterlog/stairs_121

function krushna:aihunter/action/mlg/unwaterlog/fences_121

function krushna:aihunter/action/mlg/unwaterlog/trapdoors_121

function krushna:aihunter/action/mlg/unwaterlog/walls_121

function krushna:aihunter/action/mlg/unwaterlog/signs_121

function krushna:aihunter/action/mlg/unwaterlog/others_121
