# Always set version to 121 - we are on 1.21.11
scoreboard players set version aihunter_dummy 121
