'use client'

import { Suspense, useLayoutEffect, useRef, useState } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Environment, Lightformer, PerformanceMonitor, Sky } from '@react-three/drei'
import * as THREE from 'three'
import {
  Bloom,
  BrightnessContrast,
  EffectComposer,
  HueSaturation,
  N8AO,
  SMAA,
  ToneMapping,
  Vignette,
} from '@react-three/postprocessing'
import { ToneMappingMode } from 'postprocessing'
import { City } from './city'
import { Palms } from './palms'
import { CarModel } from './car-model'
import { PlayerModel } from './player-model'
import { Pickups } from './pickups'
import { SunDisc } from './sun-disc'
import { CAMERA_PITCH_MAX, CAMERA_PITCH_MIN, CameraRig, GameLoop, SUN_POSITION, SunLight } from './camera-rig'
import { game, input } from '@/lib/game/state'
import { QUALITY } from '@/lib/game/quality'
import { Clouds } from './clouds'
import { graphicsStatus } from '@/lib/game/diagnostics'

const SKY = { turbidity: 1.2, rayleigh: 2.4, mieCoefficient: 0.0018, mieDirectionalG: 0.82 }

function FrameTracker() {
  useFrame(() => graphicsStatus.frame())
  return null
}

function MobileToneMapping() {
  const gl = useThree((state) => state.gl)
  useLayoutEffect(() => {
    gl.toneMapping = THREE.ACESFilmicToneMapping
    gl.toneMappingExposure = 1.15
    return () => {
      gl.toneMapping = THREE.NoToneMapping
    }
  }, [gl])
  return null
}

const deviceDpr = () => window.devicePixelRatio || 1
const initialDpr = () => Math.min(QUALITY.maxDpr, deviceDpr())
const floorDpr = () => Math.min(QUALITY.minDpr, deviceDpr())

function GroundFallback() {
  return (
    <mesh rotation-x={-Math.PI / 2} position-y={-0.01}>
      <planeGeometry args={[4000, 4000]} />
      <meshStandardMaterial color="#55585e" roughness={0.95} />
    </mesh>
  )
}

function CityEnvironment() {
  return (
    <Environment frames={1} resolution={128} environmentIntensity={0.6}>
      <color attach="background" args={['#7fa3c9']} />
      <Lightformer form="rect" intensity={2} color="#cfe2ff" scale={[60, 60, 1]} position={[0, 30, 0]} rotation-x={Math.PI / 2} />
      <Lightformer form="rect" intensity={7} color="#ffd29a" scale={[14, 8, 1]} position={[34, 13, -27]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={0.8} color="#c9d6e2" scale={[40, 10, 1]} position={[-30, 6, 10]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={0.5} color="#8a7c66" scale={[60, 60, 1]} position={[0, -10, 0]} rotation-x={-Math.PI / 2} />
    </Environment>
  )
}

export default function Scene() {
  const drag = useRef<{ id: number; x: number; y: number } | null>(null)
  const [dpr, setDpr] = useState(initialDpr)
  const [highQuality, setHighQuality] = useState(QUALITY.ambientOcclusion)
  const [postFx, setPostFx] = useState(QUALITY.postFx)
  const [shadows, setShadows] = useState(true)
  const [canvasKey, setCanvasKey] = useState(0)

  const endLook = (pointerId: number) => {
    if (drag.current?.id !== pointerId) return
    drag.current = null
    input.lookHeld = false
  }

  return (
    <div
      className="fixed inset-0 touch-none select-none"
      onPointerDown={(e) => {
        if (drag.current) return
        e.currentTarget.setPointerCapture(e.pointerId)
        drag.current = { id: e.pointerId, x: e.clientX, y: e.clientY }
        input.lookHeld = true
      }}
      onPointerMove={(e) => {
        if (drag.current?.id !== e.pointerId) return
        const sensitivity = e.pointerType === 'mouse' ? 0.006 : 0.009
        input.cameraDrag -= (e.clientX - drag.current.x) * sensitivity
        input.cameraPitch = Math.max(
          CAMERA_PITCH_MIN,
          Math.min(CAMERA_PITCH_MAX, input.cameraPitch + (e.clientY - drag.current.y) * sensitivity * 0.8),
        )
        drag.current.x = e.clientX
        drag.current.y = e.clientY
      }}
      onPointerUp={(e) => endLook(e.pointerId)}
      onPointerCancel={(e) => endLook(e.pointerId)}
      onLostPointerCapture={(e) => endLook(e.pointerId)}
    >
      <Canvas
        key={canvasKey}
        shadows={shadows}
        dpr={dpr}
        camera={{ fov: 55, near: 0.3, far: 1600, position: [0, 4, 0] }}
        gl={{
          antialias: QUALITY.mobile,
          powerPreference: 'high-performance',
          stencil: false,
          failIfMajorPerformanceCaveat: false,
        }}
        onCreated={({ gl }) => {
          const context = gl.getContext()
          const info = context.getExtension('WEBGL_debug_renderer_info')
          graphicsStatus.setRenderer(
            String(info ? context.getParameter(info.UNMASKED_RENDERER_WEBGL) : context.getParameter(context.RENDERER)),
          )
          gl.debug.onShaderError = (glContext, _program, vertexShader, fragmentShader) => {
            const log = glContext.getShaderInfoLog(vertexShader) || glContext.getShaderInfoLog(fragmentShader) || 'shader failed'
            graphicsStatus.error(`Shader: ${log.trim()}`)
          }
          gl.domElement.addEventListener('webglcontextlost', (event) => {
            event.preventDefault()
            graphicsStatus.contextLost()
            setHighQuality(false)
            setPostFx(false)
            if (QUALITY.mobile) setShadows(false)
            setDpr(floorDpr())
            if (graphicsStatus.get().contextLosses <= 2) setTimeout(() => setCanvasKey((k) => k + 1), 300)
          })
        }}
      >
        <PerformanceMonitor
          flipflops={2}
          onDecline={() => {
            if (highQuality) {
              setHighQuality(false)
              return
            }
            if (postFx && QUALITY.mobile) {
              setPostFx(false)
              return
            }
            setDpr((current) => Math.max(floorDpr(), Math.round((current - 0.5) * 100) / 100))
          }}
          onIncline={() => setDpr((current) => Math.min(initialDpr(), Math.round((current + 0.5) * 100) / 100))}
          onFallback={() => {
            setDpr(floorDpr())
            setHighQuality(false)
            if (QUALITY.mobile) setPostFx(false)
          }}
        />
        <color attach="background" args={['#8fb2d6']} />
        <fogExp2 attach="fog" args={['#cbd6df', 0.0007]} />
        <Sky sunPosition={SUN_POSITION} distance={4500} {...SKY} />
        <hemisphereLight args={['#c6dcf5', '#6b5a43', shadows ? 0.5 : 0.9]} />
        <SunLight />
        <SunDisc />
        <Clouds />
        <CityEnvironment />
        <FrameTracker />

        <GameLoop />
        <Suspense fallback={<GroundFallback />}>
          <City />
          <Palms />
        </Suspense>
        <Pickups />
        <Suspense fallback={null}>
          {game.cars.map((car) => (
            <CarModel key={car.id} car={car} />
          ))}
        </Suspense>
        <Suspense fallback={null}>
          <PlayerModel />
        </Suspense>
        <CameraRig />

        {!postFx ? (
          <MobileToneMapping />
        ) : (
          <EffectComposer multisampling={QUALITY.mobile ? 4 : 0} enableNormalPass={false}>
            {highQuality ? (
              <N8AO aoRadius={2.2} distanceFalloff={1.2} intensity={2.4} quality="performance" halfRes />
            ) : (
              <></>
            )}
            <Bloom luminanceThreshold={0.95} luminanceSmoothing={0.3} intensity={0.55} mipmapBlur />
            <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
            <HueSaturation saturation={0.08} />
            <BrightnessContrast brightness={0} contrast={0.06} />
            <Vignette offset={0.3} darkness={0.45} />
            {QUALITY.antialiasPass ? <SMAA /> : <></>}
          </EffectComposer>
        )}
      </Canvas>
    </div>
  )
}
