type Listener = () => void

export type GraphicsStatus = {
  renderer: string
  framesDrawn: number
  contextLosses: number
  errors: string[]
}

const status: GraphicsStatus = { renderer: 'unknown', framesDrawn: 0, contextLosses: 0, errors: [] }
const listeners = new Set<Listener>()
let snapshot: GraphicsStatus = { ...status, errors: [] }

function emit() {
  snapshot = { ...status, errors: [...status.errors] }
  listeners.forEach((listener) => listener())
}

export const graphicsStatus = {
  subscribe(listener: Listener) {
    listeners.add(listener)
    return () => listeners.delete(listener)
  },
  get: () => snapshot,
  setRenderer(name: string) {
    status.renderer = name
    emit()
  },
  frame() {
    status.framesDrawn += 1
    if (status.framesDrawn === 1 || status.framesDrawn === 30) emit()
  },
  contextLost() {
    status.contextLosses += 1
    emit()
  },
  error(message: string) {
    if (status.errors.length >= 3 || status.errors.includes(message)) return
    status.errors.push(message.slice(0, 160))
    emit()
  },
}
