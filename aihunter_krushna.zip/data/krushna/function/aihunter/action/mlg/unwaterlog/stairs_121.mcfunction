execute if block ~ ~ ~ minecraft:pale_oak_stairs[waterlogged=true] run setblock ~ ~ ~ minecraft:pale_oak_stairs[waterlogged=false] replace
execute if block ~ ~ ~ minecraft:tuff_stairs[waterlogged=true] run setblock ~ ~ ~ minecraft:tuff_stairs[waterlogged=false] replace
execute if block ~ ~ ~ minecraft:polished_tuff_stairs[waterlogged=true] run setblock ~ ~ ~ minecraft:polished_tuff_stairs[waterlogged=false] replace
execute if block ~ ~ ~ minecraft:tuff_brick_stairs[waterlogged=true] run setblock ~ ~ ~ minecraft:tuff_brick_stairs[waterlogged=false] replace
