playsound minecraft:entity.iron_golem.repair player @a ~ ~ ~ .6 2

particle minecraft:block{block_state:{Name:"minecraft:oak_planks"}} ~ ~1 ~ .1 .6 .1 .1 20 normal @a

fill ~-0.3 ~1.5 ~-0.3 ~0.3 ~1.5 ~0.3 minecraft:air replace #krushna:aihunter/falling

execute positioned ~ ~1.5 ~ unless block ~ ~ ~ #krushna:aihunter/unbreakable unless block ~ ~ ~ #krushna:aihunter/passable run function krushna:aihunter/action/break/block


execute if score showhp aihunter_dummy matches 1 in minecraft:the_end run function krushna:aihunter/hp