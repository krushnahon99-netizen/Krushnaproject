playsound minecraft:ui.button.click master @s ~ ~ ~ .1
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""
tellraw @s ""

tellraw @s {"text":"----------------------------------------","color":"white","bold":true}


execute if score quality aihunter_dummy matches 0 run tellraw @s [{"text":"Animation Quality: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"Hunters' animation quality. Although small, it may affects game performance.","color":"white"}]}},{"text":"<No Animation>","color":"red","clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/quality"}}]

execute if score quality aihunter_dummy matches 1 run tellraw @s [{"text":"Animation Quality: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"Hunters' animation quality. Although small, it may affects game performance.","color":"white"}]}},{"text":"<Standard>","color":"green","clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/quality"}}]

execute if score quality aihunter_dummy matches 2 run tellraw @s [{"text":"Animation Quality: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"Hunters' animation quality. Although small, it may affects game performance.","color":"white"}]}},{"text":"<Smooth>","color":"green","clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/quality"}}]


tellraw @s ""

tellraw @s [{"text":"Hunter's Appearance:  ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"Visual only, won't affect any of hunters' stats.","color":"white"}]}},{"text":"<Customize>","color":"light_purple","underlined":true,"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/custom/check"}},{"text":"    ","underlined":false},{"text":"<Reset>","color":"light_purple","underlined":true,"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/custom/reset"}}]


tellraw @s ""
execute unless score falldamage aihunter_dummy matches 1 run tellraw @s [{"text":"If Hunters Immune To Fall Damage: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"If 'Disabled', hunters will try to MLG to avoid fall damage after level 1 upgrade. Hunters may 'fail' their MLG, which chance depends on challenge difficulty. If 'Enabled', hunters will be completely immune to fall damage and won't MLG.","color":"white"}]}},{"text":"<Disabled>","color":"red","clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/falldamage"}}]

execute if score falldamage aihunter_dummy matches 1 run tellraw @s [{"text":"If Hunters Immune To Fall Damage: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"If 'Disabled', hunters will try to MLG to avoid fall damage after level 1 upgrade. Hunters may 'fail' their MLG, which chance depends on challenge difficulty. If 'Enabled', hunters will be completely immune to fall damage and won't MLG.","color":"white"}]}},{"text":"<Enabled>","color":"green","clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/falldamage"}}]


tellraw @s ""
execute if score crosstime aihunter_dummy matches 1.. if score crosstime_m aihunter_dummy matches 10.. if score crosstime_s aihunter_dummy matches 1.. run tellraw @s [{"text":"Hunter's Cross Dimension Time: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"Determine how long is the temporary deactivation time after every time hunters travel through dimension following a target. If 'Move Active', hunters will be activated once any target moves. If 'By Distance', that time will vary by the average distance between you and hunters.","color":"white"}]}},{"text":"<->","color":"red","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/crosstime/remove"}},{"text":" "},{"score":{"name":"crosstime_m","objective":"aihunter_dummy"},"color":"white"},{"text":"mins "},{"score":{"name":"crosstime_s","objective":"aihunter_dummy"},"color":"white"},{"text":"s "},{"text":"<+>  ","color":"green","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/crosstime/add"}}]

execute if score crosstime aihunter_dummy matches 1.. if score crosstime_m aihunter_dummy matches 10.. unless score crosstime_s aihunter_dummy matches 1.. run tellraw @s [{"text":"Hunter's Cross Dimension Time: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"Determine how long is the temporary deactivation time after every time hunters travel through dimension following a target. If 'Move Active', hunters will be activated once any target moves. If 'By Distance', that time will vary by the average distance between you and hunters.","color":"white"}]}},{"text":"<->","color":"red","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/crosstime/remove"}},{"text":" "},{"score":{"name":"crosstime_m","objective":"aihunter_dummy"},"color":"white"},{"text":"mins 0"},{"score":{"name":"crosstime_s","objective":"aihunter_dummy"},"color":"white"},{"text":"s "},{"text":"<+>  ","color":"green","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/crosstime/add"}}]

execute if score crosstime aihunter_dummy matches 1.. unless score crosstime_m aihunter_dummy matches 10.. if score crosstime_s aihunter_dummy matches 1.. run tellraw @s [{"text":"Hunter's Cross Dimension Time: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"Determine how long is the temporary deactivation time after every time hunters travel through dimension following a target. If 'Move Active', hunters will be activated once any target moves. If 'By Distance', that time will vary by the average distance between you and hunters.","color":"white"}]}},{"text":"<->","color":"red","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/crosstime/remove"}},{"text":" 0"},{"score":{"name":"crosstime_m","objective":"aihunter_dummy"},"color":"white"},{"text":"mins "},{"score":{"name":"crosstime_s","objective":"aihunter_dummy"},"color":"white"},{"text":"s "},{"text":"<+>  ","color":"green","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/crosstime/add"}}]

execute if score crosstime aihunter_dummy matches 1.. unless score crosstime_m aihunter_dummy matches 10.. unless score crosstime_s aihunter_dummy matches 1.. run tellraw @s [{"text":"Hunter's Cross Dimension Time: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"Determine how long is the temporary deactivation time after every time hunters travel through dimension following a target. If 'Move Active', hunters will be activated once any target moves. If 'By Distance', that time will vary by the average distance between you and hunters.","color":"white"}]}},{"text":"<->","color":"red","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/crosstime/remove"}},{"text":" 0"},{"score":{"name":"crosstime_m","objective":"aihunter_dummy"},"color":"white"},{"text":"mins 0"},{"score":{"name":"crosstime_s","objective":"aihunter_dummy"},"color":"white"},{"text":"s "},{"text":"<+>  ","color":"green","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/crosstime/add"}}]

execute if score crosstime aihunter_dummy matches 0 run tellraw @s [{"text":"Hunter's Cross Dimension Time: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"Determine how long is the temporary deactivation time after every time hunters travel through dimension following a target. If 'Move Active', hunters will be activated once any target moves. If 'By Distance', that time will vary by the average distance between you and hunters.","color":"white"}]}},{"text":"<->","color":"red","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/crosstime/remove"}},{"text":" By Distance ","color":"white"},{"text":"<+>  ","color":"green","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/crosstime/add"}}]

execute unless score crosstime aihunter_dummy matches 0.. run tellraw @s [{"text":"Hunter's Cross Dimension Time: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"Determine how long is the temporary deactivation time after every time hunters travel through dimension following a target. If 'Move Active', hunters will be activated once any target moves. If 'By Distance', that time will vary by the average distance between you and hunters.","color":"white"}]}},{"text":"<->","color":"red","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/crosstime/remove"}},{"text":" Move Active ","color":"white"},{"text":"<+>  ","color":"green","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/crosstime/add"}}]


tellraw @s ""
execute unless score initialupgrade aihunter_dummy matches 1.. run tellraw @s [{"text":"Hunter's Initial Equipment Level: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"Level of equipment hunters will have upon spawning & respawning. ","color":"white"}]}},{"text":"<->","color":"red","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/initialupgrade/remove"}},{"text":" "},{"text":"0","color":"gray"},{"text":" "},{"text":"<+>  ","color":"green","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/initialupgrade/add"}}]

execute if score initialupgrade aihunter_dummy matches 1.. run tellraw @s [{"text":"Hunter's Initial Equipment Level: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"Level of equipment hunters will have upon spawning & respawning. ","color":"white"}]}},{"text":"<->","color":"red","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/initialupgrade/remove"}},{"text":" "},{"score":{"name":"initialupgrade","objective":"aihunter_dummy"},"color":"white"},{"text":" "},{"text":"<+>  ","color":"green","hoverEvent":{"action":"show_text","contents":[{"text":"","color":"white"}]},"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/initialupgrade/add"}}]


tellraw @s ""
execute unless score canupgrade aihunter_dummy matches 1 run tellraw @s [{"text":"Do Hunters Upgrade Equipment: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"As stated. But hunters in terminator mode won't upgrade no matter what is set.","color":"white"}]}},{"text":"<Disabled>","color":"red","clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/canupgrade"}}]

execute if score canupgrade aihunter_dummy matches 1 run tellraw @s [{"text":"Do Hunters Upgrade Equipment: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"As stated. But hunters in terminator mode won't upgrade no matter what is set.","color":"white"}]}},{"text":"<Enabled>","color":"green","clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/canupgrade"}}]


tellraw @s ""
execute if score notifyupgrade aihunter_dummy matches 0 run tellraw @s [{"text":"Notify When Hunters Upgrade Equipment: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"As stated.","color":"white"}]}},{"text":"<Disabled>","color":"red","clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/notifyupgrade"}}]

execute if score notifyupgrade aihunter_dummy matches 1 run tellraw @s [{"text":"Notify When Hunters Upgrade Equipment: ","color":"white","hoverEvent":{"action":"show_text","contents":[{"text":"As stated.","color":"white"}]}},{"text":"<Enabled>","color":"green","clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/notifyupgrade"}}]

#


tellraw @s ""
tellraw @s [{"text":"(Page 2 of 2)     ","color":"white"},{"text":"<Next Page>","color":"green","hoverEvent":{"action":"show_text","contents":[{"text":"Go to the next page of settings menu.","color":"green"}]},"underlined":true,"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/settings/menu/1"}},{"text":"     ","underlined":false},{"text":"<Start Menu>","color":"aqua","hoverEvent":{"action":"show_text","contents":[{"text":"Go back to the main menu.","color":"aqua"}]},"underlined":true,"clickEvent":{"action":"run_command","value":"/function krushna:aihunter/menu"}}]


tellraw @s {"text":"----------------------------------------","color":"white","bold":true}