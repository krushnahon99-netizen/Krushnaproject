
execute unless score activetime aihunter_dummy matches 1.. run function krushna:aihunter/active

scoreboard players set pause aihunter_dummy 0

tellraw @a {"text":"[AI Hunter] resumed","color":"light_purple"}