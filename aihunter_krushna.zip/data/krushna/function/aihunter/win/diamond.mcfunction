#krushna:aihunter/win must be executed first

execute if score started aihunter_dummy matches 1 if score wincondition aihunter_dummy matches 1 if data entity @s Inventory.[{id:"minecraft:diamond"}] run function krushna:aihunter/win

advancement revoke @s only krushna:aihunter/win/diamond